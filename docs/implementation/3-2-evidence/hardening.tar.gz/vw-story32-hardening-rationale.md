# Story 3.2 verification hardening patch

Patch: `/tmp/vw-story32-hardening.patch`
Scratch source: `/tmp/vw-story32-hardening-source`
Immutable baseline copy: `/tmp/vw-story32-hardening-baseline`
Full baseline hashes: `/tmp/vw-story32-hardening-baseline.sha256`
Changed-file before/after hashes: `/tmp/vw-story32-hardening-manifest.json`

Nested Rust test subprocess output is captured and printed only on failure, preventing successful nested summaries from inflating audit counts. Real application persistence checks reject the key header and its nonempty Base64 payload line in addition to the whole key, so JSON newline escaping cannot evade the oracle.

No production behavior changes. The patch changes tests, synthetic native fixtures and the existing test-only backend hook's crate visibility. No source/evidence/spec in the live worktree was edited. Formatting and native static C compilation were run; no Rust build/test was run, respecting the parent's concurrent mutation target.

## New focused test names and expected kills

- `adapters::ssh_material::tests::ssh_creation_modes_are_private_with_permissive_umask`: runs its own exact test in a subprocess, sets umask 000 there, and directly inspects 0700 directories / 0600 regular single-link provider-owned files. Expected kills: `file-mode`, `request-mode`.
- `adapters::ssh_material::tests::ssh_exclusive_install_preserves_existing_key_and_replacement_inodes`: rejects second install without changing original bytes, rejects a valid-metadata replacement file inode, and preserves both original material and unrelated replacement-directory contents after directory substitution. Expected kills: `exclusive-create`, `inode-identity`.
- `access::direct_request_tests::ssh_lock_intent_during_key_resolution_cleans_material_without_launch`: verifies actual material exists before key resolution, publishes lock intent while resolution holds the authority gate, then returns the key. An adapter wrapper counts installations and requires exactly NotStarted cleanup. Asserts zero installation/launch and no residual directory.

The existing ignored `adapters::ssh_material::tests::distinct_agent_principals_cannot_read_live_provider_material` now additionally passes a real provider-owned 0600 regular single-link file descriptor as stdin to an isolated mapped-principal test subprocess. The child validates its metadata, drops from mapped UID 0 to 8, and requires `private()` to reject the foreign owner. No production path traversal is weakened. Expected kill: `provider-owner`. Run this ignored test explicitly for that mutant; the normal `ssh_` filter does not execute it.

Expected normal SSH filter count is 36 passed / 1 ignored (three added tests), subject to actual execution. Do not record this prediction as a result.

## Real manager scenarios

- Strengthened `ssh-uncertain`: keeps Fault::Stop active, confirms the lease cgroup remains populated, constructs a fresh supervisor, invokes actual Provider::start_with_cleanup startup locking, and requires startup failure to preserve both live files and the lease. After clearing the fault, the same startup path must reap and remove residuals. This catches cleanup-before-manager recovery ordering directly.
- New `app-ssh-nonzero`, `app-ssh-signal`: native fixture first establishes material-reading descendants, then exits 23 or SIGKILLs its main process. Actual application supervision must persist the exact redacted failure, reap all descendants, and remove material.
- New `app-ssh-lock`, `app-ssh-cancel`: wait for Running plus native descendant material-read evidence, then revoke authority. Lock/cancel acknowledgment must occur only after independent proc cgroup emptiness and material removal. Final state must remain durable and secret-free.

The real matrix gains four scenario names. These are within the existing ignored integration test, so Rust test count does not grow by four.

## Raw-output boundary and observed leak

The native SSH fixture uses `readlinkat` on `/proc/self/fd/1` and `/proc/self/fd/2` and requires both actual descriptors to resolve exactly to `/dev/null` before writing either sentinel. Syscall numbers are defined for x86-64 (267) and AArch64 (78). The child writes `ssh-output-sinks-verified` only after both checks; both real harness paths require that marker. The bad-descriptor branch writes `ssh-output-unsafe` before exiting; the external integration barrier checks that marker on every iteration, producing the direct assertion `native SSH stdout/stderr must point to /dev/null` without waiting for the generic deadline. Sentinel write return values are also checked. Expected kill: composite `raw-child-output` mutation, even when journal metadata lacks unit attribution.

The initial mutant actually leaked two sentinel records: bounded unfiltered journal lookup found `MESSAGE=ssh-raw-output-sentinel`, PID1892906, `_COMM=memfd:protected`, `_TRANSPORT=stdout`, `SYSLOG_IDENTIFIER=helper`, timestamp1791359069203889, with neither `_SYSTEMD_USER_UNIT` nor `_SYSTEMD_CGROUP`. Exact retained JSONL: `/tmp/vw-story32-raw-output-attribution.jsonl`. The earlier unit-filtered oracle was a false negative. Why attribution was missing is unproven; no claim of mutation equivalence is made.

## Browser correction

`tests/ui/direct-request.mjs` now expects the current SSH one-time meaning: `Approval authorizes one protected execution. Lock or cancellation stops its descendants.` This fixes the observed first-run Firefox assertion failure.

## Commands after parent applies the patch

Use the parent's isolated normal/mutation targets; run strict-ancestry and manager/namespace checks outside the filesystem sandbox with real host ownership.

```bash
cargo fmt --all -- --check
git diff --check
scripts/with-secure-test-tmpdir.sh cargo test --locked --offline --lib ssh_
scripts/with-secure-test-tmpdir.sh cargo test --locked --offline --lib -- --ignored --exact adapters::ssh_material::tests::distinct_agent_principals_cannot_read_live_provider_material --nocapture
VW18_SCENARIO=ssh-exit scripts/with-secure-test-tmpdir.sh scripts/test-systemd-supervisor.sh
VW18_SCENARIO=ssh-uncertain scripts/with-secure-test-tmpdir.sh scripts/test-systemd-supervisor.sh
VW18_SCENARIO=app-ssh-nonzero scripts/with-secure-test-tmpdir.sh scripts/test-systemd-supervisor.sh
VW18_SCENARIO=app-ssh-signal scripts/with-secure-test-tmpdir.sh scripts/test-systemd-supervisor.sh
VW18_SCENARIO=app-ssh-lock scripts/with-secure-test-tmpdir.sh scripts/test-systemd-supervisor.sh
VW18_SCENARIO=app-ssh-cancel scripts/with-secure-test-tmpdir.sh scripts/test-systemd-supervisor.sh
```

Then rerun the five filesystem survivors plus reordered-recovery and raw-child-output mutations against these tests and complete the parent regression/browser matrix. Keep pre-hardening survival/failure evidence.

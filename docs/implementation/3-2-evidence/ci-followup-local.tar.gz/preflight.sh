set -euo pipefail
for principal in 8 10; do
  timeout --signal=TERM --kill-after=5s 30s \
    unshare --user --map-auto --map-root-user --fork \
    python3 -c 'import os,sys; uid=int(sys.argv[1]); os.setgroups([]); os.setgid(uid); os.setuid(uid); assert (os.getuid(),os.getgid(),os.getgroups()) == (uid,uid,[])' "$principal"
done

# Local app-ssh-lock failure diagnosis (read-only)

The external test waited for `finished` and timed out with stale stage `recovered`. The inner provider harness had already failed after 2.74 seconds, at `src/adapters/supervisor/real_tests.rs:1150`, unwrapping `manager::proc_empty(...): Err(CleanupUncertain)`. The earlier `f.app.lock().unwrap()` at line1145 completed successfully; this was the extra independent post-acknowledgment inventory assertion, not a lock hang.

Retained journals:
- `/tmp/vw-story32-ci-app-ssh-lock-failed-journal.log`: exact provider unit `vw18-harness-778499-.tmpsTj3Kj-app-ssh-lock.service`.
- `/tmp/vw-story32-ci-app-ssh-lock-request-journal.log`: exact request unit `vw-access-98b443300f6f20c3-b8d3d4e418676f9e4628d423e233a41d.service`.
- `/tmp/vw-story32-ci-app-ssh-lock-window-journal.log`: bounded local journal window12:34:46–12:34:50.

Request journal records expected TERM-resistant fixture cleanup: stop begins12:34:46.725678; manager sends SIGKILL after its stop timeout, then records Stopped12:34:48.807936. Provider assertion panics12:34:49.022877. Systemd lifecycle messages alone cannot prove the independent process inventory was empty.

`proc_empty_with_budget` (manager.rs795–853) can return CleanupUncertain for:
1. Invalid supplied cgroup spelling.
2. Exhausted inventory budget before/during/after scanning.
3. Any non-NotFound error reading any numeric PID's stat/cgroup/stat (including invalid UTF-8); NotFound is explicitly skipped.
4. Either stat response lacking a parseable start-time field.
5. Start-time disagreement between the two observations (PID identity ambiguity).
6. An observed cgroup response with no unified `0::` line.

The scan covers all visible numeric PIDs, including unrelated processes. A matched target process instead returns Ok(false), which would produce the explicit assertion message rather than this unwrap error. Directory enumeration errors map to ManagerUnavailable, so they do not match the recorded error. Invalid cgroup input is excluded by the successful pre-lock scan of the same immutable lease; the ten-second inventory budget is inconsistent with the entire2.74-second scenario duration. The remaining recorded-error possibilities are read, parse, identity, or unified-membership ambiguity. No PID, errno, or original proc content was recorded, so the exact cause is not recoverable from these logs. Process churn or access changes are hypotheses, not established root causes.

Parent reported focused app-ssh-lock subsequently passed unchanged (one test,5.12s); full rerun remains parent-owned. No source changes were made by this diagnosis.

from pathlib import Path
import argparse,tarfile,io,gzip,hashlib,subprocess,shutil
p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('name');a=p.parse_args()
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-ssh-ephemeral-provider-material/docs/implementation/3-2-evidence')
tmp=Path('/tmp')/('vw32-archive-'+a.name)
subprocess.run(['python3','/tmp/vw-story32-parent/archive.py',str(a.source),str(tmp)],check=True)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for f in sorted(tmp.rglob('*')):
  if f.is_file():
   data=f.read_bytes();info=tarfile.TarInfo(str(f.relative_to(tmp)));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
dest=root/(a.name+'.tar.gz');assert not dest.exists();dest.write_bytes(gzip.compress(buf.getvalue(),mtime=0))
with tarfile.open(dest,'r:gz') as tar:
 members=tar.getmembers()
 for member in members:assert tar.extractfile(member).read()==(tmp/member.name).read_bytes()
with (root/'README.md').open('a') as f:f.write(f'| [{dest.name}]({dest.name}) | {len(members)} | `{hashlib.sha256(dest.read_bytes()).hexdigest()}` |\n')
print(dest)

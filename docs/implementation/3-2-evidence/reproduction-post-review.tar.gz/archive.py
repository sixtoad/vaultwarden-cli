"""Archive reproducible evidence without copying build trees or fixture state."""
from pathlib import Path
import argparse,gzip,hashlib,json,shutil
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
index=[]
for f in sorted(a.input.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(a.input)
 if any(x in ('source','target') for x in rel.parts):continue
 if f.suffix not in ('.log','.json','.jsonl','.diff','.patch','.py','.md'):continue
 data=f.read_bytes();dest=a.output/rel
 if f.suffix in ('.log','.diff','.patch','.json','.jsonl'):
  dest=dest.with_name(dest.name+'.gz');payload=gzip.compress(data,mtime=0)
 else:payload=data
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload)
 index.append(dict(source=str(rel),archived=str(dest.relative_to(a.output)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(a.output/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(dict(files=len(index),bytes=sum(x['bytes'] for x in index))))

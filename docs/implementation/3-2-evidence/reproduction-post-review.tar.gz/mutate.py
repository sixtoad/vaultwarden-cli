"""Sequential, isolated semantic mutations with exact failing-test classification."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('root', type=Path)
p.add_argument('campaign', type=Path)
p.add_argument('plan', type=Path)
p.add_argument('--target', type=Path)
a = p.parse_args()
root, campaign = a.root.resolve(), a.campaign.resolve()
campaign.mkdir(parents=True, exist_ok=False)
source, target = campaign / 'source', (a.target.resolve() if a.target else campaign / 'target')
source.mkdir()
names = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard'], cwd=root, text=True).splitlines()
for name in sorted(set(names)):
    item = root / name
    if item.is_file() and not name.startswith('docs/implementation/'):
        dest = source / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        # Fresh mtimes invalidate all package profiles in a reused mutation-only target.
        shutil.copy(item, dest)

def manifest():
    return {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(source.rglob('*')) if p.is_file()}

original = manifest()
(campaign / 'source-hashes.json').write_text(json.dumps(original, indent=2) + '\n')
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='2', RUST_TEST_THREADS='4',
           CARGO_NET_OFFLINE='true', VW_UI_DEPS='/tmp/vw-story21-ui/node_modules',
           CERTUTIL='/tmp/vw-story21-nss/extracted/usr/bin/certutil', FIREFOX='/usr/bin/firefox')

def run(command, log_path, timeout=1500):
    started = time.monotonic()
    with log_path.open('w') as log:
        child = subprocess.Popen(command, cwd=source, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            code = 124
    content = log_path.read_text(errors='replace')
    suites = [[int(n) for n in row] for row in re.findall(
        r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', content)]
    return dict(command=command, exit=code, seconds=round(time.monotonic()-started, 2),
                suites=suites, log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest()), content

plan = json.loads(a.plan.read_text())
shutil.copy2(a.plan, campaign / 'plan.json')
baselines = {}
results = []
for case in plan:
    assert manifest() == original, 'isolated source differs before candidate'
    key = json.dumps(case['command'])
    folder = campaign / case['name']
    folder.mkdir()
    if key not in baselines:
        print('BASELINE ' + case['name'], flush=True)
        record, log = run(case['command'], folder / 'baseline.log', case.get('timeout', 1500))
        passing = record['exit'] == 0 and sum(s[0] for s in record['suites']) >= case.get('min_passed', 1)
        record['valid_baseline'] = passing
        (folder / 'baseline.json').write_text(json.dumps(record, indent=2) + '\n')
        if not passing:
            raise SystemExit('Invalid baseline; campaign halted without claiming a kill.')
        baselines[key] = case['name']
    changed = {}
    try:
        for edit in case['edits']:
            path = source / edit['file']
            before = path.read_text()
            if before.count(edit['before']) != 1:
                raise SystemExit('Mutation anchor is not unique: ' + case['name'])
            changed.setdefault(path, before)
            path.write_text(before.replace(edit['before'], edit['after'], 1))
        import difflib
        patch = ''.join(''.join(difflib.unified_diff(before.splitlines(True), path.read_text().splitlines(True),
                       fromfile='a/' + str(path.relative_to(source)), tofile='b/' + str(path.relative_to(source))))
                        for path, before in changed.items())
        (folder / 'mutation.diff').write_text(patch)
        candidate = manifest()
        print('MUTANT ' + case['name'], flush=True)
        result, log = run(case['command'], folder / 'mutant.log', case.get('timeout', 1500))
        # A named executed failure plus its summary is required. Compiler/tool failures are not kills.
        expected = case['expected_failed']
        rebuilt = 'Compiling vaultwarden-cli ' in log
        failing = [name for name in expected if re.search(r'^test ' + re.escape(name) + r' \.\.\. FAILED$', log, re.M)]
        compiler_error = re.search(r'^error\[E\d+\]:|^error: could not compile|^error: expected|^error: cannot find', log, re.M) is not None
        if not rebuilt:
            classification = 'unclassified_failure'
        elif result['exit'] == 0:
            classification = 'survived'
        elif result['exit'] == 124:
            classification = 'timeout'
        elif failing and result['suites'] and sum(s[1] for s in result['suites']) > 0 and not compiler_error:
            classification = 'killed'
        elif compiler_error:
            classification = 'unviable'
        else:
            classification = 'unclassified_failure'
        result.update(name=case['name'], classification=classification, package_rebuilt=rebuilt, expected_failed=expected,
                      observed_expected_failures=failing, baseline=baselines[key], candidate_hashes=candidate)
    finally:
        for path, before in changed.items():
            path.write_text(before)
    result['restored'] = manifest() == original
    assert result['restored'], 'source restoration failed'
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    results.append(result)
    (campaign / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('name', 'classification', 'exit', 'seconds', 'observed_expected_failures', 'restored')}), flush=True)
    # Fresh write timestamps invalidate this fixed source directory; each candidate
    # must also report package recompilation. Normal builds never use this target.
summary = {name: sum(r['classification'] == name for r in results)
           for name in ('killed', 'survived', 'timeout', 'unviable', 'unclassified_failure')}
(campaign / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('root', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('checks', type=Path)
parser.add_argument('--target', required=True)
args = parser.parse_args()
root = args.root.resolve()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
checks = json.loads(args.checks.read_text())

def manifest():
    names = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard'], cwd=root, text=True).splitlines()
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest()
            for p in sorted(set(names))
            if (root / p).is_file() and (p.startswith(('src/', 'tests/', 'scripts/', 'packaging/')) or p in ('Cargo.toml', 'Cargo.lock'))}

original = manifest()
(out / 'source-hashes.json').write_text(json.dumps(original, indent=2) + '\n')
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=args.target, CARGO_BUILD_JOBS='2', RUST_TEST_THREADS='4',
           CARGO_NET_OFFLINE='true', VW_UI_DEPS='/tmp/vw-story21-ui/node_modules',
           CERTUTIL='/tmp/vw-story21-nss/extracted/usr/bin/certutil', FIREFOX='/usr/bin/firefox')
results = []
for check in checks:
    if manifest() != original:
        raise SystemExit('Source changed before check; start a new verification phase.')
    print('START ' + check['name'], flush=True)
    started = time.monotonic()
    log_path = out / (check['name'] + '.log')
    timed_out = False
    with log_path.open('w') as log:
        child = subprocess.Popen(check['command'], cwd=root, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=check.get('timeout', 1500))
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            code = 124
    content = log_path.read_text(errors='replace')
    suites = [[int(n) for n in row] for row in re.findall(
        r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', content)]
    passed = sum(s[0] for s in suites)
    valid_count = passed >= check.get('min_passed', 0)
    source_unchanged = manifest() == original
    result = dict(name=check['name'], command=check['command'], exit=code,
                  seconds=round(time.monotonic()-started, 2), timed_out=timed_out,
                  suites=suites, minimum_test_count_met=valid_count,
                  source_unchanged=source_unchanged,
                  log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest())
    results.append(result)
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    if code or not source_unchanged or not valid_count:
        raise SystemExit('Check failed or invalid; inspect saved log. No failure is classified as a pass.')
print('All selected checks completed against unchanged source.', flush=True)

from pathlib import Path
import subprocess,json,hashlib,os,signal,time,re,sys
root=Path(sys.argv[1]).resolve(); report=root/'bounded-verification';report.mkdir()
manifest=json.loads((root/'source-manifest.json').read_text());plan=json.loads((root/'mutation-plan.json').read_text());trust=root/'macos/Sources/CompanionCore/Trust.swift';original=trust.read_bytes()
def save(): (report/'results.json').write_text(json.dumps(result,indent=2)+'\n')
def hashes(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in manifest}
assert root.name.startswith('vw-companion-review-identity.') and not (root/'.git').exists() and hashes()==manifest
result={'status':'running','checks':[],'source_restored':True};save()
def descendants(pid):
 rows=[x.split(None,2) for x in subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,comm='],text=True).splitlines()];ids={pid}
 for _ in range(10): ids|={int(p) for p,pp,c in rows if int(pp) in ids}
 return [(int(p),c) for p,pp,c in rows if int(p) in ids]
def run(name,args,timeout=60):
 log=report/(name+'.log');started=time.monotonic();timedout=False
 with log.open('w') as output:
  process=subprocess.Popen(args,cwd=root,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timedout=True; children=descendants(process.pid)
   for pid,command in children:
    if Path(command).name=='xctest': subprocess.run(['/usr/bin/sample',str(pid),'1','1','-file',str(report/(name+'.sample'))],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
   for pid,_ in reversed(children):
    try: os.kill(pid,signal.SIGTERM)
    except ProcessLookupError: pass
   try: code=process.wait(timeout=5)
   except subprocess.TimeoutExpired: code=None
 text=log.read_text();row={'name':name,'command':args,'exit_code':code,'timed_out':timedout,'seconds':round(time.monotonic()-started,3),'build_completed':'Build complete!' in text,'started_tests':re.findall(r"Test Case '-\[[^\]]+ (test[^\]]+)\]' started",text),'runtime_failures':re.findall(r"Test Case '-\[[^\]]+ (test[^\]]+)\]' failed",text)}
 result['checks'].append(row);save();print(json.dumps(row),flush=True)
 if timedout: raise RuntimeError('Bounded native check timed out; stop and verify isolated Keychain cleanup before another run')
 return row
def swift(name,test): return run(name,['/usr/bin/swift','test','--package-path',str(root/'macos'),'--filter','TLSTests.'+test])
def passed(row):
 assert row['exit_code']==0 and row['started_tests'] and not row['runtime_failures'],row['name']
tests=['testIssuerSerialCollisionNeverSubstitutesExistingIdentity','testSameSubjectRenewalReturnsExactImportedIdentity','testRealURLSessionAuthenticationAndSingleTransmission','testRealURLSessionRejectsHTTPBodyStatusMismatch']
try:
 for test in tests: passed(swift(test,test))
 assert run('bundle-tls',['python3',str(root/'macos/Tests/Fixtures/bundle_tls.py'),'--report',str(report/'bundle-tls')],180)['exit_code']==0
 assert run('release-build',['/bin/bash',str(root/'scripts/build-macos-companion.sh'),str(report/'bundle')],180)['exit_code']==0
 result['baseline_completed']=True;save();print('FULL BASELINE COMPLETE (retained startup +13 protocol +8 AppModel,4 individual TLS/identity tests,full bundle matrix,release build)',flush=True)
 text=original.decode();mutation=plan['mutations'][0]
 for edit in mutation['edits']:
  assert text.count(edit['before'])==edit['count'];text=text.replace(edit['before'],edit['after'])
 (report/'original-Trust.swift').write_bytes(original);trust.write_text(text);result['source_restored']=False;save()
 row=swift('legacy-import-mutation',tests[0]);killed=row['exit_code']!=0 and row['build_completed'] and tests[0] in row['runtime_failures']
 result['mutation']={'name':mutation['name'],'verdict':'killed_runtime' if killed else 'survived_or_invalid','intended_witness':tests[0]};save()
 assert killed,'Legacy import was not killed by intended runtime assertion'
 trust.write_bytes(original);assert hashes()==manifest;result['source_restored']=True;save()
 for test in tests[:2]: passed(swift('restored-'+test,test))
 result['status']='passed'
except BaseException as error:
 result['status']='failed_or_interrupted';result['error']=str(error);raise
finally:
 trust.write_bytes(original);result['source_restored']=hashes()==manifest;(report/'source-hashes.json').write_text(json.dumps(hashes(),indent=2)+'\n');save()

import hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/tmp/vw-companion-native.reIOJJ/macos-companion-snapshot')
report=root.parent/'bundle-fix-mutations'
report.mkdir(exist_ok=True)
paths={name:root/'macos/Sources/CompanionCore'/name for name in ['Trust.swift','Protocol.swift']}
originals={name:path.read_bytes() for name,path in paths.items()}
def hashes():return {name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in paths.items()}
original_hashes=hashes()
(report/'source-hashes.json').write_text(json.dumps(original_hashes,indent=2)+'\n')
results=[]
def restore():
 for name,path in paths.items():path.write_bytes(originals[name])
def run(name):
 start=time.monotonic();case_report=report/name
 with (report/(name+'.log')).open('w') as output:
  status=subprocess.run(['python3',str(root/'macos/Tests/Fixtures/bundle_tls.py'),'--report',str(case_report)],stdout=output,stderr=subprocess.STDOUT,timeout=180).returncode
 observed=json.loads((case_report/'results.json').read_text()) if (case_report/'results.json').exists() else []
 failures=[item['case'] for item in observed if not item['passed']]
 result={'name':name,'exit_code':status,'runtime_assertion_failures':failures,'seconds':round(time.monotonic()-start,2)}
 results.append(result);(report/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 return status
mutants=[
 ('remove_leaf_pin',[('Trust.swift','KeychainIdentity.fingerprintDER(SecCertificateCopyData(leaf) as Data) == configuration.leafSHA256','true')]),
 ('skip_trust_evaluation',[('Trust.swift','SecTrustEvaluateWithError(trust, nil)','true')]),
 ('skip_hostname_validation',[('Trust.swift','SecPolicyCreateSSL(true, configuration.endpoint.host! as CFString)','SecPolicyCreateSSL(true, nil)')]),
 ('allow_http_configuration',[('Trust.swift','guard endpoint.scheme == "https", let host = endpoint.host','guard let host = endpoint.host')]),
 ('allow_tls11',[('Trust.swift','sessionConfiguration.tlsMinimumSupportedProtocolVersion = .TLSv12','sessionConfiguration.tlsMinimumSupportedProtocolVersion = .TLSv11')]),
 ('retry_lost_decision',[('Protocol.swift','let response = try await transport.send(data)','let response: Data\n        do { response = try await transport.send(data) }\n        catch {\n            if command.command == "decision" { response = try await transport.send(data) }\n            else { throw error }\n        }')]),
 ('remove_response_bounds',[('Trust.swift','response.expectedContentLength <= 1_048_576','true'),('Trust.swift','bytes.count <= 1_048_576 - data.count','true'),('Protocol.swift','response.count <= 1_048_576','true')]),
]
try:
 if run('baseline')!=0:raise RuntimeError('Baseline failed')
 for name,edits in mutants:
  restore()
  for filename,before,after in edits:
   text=paths[filename].read_text();assert text.count(before)==1,(name,filename)
   paths[filename].write_text(text.replace(before,after))
  run(name)
finally:
 restore();restored=hashes();assert restored==original_hashes
 (report/'restored-source-hashes.json').write_text(json.dumps(restored,indent=2)+'\n')
 run('restored_baseline')
print('BUNDLE_MUTATIONS_COMPLETE',flush=True)

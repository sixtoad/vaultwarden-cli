# Acceptance audit

Status: **incomplete; not ready for human implementation review**. Automated
verification and the logged-in product acceptance gate are recorded separately.
The approved spec's frozen intent has not changed.

## Frozen matrix

These named tests ran in the Linux feature suites or the final unfiltered native
suite. Full logs are retained in the evidence archives. Passing automated witnesses
establish only the scope described here.

| Matrix row | Executed automated witnesses | Remaining logged-in acceptance |
|---|---|---|
| Approval | `companion_decision_is_device_bound_single_use_and_lost_reply_is_read_only`; `companion_wrong_password_consumes_ticket_and_rate_limits_per_device`; native `testWrongPasswordConsumesVisibleTicket` and `testSharedCanonicalReviewIncludesEveryField` | Generic notification opens current full review; actual Mac approval of a signed non-TTY request produces exactly one protected execution and redacted agent result. |
| Locked | `companion_inbox_expires_and_locked_submission_never_creates_work`; `companion_unlock_is_separate_and_authentication_is_serialized` | Native separate unlock followed by a fresh signed agent submission. |
| Unavailable Mac | `companion_inbox_expires_and_locked_submission_never_creates_work`; native `testGenerationOrDisconnectInvalidationDisablesDecision` and `testLateReviewCannotUndoAuthorityInvalidation` | Actual sleep, disconnect, quit, expiry and wake/reconnect behavior. |
| Ambiguous reply | Native `testLostDecisionNeverResendsAndPendingRemainsUncertain`; real URLSession `testRealURLSessionAuthenticationAndSingleTransmission` counts exactly `decision,status` after a dropped reply | Observe app uncertainty/status recovery with the Linux provider. |
| Stale authority | `companion_snapshot_generation_review_and_deadline_are_bound_at_commit`; `companion_rejects_changed_review_generation_expiry_and_revocation`; device/replay test above | Integrated app/provider lock, restart, changed agent binding and replay acceptance. |
| Untrusted peer | `companion_real_mtls_requires_ca_and_exact_enrolled_leaf`; enrollment/revocation tests; real URLSession test rejects wrong CA/pin/hostname and foreign/revoked identity | Operator setup, persistent Keychain identity across app restart and end-to-end stop/revoke/restart. |

## Acceptance criteria

1. **Passed on the installed navigation build:** the operator clicked a generic
   notification, confirmed Setup → Approvals with the full review, and approved
   with the synthetic provider password. Linux audited exactly one real protected
   execution and success; the actual mapped-UID signed non-TTY CLI received a
   redacted completed result and exited 0. No Linux desktop was needed. See the
   2026-10-07 11:31 UTC observation below.
2. **Automated regression passed:** companion-disabled browser, mapped-UID agent
   and real-systemd regressions, plus default/all/no-default Rust feature suites.
   Live Vaultwarden tests requiring external credentials were not exercised;
   see the Linux ledger for exact exclusions.
3. **Incomplete:** login startup after a real macOS logout/login. The development
   app is now installed with explicit user approval; login registration and
   actual logout/login acceptance have not been performed or claimed.

The authorized Mac infrastructure is available and native build/tests passed.
SSH Accessibility automation is not trusted; no permissions were changed. Manual
observations require the operator. The spec remains `in-progress`; BMAD review
handoff is deferred until all required acceptance is established. Nothing was
committed, pushed, submitted as a PR or deployed.

See [native verification](native-verification.md),
[interactive fixture record](interactive-acceptance.json), and
[operator acceptance instructions](../../companion-setup.md).

## Bundle and operator follow-up

The actual app exposed a private-CA ATS failure missed by the original unbundled
checks. The user explicitly authorized the app-level ATS exception; explicit
HTTPS/TLS 1.2+, CA/hostname/expiry, exact pin and mTLS checks remain enforced.
Supplementary verification passed 9 Swift tests and 13 signed-bundle cases; all
7 scoped bundle security mutants were killed by runtime assertions, with zero
survivors/skips and restored baseline passing. See [bundle results](bundle-fix/results.json).

Notification authorization returned an NSError; this has not been established
as user denial. The app now distinguishes those outcomes. Disposable test
bundles use separate identifiers and clean up their own registrations. Actual
notification delivery, inbox visibility, approval, unlock and login acceptance
remain incomplete. Later fixture observations are in
[continuation evidence](interactive-continuation.json).

## 2026-10-07 wrong-password acceptance finding

The operator confirmed connected/unlocked and reached the full review. They
corrected the initial field-entry report: the password field worked. The attempt
showed `Outcome uncertain: still pending`, not an explicit authentication error.
The request subsequently expired with zero execution. Actual Mac logs show an
HTTP 403 response immediately followed by CFNetwork -1206; real-bundle regression
and protocol correction are in progress. Explicit rejection and denial remain
unverified. An unrelated SSH AppleScript focus diagnostic triggered a System
Events permission prompt; the operator was told to deny it and the exact diagnostic
processes were terminated. Companion operation does not require that permission.

## Corrected-build verification complete; operator acceptance pending

The HTTP422 correction passed nine native XCTest cases, fifteen signed-bundle
cases, and a new runtime-killed allowlist mutation. The three Linux feature
suites each exercised 894 tests, excluding 71 live-backend early returns and
reporting 15 ignored entries. Documentation/check/fmt/strict Clippy and real
agent/Firefox/systemd checks passed. Twelve refreshed Rust mutations were killed
at runtime; zero survivors/invalids/skips/timeouts. The first agent regression
failed an admission-synchronization check; its unchanged isolated rerun passed,
and the failure/cause uncertainty are retained. Parent verified current source
hashes (13 native and 11 Rust/protocol) and both new evidence archive digests.

The user approved development installation, and the verified corrected app was
installed under the Mac user’s Applications folder. Its authenticated reads work
and the operator confirmed notifications enabled. Notification delivery/click and
corrected decision acceptance are being tested. No commit, push, PR or production
provider deployment was performed. BMAD review handoff and final complete diff/matrix audit remain
deferred until the required logged-in acceptance is complete.

## Installed-app wrong-password and notification observation

The operator confirmed notification permission enabled and a delivered notification
opened the installed app. The window remained on Setup, which is a tab-routing
defect, not accepted full-review navigation. Native correction is in progress.
The wrong password now displayed `Decision rejected (authentication_failed).
Obtain a fresh review before trying again.` Linux retained the request pending
without an execution claim or start; it then expired normally at 10:34:53 UTC.
The signed non-TTY CLI returned exit 4 `wait_timeout`. Denial was not observed
before expiry. These observations establish rejection and notification delivery,
but do not establish correct-password execution or notification review routing.

The native tab-routing fix subsequently passed 9 XCTest and 15 signed-bundle cases
and was installed at 10:39:40 UTC, PID 28331. Source/archive/signature verification
passed. See [navigation evidence](notification-navigation/README.md). The expired
request's fixture was cleanly stopped; the next fixture is prepared but will not
start until the operator is ready. Logged-in routing/denial/execution checks remain
open; automated checks do not prove the UI navigation result.

## Installed-app denial passed

At 11:29 UTC the operator confirmed `denied` for request `EKxBAnFUaU2zMkt76OPRmxgV_W8DVs3JoahUVqZ4hZg`. Linux recorded submitted → denied, no execution claim or start. The actual signed non-TTY CLI returned exit 1 with the denied result, empty stderr and no synthetic secret markers. The operator had to allow the reinstalled app and had it open; no new notification banner was observed, so the corrected notification route is still unverified. The next request is held until the operator has put the companion in the background.

## Successful native approval and corrected notification routing

At 11:31 UTC the operator confirmed notification click switched Setup → Approvals
and displayed full review; the fresh correct-password action showed approved.
Request `fy_NI7FeSUlBG8xjgLDoj8o9c0hLcjofFSL2YLIsNMQ` audited submitted → approved →
execution_started → succeeded, with exactly one execution start. The distinct-UID
signed non-TTY CLI returned exit 0 and a redacted completed result (operation exit
code 0), empty stderr and no synthetic secret markers. The protected Linux worker
and executable were real; backend, password and credential data were synthetic.
This establishes AC1. Login startup and remaining lifecycle checks remain open.

## Separate unlock and admission limitations

The operator confirmed unlock; authoritative session at 11:36:27 UTC was unlocked
generation 4. The same two terminal requests remained unchanged and total execution
count stayed one. The locked submission returned `busy` without creating work;
that does not establish the expected locked-specific category. A post-unlock
submission also returned `busy` without admission. One explicit fresh-submission
retry was coordinated after proving no durable request existed. These were signed
agent admission attempts, never retries of an approval decision.

The operator selected Start at login and reported `Login startup enabled.`
Actual logout/login with automatic launch is pending; registration alone is not
a passing AC3 witness. Repeated post-unlock busy responses are authority-gate
contention; the fixture's frequent gated observation reads are a plausible,
unproven contributor. A test-only polling adjustment is being verified without
changing production admission behavior.

## Operator pause

The operator explicitly clarified they have not logged out/in and asked to wait
while they finish other work. Login registration succeeded, but actual automatic
launch (AC3) remains unverified. Live acceptance is paused and the bounded
synthetic provider is being cleanly stopped. No Mac logout/restart or new request
is scheduled. The refreshed fixture's first signed locked submission returned
`locked` with zero durable requests/executions; post-unlock fresh admission and
remaining lifecycle checks still require completion.

## Reboot and automatic startup observed

The operator rebooted and reported the shield in the menu bar. Read-only process
and boot metadata corroborated a new boot and installed-app PID 1352; its binary
digest matches the verified build. The agent did not launch it. The automatically
started app's inbox and authenticated reconnect are being confirmed before AC3
is marked complete. See [startup evidence](login-startup.json).

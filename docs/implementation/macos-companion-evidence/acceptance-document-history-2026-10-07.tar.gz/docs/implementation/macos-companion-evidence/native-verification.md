# Native verification

Latest verification is the 2026-10-07 [notification-navigation correction](notification-navigation/README.md):
9 native tests and 15 signed-bundle cases passed again, with no failures/skips.
Only `App.swift` changed from the preceding native manifest; transport and decision
guards retain their recorded security-mutation witnesses. Parent verified all 13
current source hashes and the archive digest. The verified development app was
installed at 10:39:40 UTC; the operator confirmed Setup-to-Approvals notification routing and subsequent exact-once protected execution.

Preceding [authentication-response correction](authentication-response/diagnosis.md):
The actual Mac exposed HTTP 403 being converted by CFNetwork into a client-certificate
error. Password rejection now uses HTTP 422; device enrollment rejection remains 403.

- **9 native XCTest tests passed; 0 failures/skips.**
- **15 signed app-bundle cases passed**, including explicit wrong-approval-password
  and wrong-unlock-password rejection, one command each, alongside peer/trust,
  TLS minimum, bounds, redirect and dropped-reply checks.
- **1 new scoped mutation killed at runtime; 0 survivors or invalid mutants.**
  Removing HTTP 422 from the allowlist broke the explicit rejection test. Source
  bytes were restored and the full final native run passed.
- **13/13 current input hashes match** the tested Mac snapshot. Release build,
  plist validation, strict signature verification, temporary Keychain cleanup
  and unique probe-registration absence passed.
- The corrected development bundle was installed and opened with explicit operator
  approval. Logged-in wrong-password rejection and notification delivery passed;
  clicking a notification retained the Setup tab, requiring a navigation fix.

Current evidence: [diagnosis and raw archive](authentication-response/diagnosis.md),
[source hashes](authentication-response/source-hashes.json),
[bundle hashes](authentication-response/bundle-verification.json),
[15 case results](authentication-response/bundle-results.json), and
[mutation result](authentication-response/mutation-results.json).
The parent independently verified the archive SHA256 and all 13 current input hashes.

Earlier evidence remains unchanged: [original native archive](native-evidence.tar.gz),
[ATS fix and seven bundle mutations](bundle-fix/README.md), and
[notification diagnostics and test isolation](notification-diagnostics/README.md).
These earlier source snapshots and top-level historical summary fields are not
claims that the current corrected build has completed operator acceptance.

[Continuation evidence](interactive-continuation.json) records actual operator
observations and provider audits. Denial, protected execution and notification routing passed on the installed build.
Unlock/reconnect and login startup remain incomplete. The native-only tab-selection
fix passed automated checks and is installed; its own manifest records current hashes.

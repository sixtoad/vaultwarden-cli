from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/vw-companion-native.reIOJJ/auth-error-repro')
source=root/'macos/Sources/CompanionCore/Trust.swift'
evidence=root/'mutation-evidence'
evidence.mkdir(exist_ok=True)
original=source.read_bytes()
mutant=original.replace(b'[200, 400, 403, 409, 422, 429, 503]',b'[200, 400, 403, 409, 429, 503]')
assert mutant != original
try:
    source.write_bytes(mutant)
    with (evidence/'mutant.log').open('w') as log:
        result=subprocess.run(['python3',str(root/'macos/Tests/Fixtures/bundle_tls.py'),'--report',str(evidence/'probe')],stdout=log,stderr=subprocess.STDOUT)
    records=json.loads((evidence/'probe/results.json').read_text())
    witness=next(r for r in records if r['case']=='wrong_password_explicitly_rejected')
    killed=result.returncode!=0 and witness['passed'] is False and witness['commands']==['decision'] and 'rejection' not in witness['response']
    summary={'mutation':'remove HTTP422 from allowed response statuses','exit_code':result.returncode,'runtime_killed':killed,'witness':witness,'original_sha256':hashlib.sha256(original).hexdigest()}
    assert killed
finally:
    source.write_bytes(original)
    assert source.read_bytes()==original
    summary['restored_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
    (evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))

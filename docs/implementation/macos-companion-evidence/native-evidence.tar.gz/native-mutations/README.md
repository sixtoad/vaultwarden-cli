# Native security mutation evidence

Executed on the authorized Mac snapshot on 2026-10-06 with Swift 6.3.3, using
synthetic localhost certificates, a temporary Keychain, real URLSession and the
shared canonical review fixture. No production identity or backend was used.
The snapshot was `/tmp/vw-companion-native.reIOJJ/macos-companion-snapshot`.

Baseline and restored baseline each passed all nine XCTest tests. All seven
mutants compiled and were caught by runtime assertions; none survived or were
classified from a compiler failure. `results.json` records exit codes and
`source-hashes.json`/`restored-source-hashes.json` prove exact restoration.
`runner.py` is the exact campaign driver, with the disposable snapshot path
recorded in its source.

| Mutation | Assertion that caught it |
|---|---|
| Remove exact leaf pin | Wrong-pin request succeeded and reached the server |
| Skip trust evaluation | Untrusted CA and wrong hostname were accepted |
| Skip hostname policy | Matching CA/pin with wrong hostname was accepted |
| Retain consumed review ticket | Review stayed available; a second decision was sent |
| Retry failed POSTs | Real dropped-response server received two decisions; controller's pending uncertainty disappeared |
| Remove header/stream/decoded response bounds | Valid JSON larger than 1 MiB was accepted |
| Render raw metadata | Directional/invisible scalars and empty/edge whitespace were no longer visibly escaped/quoted |

The real TLS fixture also verifies client authentication (valid, foreign and
revoked identities), redirect rejection, and one decision POST followed by a
read-only status query after a lost reply. This record does not replace logged-in
notification, startup, wake or real Linux execution acceptance.

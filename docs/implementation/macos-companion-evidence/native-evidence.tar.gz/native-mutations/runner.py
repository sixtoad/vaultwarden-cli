import hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path('/tmp/vw-companion-native.reIOJJ/macos-companion-snapshot')
report=root/'native-mutation-evidence'
report.mkdir(exist_ok=True)
paths={name:root/'macos/Sources/CompanionCore'/name for name in ['Trust.swift','Protocol.swift','DecisionController.swift']}
originals={name:path.read_bytes() for name,path in paths.items()}
def hashes(): return {name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in paths.items()}
baseline_hashes=hashes()
(report/'source-hashes.json').write_text(json.dumps(baseline_hashes,indent=2)+'\n')
results=[]
def run(name):
    start=time.monotonic()
    with (report/(name+'.log')).open('w') as out:
        status=subprocess.run(['/usr/bin/swift','test','--package-path',str(root/'macos')],stdout=out,stderr=subprocess.STDOUT,timeout=240).returncode
    log=(report/(name+'.log')).read_text()
    runtime_failure="Test Case" in log and " failed (" in log
    result={'name':name,'exit_code':status,'runtime_test_failure':runtime_failure,'seconds':round(time.monotonic()-start,2)}
    results.append(result)
    (report/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    return status,runtime_failure

def restore():
    for name,path in paths.items(): path.write_bytes(originals[name])

mutants=[
 ('remove_leaf_pin',[('Trust.swift','KeychainIdentity.fingerprintDER(SecCertificateCopyData(leaf) as Data) == configuration.leafSHA256','true')]),
 ('skip_trust_evaluation',[('Trust.swift','SecTrustEvaluateWithError(trust, nil)','true')]),
 ('skip_hostname_validation',[('Trust.swift','SecPolicyCreateSSL(true, configuration.endpoint.host! as CFString)','SecPolicyCreateSSL(true, nil)')]),
 ('retain_consumed_review_ticket',[('DecisionController.swift','busy = true; invalidate()\n        defer { busy = false }\n        do {\n            let status','busy = true\n        defer { busy = false }\n        do {\n            let status')]),
 ('retry_failed_posts',[('Protocol.swift','let response = try await transport.send(data)','let response: Data\n        do { response = try await transport.send(data) }\n        catch { response = try await transport.send(data) }')]),
 ('remove_response_bounds',[('Trust.swift','response.expectedContentLength <= 1_048_576','true'),('Trust.swift','bytes.count <= 1_048_576 - data.count','true'),('Protocol.swift','response.count <= 1_048_576','true')]),
 ('render_raw_review_metadata',[('Protocol.swift','    var result = "\\\""\n    for scalar in value.unicodeScalars {','    return value\n    var result = "\\\""\n    for scalar in value.unicodeScalars {')]),
]
try:
    if run('baseline')[0]!=0: sys.exit(2)
    for name,edits in mutants:
        restore()
        for filename,before,after in edits:
            path=paths[filename]; text=path.read_text()
            if text.count(before)!=1: raise RuntimeError('Mutation target mismatch: '+name)
            path.write_text(text.replace(before,after))
        run(name)
finally:
    restore()
    restored=hashes()
    (report/'restored-source-hashes.json').write_text(json.dumps(restored,indent=2)+'\n')
    assert restored==baseline_hashes
    run('restored_baseline')
print('NATIVE_MUTATIONS_COMPLETE',flush=True)

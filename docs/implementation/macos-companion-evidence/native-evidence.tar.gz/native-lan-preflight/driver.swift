import Foundation
import Security

@main struct LANPreflight {
    static func main() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("companion-lan-preflight-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        var keychain: SecKeychain?
        var originalSearchList: CFArray?
        var cleanupDone = false
        func cleanup() -> [String] {
            if cleanupDone { return [] }; cleanupDone = true
            var failures: [String] = []
            if let originalSearchList {
                if SecKeychainSetSearchList(originalSearchList) != errSecSuccess { failures.append("search list restore failed") }
                var actual: CFArray?
                if SecKeychainCopySearchList(&actual) != errSecSuccess || actual == nil || !CFEqual(actual, originalSearchList) { failures.append("search list restoration verification failed") }
            }
            if let keychain, SecKeychainDelete(keychain) != errSecSuccess { failures.append("temporary keychain delete failed") }
            do { try FileManager.default.removeItem(at: directory) } catch { failures.append("temporary directory delete failed") }
            return failures
        }
        defer {
            let failures = cleanup()
            if !failures.isEmpty { print("CLEANUP_FAILED: \(failures)") }
        }
        let password = "synthetic-lan-test-keychain"
        let createStatus = directory.appendingPathComponent("test.keychain-db").path.withCString { path in
            password.withCString { bytes in SecKeychainCreate(path, UInt32(password.utf8.count), bytes, false, nil, &keychain) }
        }
        guard createStatus == errSecSuccess, let keychain else { throw CompanionError.configuration }
        guard SecKeychainCopySearchList(&originalSearchList) == errSecSuccess else { throw CompanionError.configuration }
        let existing = (originalSearchList as? [SecKeychain]) ?? []
        guard SecKeychainSetSearchList((existing + [keychain]) as CFArray) == errSecSuccess else { throw CompanionError.configuration }
        let base = URL(fileURLWithPath: "/tmp/vw-companion-native.reIOJJ")
        let reference = try KeychainIdentity.importPKCS12(Data(contentsOf: base.appendingPathComponent("client.p12")), passphrase: "synthetic-companion-identity", keychain: keychain)
        let configuration = try ProviderConfiguration(endpoint: URL(string: "https://pop-os.int.cantolla.casa:40701")!, trustedCA: Data(contentsOf: base.appendingPathComponent("ca.der")), leafSHA256: "de65b1614d912e3ba7cc5036536a4d0fbf993d7c3dc9eeac432d557ec85bf33e", identityReference: reference)
        let client = CompanionClient(transport: try PinnedTransport(configuration: configuration))
        let session = try await client.session()
        let requests = try await client.list()
        let failures = cleanup()
        guard failures.isEmpty else { throw CompanionError.configuration }
        let result: [String: Any] = ["endpoint": configuration.endpoint.absoluteString, "commands": ["session", "list"], "state": session.state, "generation": session.generation, "pending_count": requests.count, "cleanup_verified": true]
        let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    }
}

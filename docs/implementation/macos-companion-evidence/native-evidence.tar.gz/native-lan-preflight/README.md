# Production native client → Linux provider LAN preflight

The temporary driver compiled the unchanged production `CompanionCore` sources
from the tested Mac snapshot and called the running synthetic Rust provider at
`https://pop-os.int.cantolla.casa:40701/v1/companion` through `PinnedTransport` and
`CompanionClient`.

Result: session/list reads succeeded with mutual TLS, the trusted CA, hostname
validation and exact leaf pin. The provider reported unlocked, authority
generation 2, with zero pending requests. No review, unlock, approval, denial,
agent submission or execution was performed by this driver.

The synthetic PKCS#12 was imported into a dedicated temporary Keychain. The driver
restored the original Keychain search list, verified equality, deleted the
Keychain and temporary directory, and reported `cleanup_verified: true`. It did
not change application preferences or the installed bundle. Production sources,
the driver, and its binary are hashed in `source-hashes.txt`; `build.log` and
`result.log` contain the actual diagnostics. The shell's unrelated missing
`runpodctl` startup warning did not affect the successful exit.

`driver.swift` records the exact temporary test driver and synthetic provisioning
passphrase. It does not contain production credentials. This check establishes
native-client/Rust-server interoperability over the actual LAN; it does not
replace logged-in app, notification, startup or protected execution acceptance.

import json,pathlib,subprocess,os,time,shutil,difflib,hashlib,re,sys,signal
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
manifest=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
scratch=pathlib.Path(os.environ.get('VW_MUTATION_WORKSPACE',str(out/'workspace')))
if not scratch.exists():
 scratch.mkdir()
 files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
 for f in filter(None,files):
  if f.startswith('docs/') or f.startswith('.github/'):continue
  src=root/f
  if src.is_file():
   dest=scratch/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
env=os.environ.copy();env.update(TMPDIR='/home/sixtocantolla/.vw-story16-tests.LGlAXW',CARGO_TARGET_DIR=os.environ.get('VW_MUTATION_TARGET',str(out/'target')),CARGO_TERM_COLOR='never')
rows=json.loads(manifest.read_text());original={r['file']:(scratch/r['file']).read_text() for r in rows}
(out/'source-sha256.json').write_text(json.dumps({str(p.relative_to(scratch)):hashlib.sha256(p.read_bytes()).hexdigest() for p in scratch.rglob('*') if p.is_file()},indent=2))
shutil.copy2(manifest,out/'manifest.json')
results=[]
def run(argv,log,timeout):
 start=time.monotonic()
 with log.open('w') as stream:
  process=subprocess.Popen(argv,cwd=scratch,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait();code='timeout'
  except BaseException:
   os.killpg(process.pid,signal.SIGKILL);process.wait();raise
 return {'argv':argv,'cwd':str(scratch),'exit_code':code,'elapsed_seconds':round(time.monotonic()-start,3),'log':str(log),'env_overrides':{k:env[k] for k in ['TMPDIR','CARGO_TARGET_DIR','CARGO_TERM_COLOR']}}
build=['cargo','test','--lib','--no-run','--locked','--offline']
test=['cargo','test','--lib','--locked','--offline','--']
base=run(build,out/'baseline-build.log',600)
(out/'baseline-build-result.json').write_text(json.dumps(base,indent=2))
if base['exit_code']!=0:sys.exit('Baseline build failed')
base=run(test+['access::','adapters::execution::'],out/'baseline-test.log',240)
(out/'baseline-test-result.json').write_text(json.dumps(base,indent=2))
if base['exit_code']!=0:sys.exit('Baseline test failed')
for r in rows:
 file=scratch/r['file'];before=original[r['file']]
 if 'replacements' in r:
  after=before
  for replacement in r['replacements']:
   assert after.count(replacement['before'])==1,(r['id'],replacement['before']);after=after.replace(replacement['before'],replacement['after'],1)
 else:
  assert before.count(r['before'])==1,(r['id'],before.count(r['before']));after=before.replace(r['before'],r['after'],1)
 d=out/r['id'];d.mkdir(exist_ok=True)
 (d/'mutation.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=r['file'],tofile=r['file'])))
 file.write_text(after)
 try:
  build_result=run(build,d/'build.log',600)
  result={'id':r['id'],'build':build_result}
  if build_result['exit_code']!=0:result['classification']='build-timeout' if build_result['exit_code']=='timeout' else 'compiler-rejected'
  else:
   tested=run(test+r['tests'],d/'test.log',180);result['test']=tested
   log=(d/'test.log').read_text()
   failed=re.findall(r'^test (.+?) \.\.\. FAILED$',log,re.M);result['failed_tests']=failed
   result['classification']='caught' if tested['exit_code']==101 and failed else ('survived' if tested['exit_code']==0 else 'needs-investigation')
  results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2));print(r['id'],result['classification'],flush=True)
 finally:file.write_text(before)

from pathlib import Path
import json,collections
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable');base=Path('/tmp');read=lambda p:json.loads(p.read_text())
c=base/'vw-story16-review1-classification';s=read(c/'summary.json');assert not s['unresolved']
g=s['generated_final'];m=s['manual_final'];eq=lambda d:sum(v for k,v in d.items() if k.startswith('equivalent'))
raw=read(base/'vw-story16-review1-mutants-final/mutants.out/outcomes.json');run=read(base/'vw-story16-review1-mutants-final/result.json')
files=collections.Counter(r['name'].split(':')[0] for r in read(c/'generated-results.json'))
text=f'''## Mutation verification

All required campaigns have finished. The effective inventory contains **506 generated
and 78 manual distinct mutations**. Generated scope covers complete production
functions and relevant existing admission/ownership/expiry guards: {files['src/adapters/execution.rs']} adapter,
{files['src/access/policy.rs']} policy, {files['src/access/application.rs']} application, {files['src/access/provider.rs']} provider and {files['src/access/ports.rs']} redacted-error formatter cases.
Manual cases cover guard omissions, individual flags/mode bits, credential wiring,
resource leaks, digest/path bypasses, syscall ordering and protocol constants.

| Scope | Caught by named failing tests | Documented equivalent/redundant | Compiler rejected | Unresolved |
|---|---:|---:|---:|---:|
| Generated: 506 | {g['caught']} | {eq(g)} | {g['compiler-rejected']} | 0 |
| Manual: 78 | {m['caught']} | {eq(m)} | 0 | 0 |
| Total: 584 | {s['combined']['caught']} | {s['combined']['documented_equivalent_or_redundant']} | {s['combined']['compiler_rejected']} | 0 |

These are distinct mutations, not summed attempts or a claimed 100% mutation score.
Compiler rejection and timeout are never credited as tests catching a bypass.
The [survivor classifications](1-6-mutation-classifications.md) explain every
remaining survivor, distinguishing exact equivalence from preparation/race-contract
redundancy and observable timing or conservative-rejection differences.

After review amendments, all six changed function scopes were freshly mutated:
`prepare_execution`, `execution_authority`, `execution_live`,
`executable_identity_matches`, `validate_elf_for_page_size` and
`checked_userspace_mapping_end`. This 257-case generated run completed with
{raw['caught']} named-test catches, {raw['missed']} initial survivors, {raw['unviable']} compiler rejections and
{raw['timeout']} build timeouts ({run['elapsed_seconds']} seconds; tool exit {run['exit_code']}). Its unmutated baseline
passed 150 tests, with six subprocess fixtures invoked through passing parents.

All three build timeouts occurred while separate dependency caches warmed under
parallel load. Separate completed reruns in an idle isolated workspace resolved
them as two named-test failures and one compiler rejection. Six size-boundary
survivors were separately caught using the literal 64 MiB positive control and
correctly hashed oversized images. No final timeout or unclassified case remains.

The 25 refreshed manual cases produced 23 named-test failures and two adjacent
live-check redundancies. They cover failed-I/O authority cleanup, final durable
policy/binding changes during backend calls, every particular credential item,
username/custom-field requirements and operation marker through the real backend,
both architecture address-bit constants, capability cleanup and aggregate
preliminary size/execute guards. The former final-authority-check survivor is
now caught; its old equivalence classification was retired.

The refreshed broad generated run omits the two expensive 64 MiB tests, the
credential-count performance oracle and the FIFO test. The six relevant new
boundary mutants ran against the size oracle separately; unchanged size/flag
mutations retain the earlier completed boundary and syscall-contract evidence.
The FIFO omission prevents a deliberately removed O_NONBLOCK flag from hanging a
mutation worker. Missing flags are tested by bounded syscall-contract fixtures.
The performance oracle and all omitted tests passed in both complete ordinary
suites. The separate manual baseline also ran the performance and size oracles.

Results retained from prior completed campaigns are explicitly identified:
**249 generated and 53 manual cases** concern unchanged production code. Exact
whole-function/constant hashes and manual patch anchors were checked, and their
**109 original named failure oracles pass in both final toolchain suites**
(subprocess fixtures via their passing parents). Current source ranges are mapped
in [provenance](1-6-evidence/retained-result-provenance.json). The current inventory
has 44 scoped function/constant ranges: 38 retained and six freshly mutated.
Retained results are not described as rerun after every test change.

Historical raw evidence includes the original 496-case generated campaign,
91-case refinement, 11 size reruns, 63-case manual run and supplemental cases.
Their initial 16 test timeouts were all rerun as named failures before retention.
The 69 prior manual cases are superseded by the retained/refreshed 78-case inventory,
not added to it. All meaningful earlier survivors were addressed by independent
permission, descriptor-zero, seal, error-label, source-race and ELF-boundary oracles.

Excluded attempts are preserved but contribute no outcomes: the earlier interrupted
manual timeout-harness run, a manual run with a concurrent build-target collision,
and the first review-refresh generated attempt that redundantly ran the costly
performance oracle for each mutant. The latter was explicitly stopped and the
entire 257-case campaign restarted. Completed campaigns used isolated workspaces
and targets; reuse of the idle manual target for the three infrastructure and six
boundary reruns was sequential and checked against current source before reuse.

Channels/hooks determine race ordering. No production inspection API was added
for tests. Raw commands, mutation diffs, compiler errors, named assertions and
attempt exclusions are retained in the archive.

'''
p=root/'docs/implementation/1-6-test-evidence.md';d=p.read_text();start=d.index('## Mutation verification');end=d.index('## Evidence files',start);d=d[:start]+text+d[end:]
d=d.replace('Status: review-directed implementation and final ordinary verification complete;\nmutation refresh and fresh workflow reviews pending. Previous mutation totals\nbelow remain historical until the refresh is integrated.','Status: implementation and required verification complete; fresh workflow reviews\nand human acceptance pending. No commit, push or PR has been made.')
d=d.replace('are currently in `/tmp/vw-story16-review1-final-verification/`; the command\nrecords are `stable-results.json` and `msrv-results.json`. Earlier run artifacts\nlinked below remain historical pending the final evidence packaging refresh.','are packaged under `review1-ordinary/` in the raw archive (also available at\n`/tmp/vw-story16-review1-final-verification/`). The current command records are\n[ordinary-results.json](1-6-evidence/ordinary-results.json). Older archive labels\n`ordinary-initial` and `ordinary-final` are historical pre-review runs.')
d=d.replace('[Historical pre-review acceptance matrix audit](1-6-evidence/matrix-audit.json): 17 rows, 55 tests; current final audit in `/tmp/vw-story16-review1-final-verification/matrix-audit.json` has 19 rows and 65 distinct passing tests on both toolchains','[Acceptance matrix audit](1-6-evidence/matrix-audit.json): 19 rows and 65 distinct passing tests on both toolchains')
d=d.replace('Clippy checks passed. Mutation refresh and final evidence packaging remain\npending.', 'Clippy checks passed. Scoped mutation verification and tracked/untracked\n`git diff --check` are complete; no required check is blocked.')
p.write_text(d)
spec=Path('/home/sixtocantolla/sessions/day-to-day/_bmad-output/implementation-artifacts/spec-1-6-verify-exact-protected-executable.md');d=spec.read_text();mark='### Completed implementation verification (2026-09-25)';d=d[:d.index(mark)]+f'''{mark}

- Final formatting, complete all-targets suites on Rust 1.98.1 and 1.88.0, strict Clippy, real Linux descriptor execution, and tracked/untracked whitespace checks passed. Each suite reports 773 passes: 702 non-live tests executed and 71 live-account early returns; 13 benchmark smoke checks passed. All 68 verified inputs match the final manifests.
- Current distinct inventory: 506 generated plus 78 manual mutations; {s['combined']['caught']} named-test catches, {s['combined']['documented_equivalent_or_redundant']} documented equivalent/redundant survivors and {s['combined']['compiler_rejected']} compiler-rejected cases. No unresolved result. The three refreshed build timeouts were rerun (two test catches, one compiler rejection); no timeout is credited as a catch.
- Review amendments were freshly mutated in six changed functions and 25 manual cases. Retained 249 generated/53 manual results have exact unchanged source and patch provenance; their 109 original oracles pass in both final ordinary suites. Six fresh size-boundary reruns all caught their mutations.
- All 19 acceptance-matrix rows and 65 named tests pass on both toolchains. Native AArch64/macOS, an actual Linux 6.3 host, live-account and browser runs are not claimed. No required check is blocked.
- [Full evidence and limitations](../../vaultwarden-exact-protected-executable/docs/implementation/1-6-test-evidence.md) and [mutation classifications](../../vaultwarden-exact-protected-executable/docs/implementation/1-6-mutation-classifications.md).
- Root read the initial complete implementation, the complete re-derivation delta and final helper refinement. Fresh workflow reviews and human acceptance remain pending. No commit, push or pull request.
''';spec.write_text(d)
print('Updated final verification documentation and non-frozen spec evidence')

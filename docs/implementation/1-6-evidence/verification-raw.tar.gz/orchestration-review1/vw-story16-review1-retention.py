from pathlib import Path
import json,hashlib,re
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
backup=Path('/tmp/vw-story16-review1-preserve')
out=Path('/tmp/vw-story16-review1-retention');out.mkdir(exist_ok=True)
changed={'ProviderApplication::prepare_execution','ProviderApplication::execution_authority','executable_identity_matches','linux::validate_elf_for_page_size'}
old=json.loads(Path('/tmp/vw-story16-verification/mutation-inventory.json').read_text())
retained=[r for r in old if not r['function'] or r['function']['function_name'] not in changed]
assert len(retained)==249
names={r['name'] for r in retained}
generated=[r for r in json.loads(Path('/tmp/vw-story16-final-classification/generated-results.json').read_text()) if r['name'] in names]
assert len(generated)==249
ranges=[]
for r in json.loads((backup/'docs/implementation/1-6-evidence/mutation-source-provenance.json').read_text()):
 if r['function'] in changed:continue
 text='\n'.join((backup/r['file']).read_text().splitlines()[r['first_line']-1:r['last_line']])+'\n'
 assert hashlib.sha256(text.encode()).hexdigest()==r['sha256'],r
 assert text in (root/r['file']).read_text(),r
 ranges.append({**r,'retained_after_review1':True})
assert len(ranges)==38
refresh={r['id'] for r in json.loads(Path('/tmp/vw-story16-review1-manual-manifest.json').read_text())}
manual=[r for r in json.loads(Path('/tmp/vw-story16-final-classification/manual-results.json').read_text()) if r['id'] not in refresh and not r['id'].startswith('auth_')]
assert len(manual)==53
manifest={r['id']:r for f in ['/tmp/vw-story16-manual-isolated/manifest.json','/tmp/vw-story16-manual-supplemental/manifest.json'] for r in json.loads(Path(f).read_text())}
allold=json.loads(Path('/tmp/vw-story16-verification/all-mutants.json').read_text())
manual_proof=[]
for result in manual:
 r=manifest[result['id']]; oldtext=(backup/r['file']).read_text();newtext=(root/r['file']).read_text()
 proof=[]
 for change in r.get('replacements',[{'before':r.get('before')} ]):
  before=change['before'];assert oldtext.count(before)==1 and newtext.count(before)==1,r['id']
  line=oldtext[:oldtext.index(before)].count('\n')+1
  functions={json.dumps(x['function'],sort_keys=True) for x in allold if x['file']==r['file'] and x['function'] and x['function']['span']['start']['line']<=line<=x['function']['span']['end']['line']}
  if functions:
   f=min([json.loads(x) for x in functions],key=lambda x:x['span']['end']['line']-x['span']['start']['line'])
   body='\n'.join(oldtext.splitlines()[f['span']['start']['line']-1:f['span']['end']['line']])+'\n'
   assert body in newtext,(r['id'],f['function_name'])
   proof.append({'function':f['function_name'],'whole_body_sha256':hashlib.sha256(body.encode()).hexdigest(),'unchanged':True})
  else:proof.append({'constant_or_module_fragment_sha256':hashlib.sha256(before.encode()).hexdigest(),'unchanged':True})
 manual_proof.append({'id':r['id'],'file':r['file'],'proof':proof})
logs=[Path('/tmp/vw-story16-review1-final-verification/'+n).read_text() for n in ['stable-1.log','msrv-0.log']]
def current_name(n):return n.replace('execution_preparation_retains_bytes_without_consuming_approval_or_resolving','execution_preparation_retains_capability_without_consuming_approval_or_resolving')
# Original ignored fixtures execute through their parent harnesses.
parents={'adapters::execution::linux::tests::execution_child':'adapters::execution::linux::tests::descriptor_execution_subprocess','adapters::execution::linux::tests::cleanup_child':'adapters::execution::linux::tests::descriptor_cleanup_subprocess'}
parents.update({'adapters::execution::linux::tests::required_syscall_flag_child':'adapters::execution::linux::tests::preparation_explicitly_requests_executable_memfd_and_no_controlling_terminal','adapters::execution::linux::tests::syscall_failure_child':'adapters::execution::linux::tests::unavailable_memfd_and_sealing_syscalls_close_resources'})
parents.update({'adapters::execution::linux::tests::descriptor_zero_child':'adapters::execution::linux::tests::descriptor_zero_is_valid_for_open_and_snapshot_subprocess','access::policy::tests::preliminary_open_flags_child':'access::policy::tests::preliminary_open_flags_are_required_by_the_syscall_contract'})
oracles=set()
for r in generated+manual:
 for name in r.get('failed_tests',[]):oracles.add(parents.get(name,current_name(name)))
for name in oracles:
 assert all(re.search(r'^test '+re.escape(name)+r' \.\.\. ok$',log,re.M) for log in logs),name
for name,value in [('generated-results',generated),('manual-results',manual),('production-ranges',ranges),('manual-source-proof',manual_proof)]:
 (out/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
summary={'retained_generated':len(generated),'retained_manual':len(manual),'unchanged_scoped_ranges':len(ranges),'named_original_oracles_passing_both_toolchains':len(oracles),'old_authority_manual_cases_replaced_not_silently_carried':True,'basis':'Exact unchanged function/constant bodies and retained patch locations; final ordinary oracles pass. Changed function scopes are freshly mutated. Portable authority fixture replaced by explicit Linux application integration for FD behavior.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))

from pathlib import Path
import subprocess,json,os,stat,hashlib
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable');out=Path('/tmp/vw-story16-review1-diff');out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(json.loads((out/'git-env.json').read_text()));baseline='fd6b7eb3dea18d686c844189772fb9e5673ec050'
def git(*args,**kwargs):return subprocess.run(['git',*args],cwd=root,env=env,check=True,**kwargs)
git('read-tree',baseline)
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
entries=[]
for name in sorted(set(filter(None,files))):
 p=root/name
 if not p.exists():entries.append('0 '+'0'*40+'\t'+name+'\n');continue
 if p.is_symlink():raise RuntimeError('unexpected link '+name)
 mode='100755' if p.stat().st_mode & stat.S_IXUSR else '100644'
 blob=git('hash-object','-w','--',name,capture_output=True,text=True).stdout.strip()
 entries.append(mode+' '+blob+'\t'+name+'\n')
git('update-index','--index-info',input=''.join(entries),text=True)
with (out/'complete.diff').open('wb') as stream:git('diff','--cached',baseline,stdout=stream)
git('diff','--cached','--check',baseline)
r=git('diff','--cached','--stat',baseline,capture_output=True,text=True);print(r.stdout)
print('Complete diff',out/'complete.diff', 'bytes',(out/'complete.diff').stat().st_size)

from pathlib import Path
import json
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
source=(root/'src/access/application.rs').read_text()
old=json.loads(Path('/tmp/vw-story16-manual-isolated/manifest.json').read_text())
tests=['access::direct_request_tests::execution_','access::application::tests::execution_']
rows=[]
def add(id,before,after,why,oracles=tests):
 assert source.count(before)==1,(id,source.count(before))
 rows.append({'id':id,'file':'src/access/application.rs','before':before,'after':after,'tests':oracles,'explanation':why})
for r in old:
 if r['id'] in {'auth_after_prepare','auth_final','auth_initial_full_revalidation','auth_exact_original_binding','auth_compatibility_result','auth_owner_boundary'}:
  assert source.count(r['before'])==1,r['id'];rows.append(r)
for id,before,after in [
 ('auth_after_probe','        self.execution_live(&mut authority, id)?;\n        compatibility?;', '        compatibility?;'),
 ('auth_before_each_credential','        for login in policy.login_bindings() {\n            self.execution_live(&mut authority, id)?;', '        for login in policy.login_bindings() {'),
 ('auth_after_each_credential','            self.execution_live(&mut authority, id)?;\n            if !eligible.unwrap_or(false) {','            if !eligible.unwrap_or(false) {'),
 ('auth_before_probe','        self.execution_live(&mut authority, id)?;\n        let compatibility =','        let compatibility ='),
 ('auth_post_read_admit','        // the strength of authority checked before that read.\n        self.execution_live(authority, id)?;','        // the strength of authority checked before that read.'),
 ('auth_post_expiry_admit','            // session expired or admission closed during that I/O.\n            self.admit(authority)?;','            // session expired or admission closed during that I/O.'),
 ('auth_initial_admit','    ) -> Result<(), DirectRequestError> {\n        self.admit(authority)?;\n        if authority','    ) -> Result<(), DirectRequestError> {\n        if authority'),
 ('auth_expiry_persistence','            let expiry = self.expire_requests(authority);','            let expiry: Result<(), SessionError> = Ok(());'),
]:add(id,before,after,'Independent live/durable check omission; assess cleanup, ordering and final policy binding, not only returned success.')
start=source.index('        if authority\n            .request_deadlines',source.index('    fn execution_live('))
end=source.index('        Ok(())',start)
add('auth_post_read_deadline',source[start:end],'','Remove request-deadline and durable-expiry branch; session admission remains.')
start=source.index('            let eligible = authority.backend.eligible(',source.index('    pub(crate) fn prepare_execution'))
end=source.index('            self.execution_live',start)
block=source[start:end]
contract=['adapters::vaultwarden::tests::preparation_rechecks_each_policy_credential_with_the_real_backend']
add('credential_first_item_reused',block,block.replace('immutable_item_id: login.item_id','immutable_item_id: policy.login_bindings().next().unwrap().item_id'),'Check the first policy item twice while preserving each supplied field list.',contract)
add('credential_password_fields_reused',block,block.replace('fields: &login.required_fields','fields: &[super::policy::LoginField::Password]'),'Use Password for every item, ignoring policy Username/Custom requirements.',contract)
add('credential_username_omitted',block,block.replace('fields: &login.required_fields','fields: &login.required_fields.iter().filter(|f| !matches!(f, super::policy::LoginField::Username)).cloned().collect::<Vec<_>>()'),'Omit the second item username requirement; all other requested fields remain.',contract)
add('credential_custom_omitted',block,block.replace('fields: &login.required_fields','fields: &login.required_fields.iter().filter(|f| !matches!(f, super::policy::LoginField::Custom { .. })).cloned().collect::<Vec<_>>()'),'Omit the second item custom requirement; all other requested fields remain.',contract)
add('credential_wrong_operation_marker',block,block.replace('marker: &marker','marker: "vw-access=deploy"'),'Use a marker unrelated to this approved operation.',contract)
p=Path('/tmp/vw-story16-review1-manual-manifest.json');p.write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),p)

from pathlib import Path
import json,collections,re
base=Path('/tmp');out=base/'vw-story16-review1-classification';out.mkdir(exist_ok=True)
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable');backup=base/'vw-story16-review1-preserve'
fresh_dir=base/'vw-story16-review1-mutants-final'
raw=json.loads((fresh_dir/'mutants.out/outcomes.json').read_text());assert raw['end_time']
audit=json.loads((fresh_dir/'assertion-audit.json').read_text())
old_inventory={r['name']:r for r in json.loads((base/'vw-story16-verification/mutation-inventory.json').read_text())}
new_inventory={r['name']:r for r in json.loads((fresh_dir/'selected.json').read_text())}
def key(r,tree):
 line=(tree/r['file']).read_text().splitlines()[r['span']['start']['line']-1].strip()
 return (r['file'],r['function']['function_name'] if r['function'] else '',r['replacement'],line)
equivalent={}
for r in json.loads((base/'vw-story16-final-classification/generated-results.json').read_text()):
 if r['classification'].startswith('equivalent'):equivalent[key(old_inventory[r['name']],backup)]=r
boundaries={}
folder=base/'vw-story16-review1-boundary-final'
if (folder/'results.json').exists():
 manifest={r['id']:r for r in json.loads((folder/'manifest.json').read_text())}
 for r in json.loads((folder/'results.json').read_text()):boundaries[manifest[r['id']]['original_generated_name']]=r
infrastructure={}
folder=base/'vw-story16-review1-infrastructure-final'
if (folder/'results.json').exists():
 manifest={r['id']:r for r in json.loads((folder/'manifest.json').read_text())}
 for r in json.loads((folder/'results.json').read_text()):infrastructure[manifest[r['id']]['original_generated_name']]=r
rows=json.loads((base/'vw-story16-review1-retention/generated-results.json').read_text())
for r in rows:r['retained_after_review1']=True
unresolved=[]
for a in audit:
 n=a['name'];r={'name':n,'campaign':'review1-generated','initial_outcome':a['summary'],'log_path':a['log_path'],'diff_path':a['diff_path'],'phase_results':a['phase_results']}
 if n in infrastructure:
  b=infrastructure[n];r.update(classification=b['classification'],campaign='review1-infrastructure-rerun',build=b['build'])
  if b['classification']=='caught':
   assert b['failed_tests'],n;r.update(failed_tests=b['failed_tests'],test=b['test'])
  elif b['classification']=='compiler-rejected':
   errors=re.findall(r'^error(?:\[[^]]+\])?:[^\n]+',Path(b['build']['log']).read_text(),re.M);assert errors,n;r.update(compiler_errors=errors)
  else:unresolved.append(n)
 elif n in boundaries:
  b=boundaries[n];assert b['classification']=='caught' and b['failed_tests'],n
  r.update(classification='caught',campaign='review1-boundary',failed_tests=b['failed_tests'],build=b['build'],test=b['test'])
 elif a['summary']=='CaughtMutant':
  assert a['failed_tests'],n;r.update(classification='caught',failed_tests=a['failed_tests'])
 elif a['summary']=='Unviable':
  assert a['compiler_errors'],n;r.update(classification='compiler-rejected',compiler_errors=a['compiler_errors'])
 elif a['summary']=='MissedMutant' and key(new_inventory[n],root) in equivalent:
  e=equivalent[key(new_inventory[n],root)];r.update(classification=e['classification'],evidence=e['evidence'],review1_equivalence_origin=e['name'])
 else:r['classification']='unresolved';unresolved.append(n)
 rows.append(r)
assert len(rows)==506,len(rows)
manual=json.loads((base/'vw-story16-review1-retention/manual-results.json').read_text())
for r in manual:r['retained_after_review1']=True
fresh=json.loads((base/'vw-story16-review1-manual-final/results.json').read_text());assert len(fresh)==25
for r in fresh:
 if r['classification']=='caught':assert r['failed_tests'],r['id']
 elif r['classification']=='survived' and r['id'] in ['auth_before_each_credential','auth_before_probe']:
  r.update(classification='equivalent-to-preparation-authority-contract',evidence='Only owned immutable policy/marker/iterator/boolean work under the authority gate separates this live check from the immediately preceding post-I/O check. Removing it changes when an asynchronous closure/deadline can be observed, not whether successful preparation requires live authority. The following post-I/O check always runs, including on errors, and the final durable binding revalidation remains. No secret resolution, dispatch or approval consumption occurs. This is preparation-contract redundancy, not identical timing or backend-call counts under asynchronous revocation; all nonredundant post-I/O/expiry/durable guards are independently caught. Story 1.7 must revalidate/consume dispatch authority.')
 else:unresolved.append(r['id'])
 manual.append(r)
assert len(manual)==78
summary={'generated_inventory':506,'generated_retained_unchanged':249,'generated_refreshed':257,'generated_refresh_outcomes':{k:raw[k] for k in ['caught','missed','timeout','unviable']},'generated_final':dict(collections.Counter(r['classification'] for r in rows)),'manual_distinct':78,'manual_retained_unchanged':53,'manual_refreshed':25,'manual_final':dict(collections.Counter(r['classification'] for r in manual)),'boundary_reruns':len(boundaries),'build_timeout_reruns':len(infrastructure),'counts_are_distinct_mutations_not_attempts':True,'unresolved':unresolved}
combined=collections.Counter(r['classification'] for r in rows+manual)
summary['combined']={'caught':combined['caught'],'documented_equivalent_or_redundant':sum(v for k,v in combined.items() if k.startswith('equivalent')),'compiler_rejected':combined['compiler-rejected'],'unresolved':len(unresolved)}
for n,d in [('generated-results',rows),('manual-results',manual),('summary',summary)]:
 (out/(n+'.json')).write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(summary,indent=2))
if unresolved:raise SystemExit(1)

import json,pathlib,subprocess,os,time,re,hashlib
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
out=pathlib.Path('/tmp/vw-story16-review1-mutants-final');out.mkdir(exist_ok=True)
wanted={'ProviderApplication::prepare_execution','ProviderApplication::execution_authority','ProviderApplication::execution_live','executable_identity_matches','linux::validate_elf_for_page_size','linux::checked_userspace_mapping_end'}
listed=subprocess.run(['cargo','mutants','--list','--json','--file','src/access/application.rs','--file','src/access/policy.rs','--file','src/adapters/execution.rs'],cwd=root,capture_output=True,check=True)
(out/'all-mutants.json').write_bytes(listed.stdout)
rows=[r for r in json.loads(listed.stdout) if r['function'] and r['function']['function_name'] in wanted]
for r in rows:
 f=r['function']['span'];lines=(root/r['file']).read_text().splitlines();r['whole_function_sha256']=hashlib.sha256(('\n'.join(lines[f['start']['line']-1:f['end']['line']])+'\n').encode()).hexdigest()
(out/'selected.json').write_text(json.dumps(rows,indent=2)+'\n')
pattern='^(?:'+'|'.join(re.escape(r['name']) for r in rows)+')$'
argv=['cargo','mutants','--cap-lints=false','--copy-target=true','--jobs','4','--jobserver-tasks','8','--build-timeout','600','--timeout','180','--cargo-arg=--lib','--cargo-arg=--locked','--cargo-arg=--offline','--output',str(out),'--re',pattern,'--','--','access::','adapters::execution::','adapters::vaultwarden::tests::preparation_rechecks_each_policy_credential_with_the_real_backend','--skip','preliminary_image_limit_uses_independent_literal_boundaries','--skip','snapshot_contract_accepts_literal_64_mib_pinned_image','--skip','invalid_paths_and_special_sources_fail_without_blocking','--skip','execution_durable_validation_work_is_independent_of_credential_count']
env=os.environ.copy();env.update(TMPDIR='/home/sixtocantolla/.vw-story16-tests.LGlAXW',CARGO_TERM_COLOR='never')
(out/'command.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'env_overrides':{k:env[k] for k in ['TMPDIR','CARGO_TERM_COLOR']}},indent=2)+'\n')
print('Running',len(rows),'generated mutants',flush=True)
start=time.monotonic()
with (out/'run.log').open('w') as stream:p=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
(out/'result.json').write_text(json.dumps({'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-start,3)},indent=2)+'\n')
print((out/'result.json').read_text(),flush=True)

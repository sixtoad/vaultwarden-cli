import json
import os
from pathlib import Path
import subprocess
import tempfile

wrapper = str(Path("scripts/with-secure-test-tmpdir.sh").resolve())
arguments = ["space argument", "", "literal $(false)", "--flag"]
probe = """import json, os, pathlib, stat, sys
root = pathlib.Path(os.environ['TMPDIR'])
assert root.parent == pathlib.Path.home()
assert stat.S_IMODE(root.stat().st_mode) == 0o700
print(json.dumps({'root': str(root), 'args': sys.argv[1:]}))
sys.exit(int(os.environ.get('PROBE_STATUS', '0')))
"""
for status in [0, 37]:
    env = dict(os.environ, PROBE_STATUS=str(status))
    result = subprocess.run([wrapper, "python3", "-c", probe, *arguments], env=env, text=True, capture_output=True)
    assert result.returncode == status, (result.returncode, result.stderr)
    observed = json.loads(result.stdout)
    assert observed['args'] == arguments
    assert not Path(observed['root']).exists()
    print(f"Linux private directory, argument preservation, exit {status}, cleanup: passed")
with tempfile.TemporaryDirectory() as temporary:
    stub = Path(temporary) / 'uname'
    stub.write_text('#!/bin/sh\nprintf Darwin\\n\n')
    stub.chmod(0o755)
    env = dict(os.environ, PATH=temporary + os.pathsep + os.environ['PATH'], TMPDIR=temporary)
    result = subprocess.run([wrapper, 'python3', '-c', 'import os,sys; print(os.environ["TMPDIR"]); sys.exit(23)'], env=env, text=True, capture_output=True)
    assert result.returncode == 23, result.stderr
    assert result.stdout.strip() == temporary
    print('Non-Linux dispatch with unchanged TMPDIR and exit status: passed (simulated uname)')
with tempfile.TemporaryDirectory(prefix='.vw-wrapper-negative-', dir=Path.home()) as temporary:
    safe = Path(temporary) / 'safe'
    safe.mkdir(mode=0o700)
    link = Path(temporary) / 'link'
    link.symlink_to(safe, target_is_directory=True)
    unsafe = Path(temporary) / 'unsafe'
    unsafe.mkdir(mode=0o700)
    unsafe.chmod(0o777)
    for home in [str(link), str(link) + '///', str(unsafe), '/tmp']:
        env = dict(os.environ, HOME=home)
        result = subprocess.run([wrapper, 'python3', '-c', 'print("unexpected command")'], env=env, text=True, capture_output=True)
        assert result.returncode == 2, (home, result.returncode, result.stderr)
        assert not result.stdout
    print('Symlink, repeated trailing slash, unsafe mode and shared /tmp ancestry: rejected')

import json,re,pathlib
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
out=pathlib.Path('/tmp/vw-story16-review1-final-verification')
rows=json.loads((root/'docs/implementation/1-6-evidence/matrix-audit.json').read_text())
old='execution_preparation_retains_bytes_without_consuming_approval_or_resolving'
new='execution_preparation_retains_capability_without_consuming_approval_or_resolving'
for r in rows:r['tests']=[n.replace(old,new) for n in r['tests']]
rows[0]['tests'].append('access::direct_request_tests::execution_application_integrates_real_owned_linux_preparation')
rows[4]['tests'] += ['access::direct_request_tests::'+n for n in ['execution_failed_durable_reads_still_clear_invalidated_authority','execution_failed_request_expiry_write_still_clears_invalidated_authority','execution_final_durable_validation_rejects_edits_during_backend_work']]
rows[14]['tests'] += ['adapters::execution::linux::tests::'+n for n in ['elf_userspace_profiles_have_independent_literal_bounds_and_rounding','elf_userspace_high_load_is_rejected_with_matching_hash_and_valid_entry','elf_userspace_end_and_entry_boundaries_have_matching_hashes','elf_userspace_boundaries_account_for_supported_page_rounding']]
rows += [
 {'acceptance_behavior':'Every particular policy-bound credential, required field and operation marker is checked by the actual backend','tests':['adapters::vaultwarden::tests::preparation_rechecks_each_policy_credential_with_the_real_backend'],'explicitly_invoked_fixtures':[]},
 {'acceptance_behavior':'Durable registry validation work remains independent of credential count','tests':['access::direct_request_tests::execution_durable_validation_work_is_independent_of_credential_count'],'explicitly_invoked_fixtures':[]},
]
logs={'stable_passed':(out/'stable-1.log').read_text(),'rust_1_88_passed':(out/'msrv-0.log').read_text()}
for r in rows:
 for field,log in logs.items():
  r[field]=all(re.search(r'^test '+re.escape(t)+r' \.\.\. ok$',log,re.M) for t in r['tests'])
  assert r[field],(field,r['acceptance_behavior'])
(out/'matrix-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'rows;',len({n for r in rows for n in r['tests']}),'distinct tests passed on both toolchains')

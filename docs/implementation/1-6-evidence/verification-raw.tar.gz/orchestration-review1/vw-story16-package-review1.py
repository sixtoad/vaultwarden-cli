from pathlib import Path
import json,hashlib,collections,tarfile,runpy,shutil
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable');out=root/'docs/implementation/1-6-evidence';base=Path('/tmp');backup=base/'vw-story16-review1-preserve'
read=lambda p:json.loads(p.read_text())
classification=base/'vw-story16-review1-classification';summary=read(classification/'summary.json');assert not summary['unresolved']
generated=read(classification/'generated-results.json');manual=read(classification/'manual-results.json')
rows=[]
for r in read(base/'vw-story16-review1-retention/production-ranges.json'):
 oldlines=(backup/r['file']).read_text().splitlines(True);body=''.join(oldlines[r['first_line']-1:r['last_line']]);text=(root/r['file']).read_text();assert text.count(body)==1,r
 first=text[:text.index(body)].count('\n')+1
 rows.append({**r,'first_line':first,'last_line':first+body.count('\n')-1,'historical_first_line':r['first_line'],'historical_last_line':r['last_line']})
seen=set()
for r in read(base/'vw-story16-review1-mutants-final/selected.json'):
 f=r['function'];key=(r['file'],f['function_name'])
 if key in seen:continue
 seen.add(key);span=f['span'];body='\n'.join((root/r['file']).read_text().splitlines()[span['start']['line']-1:span['end']['line']])+'\n';digest=hashlib.sha256(body.encode()).hexdigest();assert digest==r['whole_function_sha256']
 rows.append({'file':r['file'],'function':f['function_name'],'first_line':span['start']['line'],'last_line':span['end']['line'],'sha256':digest,'freshly_mutated_after_review1':True})
assert len(rows)==44,len(rows)
provenance={**read(base/'vw-story16-review1-retention/summary.json'),'production_provenance':rows,'manual_patch_proof':read(base/'vw-story16-review1-retention/manual-source-proof.json'),'limits':'Retained results concern exact unchanged production bodies/constant fragments, with their original named failure oracles passing in both final ordinary suites. These are not described as rerun; every changed function was refreshed. Historical names/line positions remain in raw logs; current source ranges are mapped here.'}
compiler=[r for r in generated if r['classification']=='compiler-rejected']
for name,d in [('mutation-summary',summary),('compiler-rejections',compiler),('mutation-source-provenance',rows),('retained-result-provenance',provenance)]:
 (out/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
groups=collections.OrderedDict()
for r in generated+manual:
 if r['classification'].startswith('equivalent'):groups.setdefault((r['classification'],r['evidence']),[]).append(r.get('name',r.get('id')))
text=f'''# Story 1.6 mutation survivor classifications\n\nAll {summary['combined']['documented_equivalent_or_redundant']} surviving distinct mutations are listed below. Equivalence is scoped to\nthe enforced input domain and approved preparation/race contract described in each\nentry. This does not claim identical timing, internal bookkeeping or conservative\nrejection behavior. Disjoint-bit OR/XOR cases are exact mathematical equivalences.\n\nThe {len(compiler)} compiler-rejected mutants are separate from these survivors and from the\n{summary['combined']['caught']} named-test failures. They are not counted as security checks caught by tests.\nHistorical line positions identify retained raw results; current production ranges\nare recorded in the provenance JSON. Changed functions were freshly mutated.\n\nRaw patches, logs, commands and per-mutant classifications are in\n[verification-raw.tar.gz](1-6-evidence/verification-raw.tar.gz).\n'''
for i,((category,evidence),names) in enumerate(groups.items(),1):
 text+=f'\n## {i}. {category}\n\n{evidence}\n\n'+''.join(f'- `{n}`\n' for n in names)
(root/'docs/implementation/1-6-mutation-classifications.md').write_text(text)
# Preserve previous raw campaign records and add current completed results, avoiding recursive archives/build trees.
namespace=runpy.run_path('/tmp/vw-story16-package-evidence.py')
archive=out/'verification-raw.tar.gz';old=base/'vw-story16-pre-review-raw.tar.gz';shutil.copy2(archive,old)
inputs={
 'review1-ordinary':base/'vw-story16-review1-final-verification',
 'review1-generated':base/'vw-story16-review1-mutants-final',
 'review1-manual':base/'vw-story16-review1-manual-final',
 'review1-boundary':base/'vw-story16-review1-boundary-final',
 'review1-infrastructure-rerun':base/'vw-story16-review1-infrastructure-final',
 'review1-retention':base/'vw-story16-review1-retention',
 'review1-classification':classification,
 'excluded-review1-expensive-baseline':base/'vw-story16-review1-mutants-excluded-expensive-baseline',
 'review1-earlier-ordinary':base/'vw-story16-review1-verification',
}
assert read(inputs['review1-generated']/'mutants.out/outcomes.json')['end_time']
assert len(read(inputs['review1-manual']/'results.json'))==25
assert len(read(inputs['review1-boundary']/'results.json'))==6
assert len(read(inputs['review1-infrastructure-rerun']/'results.json'))==3
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 with tarfile.open(old,'r:gz') as previous:
  for member in previous:
   if member.isfile():tar.addfile(member,previous.extractfile(member))
 for label,directory in inputs.items():
  for p in sorted(directory.rglob('*')):
   relative=p.relative_to(directory)
   if any(part in ['target','workspace','.git'] for part in relative.parts):continue
   if p.is_file():tar.add(p,arcname=str(Path(label)/relative),recursive=False)
 for p in sorted(base.glob('vw-story16-*review1*.py')):
  tar.add(p,arcname='orchestration-review1/'+p.name,recursive=False)
 for n in ['vw-story16-review1-manual-manifest.json','vw-story16-review1-boundary-manifest.json','vw-story16-review1-infrastructure-manifest.json','vw-story16-test-wrapper.py']:
  p=base/n
  if p.exists():tar.add(p,arcname='orchestration-review1/'+p.name,recursive=False)
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Packaged current source ranges',len(rows),'archive bytes',archive.stat().st_size)

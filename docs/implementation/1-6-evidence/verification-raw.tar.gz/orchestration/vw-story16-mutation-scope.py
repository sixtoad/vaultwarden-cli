import json,pathlib,re,hashlib
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
out=pathlib.Path('/tmp/vw-story16-verification')
items=json.loads((out/'all-mutants.json').read_text())
wanted={
 'src/access/application.rs':{'ProviderApplication::prepare_execution','ProviderApplication::execution_authority','ProviderApplication::admit','ProviderApplication::check_owner','ProviderApplication::expire_requests'},
 'src/access/provider.rs':{'Provider::approved_execution'},
 'src/access/policy.rs':{'ApprovedImage::validate_integrity','OperationPolicy::from_draft','OperationPolicy::image_matches','OperationPolicy::execution_image','OperationPolicy::validate_integrity','<impl TryFrom<StoredOperationPolicy> for OperationPolicy>::try_from','executable_identity_matches','revision_for','valid_image_path','nonsymlink_regular','OperationPolicy::normalize_args','OperationPolicy::validates_args'},
 'src/access/ports.rs':{'<impl fmt::Display for ExecutionError>::fmt'},
}
selected=[]
for row in items:
 f=row['file']; fn=row['function']; lines=(root/f).read_text().splitlines()
 if f=='src/adapters/execution.rs' or (fn and fn['function_name'] in wanted.get(f,set())) or (f=='src/access/policy.rs' and fn is None and 'MAX_PRELIMINARY_IMAGE_BYTES' in lines[row['span']['start']['line']-1]):
  selected.append(row)
  if fn:
   s,e=fn['span']['start']['line'],fn['span']['end']['line']
   row['whole_function_sha256']=hashlib.sha256(('\n'.join(lines[s-1:e])+'\n').encode()).hexdigest()
(out/'mutation-inventory.json').write_text(json.dumps(selected,indent=2)+'\n')
# Exact list-name selection avoids missing mutations elsewhere in a changed body.
pattern='^(?:'+'|'.join(re.escape(row['name']) for row in selected)+')$'
(out/'mutation-filter.txt').write_text(pattern)
print('Scoped inventory:',len(selected))
from collections import Counter
print(dict(Counter(row['file'] for row in selected)))

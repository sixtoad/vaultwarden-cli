import json, pathlib, subprocess, os, time
root='/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable'
out=pathlib.Path('/tmp/vw-story16-mutation-campaign');out.mkdir(exist_ok=True)
pattern=pathlib.Path('/tmp/vw-story16-verification/mutation-filter.txt').read_text()
argv=['cargo','mutants','--cap-lints=false','--copy-target=true','--jobs','4','--jobserver-tasks','8','--build-timeout','600','--timeout','60','--cargo-arg=--lib','--cargo-arg=--locked','--cargo-arg=--offline','--output',str(out),'--re',pattern,'--','--','access::','adapters::execution::']
env=os.environ.copy();env.update(TMPDIR='/home/sixtocantolla/.vw-story16-tests.LGlAXW',CARGO_TERM_COLOR='never')
(out/'command.json').write_text(json.dumps({'argv':argv,'cwd':root,'env_overrides':{k:env[k] for k in ['TMPDIR','CARGO_TERM_COLOR']}},indent=2))
start=time.time()
with (out/'run.log').open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'result.json').write_text(json.dumps({'exit_code':r.returncode,'elapsed_seconds':round(time.time()-start,3)}))
print((out/'result.json').read_text())

import json,pathlib,subprocess,os,time,re,sys
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
out=pathlib.Path('/tmp/vw-story16-generated-refinements');out.mkdir(exist_ok=True)
old=json.loads(pathlib.Path('/tmp/vw-story16-mutation-campaign/mutants.out/outcomes.json').read_text())
assert old['end_time'], 'Initial campaign must finish first'
equivalent={x['match'] for x in json.loads(pathlib.Path('/tmp/vw-story16-mutation-triage.json').read_text())}
boundary={
'src/access/policy.rs:442:25: replace > with == in executable_identity_matches',
'src/access/policy.rs:465:26: replace > with == in executable_identity_matches',
'src/access/policy.rs:26:52: replace * with +',
'src/access/policy.rs:26:45: replace * with +',
'src/access/policy.rs:442:25: replace > with >= in executable_identity_matches',
'src/access/policy.rs:446:58: replace + with - in executable_identity_matches',
'src/access/policy.rs:464:23: replace += with *= in executable_identity_matches',
'src/access/policy.rs:465:26: replace > with >= in executable_identity_matches',
'src/adapters/execution.rs:299:70: replace + with - in linux::snapshot',
'src/adapters/execution.rs:303:23: replace > with == in linux::snapshot',
'src/adapters/execution.rs:303:23: replace > with >= in linux::snapshot',
}
selected=[x['scenario']['Mutant']['name'] for x in old['outcomes'] if x['summary'] in ['MissedMutant','Timeout'] and x['scenario']['Mutant']['name'] not in equivalent|boundary]
(out/'selected-names.json').write_text(json.dumps(selected,indent=2))
(out/'boundary-names.json').write_text(json.dumps(sorted(boundary),indent=2))
pattern='^(?:'+'|'.join(re.escape(s) for s in selected)+')$'
argv=['cargo','mutants','--cap-lints=false','--copy-target=true','--jobs','4','--jobserver-tasks','8','--build-timeout','600','--timeout','180','--cargo-arg=--lib','--cargo-arg=--locked','--cargo-arg=--offline','--output',str(out),'--re',pattern,'--','--','access::','adapters::execution::','--skip','preliminary_image_limit_uses_independent_literal_boundaries','--skip','snapshot_contract_accepts_literal_64_mib_pinned_image','--skip','invalid_paths_and_special_sources_fail_without_blocking']
env=os.environ.copy();env.update(TMPDIR='/home/sixtocantolla/.vw-story16-tests.LGlAXW',CARGO_TERM_COLOR='never')
(out/'command.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'env_overrides':{k:env[k] for k in ['TMPDIR','CARGO_TERM_COLOR']}},indent=2))
start=time.monotonic()
with (out/'run.log').open('w') as stream:p=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
(out/'result.json').write_text(json.dumps({'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-start,3)}))
print((out/'result.json').read_text())

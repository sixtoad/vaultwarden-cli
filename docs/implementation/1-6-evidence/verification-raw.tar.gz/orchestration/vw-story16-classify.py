import pathlib,json,collections,re
base=pathlib.Path('/tmp');out=base/'vw-story16-final-classification';out.mkdir(exist_ok=True)
initial_dir=base/'vw-story16-mutation-campaign';refined_dir=base/'vw-story16-generated-refinements'
initial=json.loads((initial_dir/'mutants.out/outcomes.json').read_text());refined=json.loads((refined_dir/'mutants.out/outcomes.json').read_text())
assert initial['end_time'] and refined['end_time'], 'Wait for all generated checks'
initial_audit={r['name']:r for r in json.loads((initial_dir/'assertion-audit.json').read_text())};refined_audit={r['name']:r for r in json.loads((refined_dir/'assertion-audit.json').read_text())}
triage={r['match']:r for r in json.loads((base/'vw-story16-mutation-triage.json').read_text())}
boundaries={}
for campaign in ['generated-boundary-reruns','generated-boundary-extra-reruns']:
 folder=base/('vw-story16-'+campaign);manifest={r['id']:r for r in json.loads((folder/'manifest.json').read_text())}
 for r in json.loads((folder/'results.json').read_text()):boundaries[manifest[r['id']]['original_generated_name']]={**r,'campaign':campaign}
rows=[];unresolved=[]
for name,original in initial_audit.items():
 r={'name':name,'initial_outcome':original['summary']}
 if name in boundaries:
  b=boundaries[name];assert b['classification']=='caught' and b['failed_tests'],name
  r.update(classification='caught',campaign=b['campaign'],failed_tests=b['failed_tests'],build=b['build'],test=b['test'])
 else:
  current=refined_audit.get(name,original);r.update(campaign='generated-refinements' if name in refined_audit else 'initial-generated',log_path=current['log_path'],diff_path=current['diff_path'],phase_results=current['phase_results'])
  if current['summary']=='CaughtMutant':
   assert current['failed_tests'],name;r.update(classification='caught',failed_tests=current['failed_tests'])
  elif current['summary']=='Unviable':
   assert current['compiler_errors'],name;r.update(classification='compiler-rejected',compiler_errors=current['compiler_errors'])
  elif current['summary']=='MissedMutant' and name in triage:
   t=triage[name];r.update(classification=t['classification'],evidence=t['evidence'])
  else:r.update(classification='unresolved');unresolved.append(name)
 rows.append(r)
assert len(rows)==496
(out/'generated-results.json').write_text(json.dumps(rows,indent=2)+'\n')
manual=json.loads((base/'vw-story16-manual-final.json').read_text())
for r in manual:
 if r['classification']=='survived':
  assert r['id'] in ['auth_before_each_credential','auth_final']
  r['classification']='equivalent-to-preparation-authority-contract'
  r['evidence']='The prior post-probe check (or prior post-eligibility check for later credentials) revalidates the exact same authority before the next call. The final post-eligibility check (or post-probe check when there are no credentials) revalidates before returning. Between adjacent checks only owned immutable policy/marker/iterator/boolean work occurs while holding the authority gate; no external call or approval consumption is introduced. Required before/after-I/O and exact-binding checks remain. The extra retained checks can observe asynchronous closure, deadline passage, or a store failure sooner, so this is NOT strict observational equivalence. Prepared bytes grant no dispatch authority; Story1.7 must revalidate and consume authority before secrets/dispatch. Removal of every nonredundant neighboring check is caught by the named invalidation/failure tests.'
 elif r['classification']=='caught':assert r['failed_tests'],r['id']
 else:raise AssertionError(r)
(out/'manual-results.json').write_text(json.dumps(manual,indent=2)+'\n')
summary={'generated_inventory':496,'generated_initial':{k:initial[k] for k in ['caught','missed','timeout','unviable']},'generated_refinement':{k:refined[k] for k in ['total_mutants','caught','missed','timeout','unviable']},'boundary_reruns':len(boundaries),'generated_final':dict(collections.Counter(r['classification'] for r in rows)),'manual_distinct':len(manual),'manual_final':dict(collections.Counter(r['classification'] for r in manual)),'unresolved':unresolved,'counts_are_distinct_mutations_not_attempts':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if unresolved:raise SystemExit(1)

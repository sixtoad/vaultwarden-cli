import pathlib,json,re,collections,sys
base=pathlib.Path(sys.argv[1]);data=json.loads((base/'outcomes.json').read_text());audit=[]
for outcome in data['outcomes']:
 mutant=outcome['scenario'].get('Mutant') if isinstance(outcome['scenario'],dict) else None
 if not mutant:continue
 log=(base/outcome['log_path']).read_text();failed=re.findall(r'^test (.+?) \.\.\. FAILED$',log,re.M)
 errors=re.findall(r'^error(?:\[[^]]+\])?:[^\n]+',log,re.M)
 panics=re.findall(r"panicked at[^\n]*\n([^\n]*(?:\n[^\n]*)?)",log)
 row={'name':mutant['name'],'summary':outcome['summary'],'failed_tests':failed,'compiler_errors':errors,'panic_excerpts':panics,'log_path':outcome['log_path'],'diff_path':outcome['diff_path'],'phase_results':outcome['phase_results']}
 row['needs_inspection']=outcome['summary']=='CaughtMutant' and not failed
 audit.append(row)
(base.parent/'assertion-audit.json').write_text(json.dumps(audit,indent=2))
print(dict(collections.Counter(r['summary'] for r in audit)))
print('Caught without named assertions:',[r['name'] for r in audit if r['needs_inspection']])
print('Unique failing tests',len({t for r in audit for t in r['failed_tests']}))

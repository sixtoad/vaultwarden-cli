import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
out=pathlib.Path('/tmp/vw-story16-review2-final-verification');out.mkdir(exist_ok=True)
mode=sys.argv[1]
env=os.environ.copy()
env['TMPDIR']='/home/sixtocantolla/.vw-story16-tests.LGlAXW'
env['CARGO_TERM_COLOR']='never'
def fingerprint():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src','tests','scripts','justfile','.github/workflows/ci.yml','Cargo.toml','Cargo.lock'],cwd=root,text=True).splitlines()
 return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (root/n).is_file()}
before=fingerprint()
(out/(mode+'-source-before.json')).write_text(json.dumps(before,indent=2)+'\n')
if mode=='stable':
 env['CARGO_TARGET_DIR']='/tmp/vw-story16-refinement-target'
 commands=[['cargo','fmt','--all','--','--check'],['cargo','test','--all-targets','--locked','--offline'],['cargo','clippy','--all-targets','--all-features','--locked','--offline','--','-D','warnings']]
elif mode=='msrv':
 env['RUSTUP_HOME']='/tmp/vw-story16-rustup'
 env['CARGO_TARGET_DIR']=str(root/'target'/'msrv188')
 commands=[['rustup','run','1.88.0','cargo','test','--all-targets','--locked','--offline']]
else:
 raise SystemExit('unsupported verification mode')
results=[]
for i,cmd in enumerate(commands):
 log=out/(mode+'-'+str(i)+'.log')
 start=time.time()
 print('Running '+repr(cmd)+'; log='+str(log),flush=True)
 with log.open('w') as stream:
  p=subprocess.run(['./scripts/with-secure-test-tmpdir.sh',*cmd],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 r={'argv':['./scripts/with-secure-test-tmpdir.sh',*cmd],'cwd':str(root),'env_overrides':{k:env[k] for k in ('TMPDIR','CARGO_TERM_COLOR','RUSTUP_HOME','CARGO_TARGET_DIR') if k in env and (k not in os.environ or env[k]!=os.environ[k])},'log':str(log),'exit_code':p.returncode,'elapsed_seconds':round(time.time()-start,3)}
 results.append(r)
 (out/(mode+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(r),flush=True)
 if p.returncode:
  break
after=fingerprint()
(out/(mode+'-source-after.json')).write_text(json.dumps(after,indent=2)+'\n')
print('Source fingerprints unchanged:',before==after,flush=True)
raise SystemExit(0 if before==after and all(r['exit_code']==0 for r in results) else 1)

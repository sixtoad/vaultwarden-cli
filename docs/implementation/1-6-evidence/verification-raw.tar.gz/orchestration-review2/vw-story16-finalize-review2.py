from pathlib import Path
import json,re,hashlib,tarfile,shutil,collections
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable')
base=Path('/tmp');out=root/'docs/implementation/1-6-evidence';runs=base/'vw-story16-review2-final-verification'
read=lambda p:json.loads(p.read_text())
write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n')
results=read(runs/'stable-results.json')+read(runs/'msrv-results.json')
assert len(results)==4 and all(r['exit_code']==0 for r in results)
fingerprints=[read(runs/(n+'-source-'+s+'.json')) for n in ['stable','msrv'] for s in ['before','after']]
assert len(fingerprints[0])==68 and all(f==fingerprints[0] for f in fingerprints)
for n,h in fingerprints[0].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
old=read(out/'verified-input-sha256.json'); assert set(old)==set(fingerprints[0])
changed=[n for n in old if old[n]!=fingerprints[0][n]]
assert changed==['src/adapters/execution/linux/tests.rs'],changed
logs=[(runs/n).read_text() for n in ['stable-1.log','msrv-0.log']]
for log in logs:
 counts=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)
 assert len(counts)==15 and sum(int(x[0]) for x in counts)==774 and all(x[1]=='0' for x in counts),counts
 assert counts[0]==('518','0','9'),counts[0]
 assert len(re.findall(r'^Success$',log,re.M))==13
ordinary=read(out/'ordinary-results.json');ordinary['commands']=results
ordinary['counts'].update(reported_passes_per_toolchain=774,non_live_tests_executed_per_toolchain=703,library_passes_per_toolchain=518)
ordinary['prior_failed_attempt']={'archive':'review2-msrv-first-attempt/','exit_code':101,'elapsed_seconds':159.115,'failure':'Existing fixed_system_launcher_uses_only_an_isolated_desktop_association: isolated child returned ReviewUnavailable at its two-second timeout while stable and MSRV ran concurrently. Full MSRV rerun alone passed without source changes; timeout under load is an inference, not proof of cause.'}
write(out/'ordinary-results.json',ordinary);write(out/'verified-input-sha256.json',fingerprints[0])
rows=read(out/'matrix-audit.json');test='adapters::execution::linux::tests::full_preparer_rejects_each_unsafe_execution_root_ancestor_permission'
assert test not in {n for r in rows for n in r['tests']}
rows[7]['tests'].append(test)
for r in rows:
 for key,log in zip(['stable_passed','rust_1_88_passed'],logs):
  r[key]=all(re.search(r'^test '+re.escape(t)+r' \.\.\. ok$',log,re.M) for t in r['tests']);assert r[key],r
assert len(rows)==19 and len({n for r in rows for n in r['tests']})==66
write(out/'matrix-audit.json',rows);write(runs/'matrix-audit.json',rows)
live_times=[]
for log in logs:
 m=re.search(r'test result: ok\. 71 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in ([0-9.]+)s',log);assert m
 live_times.append(m[1])
live=read(out/'live-test-accounting.json');live['evidence']=f'tests/live/env.rs:118-119 returns None without the two account environment variables; all 71 tests return early. Final stable live suite elapsed {live_times[0]}s; Rust 1.88 elapsed {live_times[1]}s. No live account execution claimed.';write(out/'live-test-accounting.json',live)
# Audit the completed previous mutation inventory against current ordinary oracles; production is unchanged.
parents={
'execution_child':'descriptor_execution_subprocess','cleanup_child':'descriptor_cleanup_subprocess','required_syscall_flag_child':'preparation_explicitly_requests_executable_memfd_and_no_controlling_terminal','syscall_failure_child':'unavailable_memfd_and_sealing_syscalls_close_resources','descriptor_zero_child':'descriptor_zero_is_valid_for_open_and_snapshot_subprocess'}
parents={'adapters::execution::linux::tests::'+k:'adapters::execution::linux::tests::'+v for k,v in parents.items()}
parents['access::policy::tests::preliminary_open_flags_child']='access::policy::tests::preliminary_open_flags_are_required_by_the_syscall_contract'
generated=read(base/'vw-story16-review1-classification/generated-results.json');manual=read(base/'vw-story16-review1-classification/manual-results.json')
oracles=set()
for r in generated+manual:
 for name in r.get('failed_tests',[]):
  n=parents.get(name,name.replace('execution_preparation_retains_bytes_without_consuming_approval_or_resolving','execution_preparation_retains_capability_without_consuming_approval_or_resolving'));oracles.add(n)
for n in oracles: assert all(re.search(r'^test '+re.escape(n)+r' \.\.\. ok$',log,re.M) for log in logs),n
for r in read(out/'mutation-source-provenance.json'):
 body='\n'.join((root/r['file']).read_text().splitlines()[r['first_line']-1:r['last_line']])+'\n';assert hashlib.sha256(body.encode()).hexdigest()==r['sha256'],r
new=read(base/'vw-story16-review2-manual-final/results.json');assert len(new)==1 and new[0]['classification']=='caught' and new[0]['failed_tests']==[test]
assert new[0]['build']['exit_code']==0 and new[0]['test']['exit_code']==101
assert 'on an `Ok` value: PreparedExecutable([REDACTED])' in Path(new[0]['test']['log']).read_text()
assert not any(r['id']==new[0]['id'] for r in manual)
manual+=new
summary=read(out/'mutation-summary.json');summary.update(manual_distinct=79,manual_review2_added=1)
summary['manual_final']['caught']=77;summary['combined']['caught']=520
summary['review2_retention']={'previous_distinct_results_retained':584,'unchanged_production':True,'only_verified_input_changed':'src/adapters/execution/linux/tests.rs','original_named_oracles_passing_current_suites':len(oracles),'new_manual_caught':1}
write(out/'mutation-summary.json',summary)
classification=base/'vw-story16-review2-classification';classification.mkdir(exist_ok=True)
for n,d in [('generated-results',generated),('manual-results',manual),('summary',summary)]:write(classification/(n+'.json'),d)
proof={'unchanged_production_ranges':44,'previous_584_results_retained_not_rerun':True,'prior_named_oracles_passing_both_current_suites':sorted(oracles),'changed_verified_inputs':changed,'new_manual_caught':new[0]['id']};write(classification/'retention-proof.json',proof)
p=root/'docs/implementation/1-6-mutation-classifications.md';s=p.read_text();assert '519 named-test failures' in s;s=s.replace('519 named-test failures','520 named-test failures');p.write_text(s)
p=root/'docs/implementation/1-6-test-evidence.md';s=p.read_text()
s=s.replace('Status: implementation and required verification complete; fresh workflow reviews\nand human acceptance pending.', 'Status: implementation, required verification and all three workflow review layers\ncomplete; human acceptance pending.')
s=s.replace('after the architecture\nbound-helper refinement','after the final review\nregression test and documentation corrections')
for a,b in [('0.521 s','2.736 s'),('175.415 s','197.186 s'),('9.356 s','5.680 s'),('175.898 s',str(results[3]['elapsed_seconds'])+' s'),('review1-ordinary/','review2-ordinary/'),('/tmp/vw-story16-review1-final-verification/','/tmp/vw-story16-review2-final-verification/'),('**773 passes','**774 passes'),('**702 non-live','**703 non-live'),('| Library (`src/lib.rs`) | 517 |','| Library (`src/lib.rs`) | 518 |'),('773 reported passes','774 reported passes'),('65 distinct tests','66 distinct tests'),('65 distinct passing tests','66 distinct passing tests'),('and 78 manual distinct mutations','and 79 manual distinct mutations'),('| Manual: 78 | 76 |','| Manual: 79 | 77 |'),('| Total: 584 | 519 |','| Total: 585 | 520 |')]:s=s.replace(a,b)
s=s.replace('Their suite took 0.02s on stable and 0.00s on Rust 1.88.',f'Their suite took {live_times[0]}s on stable and {live_times[1]}s on Rust 1.88.')
s=s.replace('`directory_ownership_and_ancestor_permissions_are_independent` |','`directory_ownership_and_ancestor_permissions_are_independent`; `full_preparer_rejects_each_unsafe_execution_root_ancestor_permission` uses a safe positive then independently adds each unsafe intermediate-ancestor permission bit |')
needle='## Historical pre-review ordinary verification'
s=s.replace(needle,'''The first final Rust 1.88 attempt failed (exit 101, 159.115 s) in the existing
`fixed_system_launcher_uses_only_an_isolated_desktop_association` test: its child
returned `ReviewUnavailable` at the production two-second deadline while both
toolchain suites ran concurrently. The entire Rust 1.88 suite was rerun alone and
passed without source changes. Load-related timeout is an inference, not a proven
cause. The failed attempt is preserved under `review2-msrv-first-attempt/` and is
not counted as successful verification.

'''+needle)
needle='Historical raw evidence includes the original 496-case generated campaign,'
s=s.replace(needle,'''The final review added one full-preparer ancestor permission test and documentation
corrections; production code was unchanged. The new manual mutation removes the
entire metadata guard inside execution-root ancestry traversal while leaving the
separate root/descendant guard intact. It compiled (exit 0, 15.585 s) and the new
test failed (exit 101, 1.689 s) because unsafe preparation returned a capability.
The safe positive and all five independent unsafe permission cases pass unmutated.
This adds one catch to the prior 584 distinct results. Those results were retained,
not rerun: all 44 production ranges match their recorded hashes, and all their
named failure oracles pass in both final ordinary suites. The proof and consolidated
585-case inventory are archived under `review2-classification/`.

'''+needle)
s=s.replace('No commit, push or pull request is authorized. Workflow reviews remain pending.', '''## Workflow review outcome

All three context-free review layers completed. The edge-case review returned no
findings. The accepted documentation precision and full-preparer ancestor coverage
findings were patched and verified. Individual verdicts and carried/rejected
findings are recorded in the build spec's review triage log.

One medium pre-existing performance item was deferred: durable snapshot validation
rehashes image bindings repeatedly. Preparation now performs three durable reads
independent of credential count, but a single-operation example still hashes fifteen
image-lengths. Large registries can delay callers including Lock while the authority
gate is held. This is documented in `docs/access-mvp.md` and the shared deferred-work
log; this change does not claim to solve per-snapshot duplication or policy-count
scaling. ELF checks cover selected execution structures, not all auxiliary ABI
metadata; unused null-section/name-table semantics are not certified.

No commit, push or pull request has been made. Human acceptance remains pending.''')
p.write_text(s)
# Preserve historical raw evidence and append current final results, including the failed attempt.
archive=out/'verification-raw.tar.gz';oldarchive=base/'vw-story16-pre-review2-raw.tar.gz';shutil.copy2(archive,oldarchive)
inputs={'review2-ordinary':runs,'review2-msrv-first-attempt':base/'vw-story16-review2-msrv-first-attempt','review2-manual':base/'vw-story16-review2-manual-final','review2-classification':classification}
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 with tarfile.open(oldarchive,'r:gz') as previous:
  for member in previous:
   if member.isfile():tar.addfile(member,previous.extractfile(member))
 for label,directory in inputs.items():
  for q in sorted(directory.rglob('*')):
   rel=q.relative_to(directory)
   if q.is_file() and not any(x in ['target','workspace','.git'] for x in rel.parts):tar.add(q,arcname=str(Path(label)/rel),recursive=False)
 for n in ['vw-story16-verify-review2-final.py','vw-story16-run-review2-manual.py','vw-story16-review2-manual-manifest.json','vw-story16-finalize-review2.py','vw-story16-ancestor-regression.log']:
  tar.add(base/n,arcname='orchestration-review2/'+n,recursive=False)
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(q.read_bytes()).hexdigest()+'  '+q.name+'\n' for q in sorted(out.iterdir()) if q.is_file() and q.name!='SHA256SUMS'))
print(json.dumps({'counts':ordinary['counts'],'mutations':summary['combined'],'previous_named_oracles_revalidated':len(oracles),'archive_bytes':archive.stat().st_size,'msrv_elapsed':results[3]['elapsed_seconds']},indent=2))

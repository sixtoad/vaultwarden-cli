from pathlib import Path
import json,subprocess,difflib,shutil
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-decide-request');copy=Path('/tmp/story15-manual-workspace');out=Path('/tmp/story15-mutation-campaign/closed-audit-manual');out.mkdir(exist_ok=True);shutil.copy2(root/'src/access/direct_request_tests.rs',copy/'src/access/direct_request_tests.rs');path=copy/'src/access/provider.rs';original=path.read_text();results=[]
for name,old,new in [('denied-outcome','(DirectStatus::Denied, DecisionOutcome::Denied)','(DirectStatus::Denied, DecisionOutcome::Approved)'),('expired-outcome','super::direct_request::DecisionOutcome::Expired,','super::direct_request::DecisionOutcome::Denied,')]:
 mutated=original.replace(old,new,1);assert mutated!=original;path.write_text(mutated);(out/(name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True),fromfile='src/access/provider.rs',tofile='src/access/provider.rs')));args=['cargo','test','--lib','decision_denied_and_clock_expired_audits_bind_exact_redacted_metadata']
 try:
  with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=copy,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 finally:path.write_text(original)
 text=(out/(name+'.log')).read_text();classification='caught' if 'test result: FAILED' in text and 'assertion `left == right` failed' in text else 'unresolved';results.append(dict(name=name,argv=args,exit_code=p.returncode,classification=classification));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,classification,flush=True)

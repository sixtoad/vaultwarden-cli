import pathlib,subprocess,shutil,json,difflib,os,time
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-decide-request')
copy=pathlib.Path('/tmp/story15-manual-workspace')
out=pathlib.Path('/tmp/story15-mutation-campaign/final-manual');out.mkdir(exist_ok=True)
if not copy.exists():
 shutil.copytree(root,copy,ignore=shutil.ignore_patterns('target','.git','.agents','.codex'))
 subprocess.run(['cp','-a',str(root/'target'),str(copy/'target')],check=True)
T='access::direct_request_tests::'
U='adapters::loopback_ui::tests::'
cases=[]
def case(name,file,old,new,test,occurrence=0,browser=False):cases.append(dict(name=name,file=file,old=old,new=new,test=test,occurrence=occurrence,browser=browser))
direct='src/access/direct_request.rs'
case('password-authentication-bypass',direct,'authenticator\n            .authenticate(password)\n            .map_err(|_error| DirectRequestError::AuthenticationFailed)?;','let _unused = (authenticator, password);',T+'decision_missing_empty_wrong_failed_and_cancelled_authentication_grant_nothing')
for field,old,new in [
 ('request-id','request_id: self.review.id.clone(),','request_id: "A".repeat(43),'),
 ('uid','requester_uid: self.owner_uid,','requester_uid: self.owner_uid + 1,'),
 ('policy','policy_digest: self.review.policy_digest.clone(),','policy_digest: "a".repeat(64),'),
 ('arguments','arguments_digest: self.review.arguments_digest.clone(),','arguments_digest: "a".repeat(64),'),
 ('expiry','expires_at_unix_seconds: self.review.expires_at_unix_seconds,','expires_at_unix_seconds: self.review.expires_at_unix_seconds + 1,'),
 ('epoch','lifecycle_epoch: self.lifecycle_epoch,','lifecycle_epoch: self.lifecycle_epoch + 1,'),
 ('seal','record_digest: self.binding_digest.clone(),','record_digest: "a".repeat(64),')]:case('binding-'+field,direct,old,new,T+'decision_approval_binds_exactly_and_audits_once_without_client_authority')
case('omitted-decision-persistence','src/access/provider.rs','self.store.write_state_guarded(&state, still_authorized)?;','let _unused = still_authorized;',T+'decision_approval_binds_exactly_and_audits_once_without_client_authority')
case('illegal-transition-guard','src/access/provider_store.rs','if !legal {','if false {',T+'decision_transition_matrix_rejects_every_illegal_edge_including_terminal_replays')
case('post-auth-browser-guard','src/adapters/loopback_ui.rs','if !locked.decision_authorized(&request, app) {','if false {',U+'decision_browser_authentication_allows_lock_and_denial_to_finish',1)
case('cross-session-proof','src/adapters/loopback_ui.rs','request.header("x-csrf-token") == Some(session.csrf.expose())','true',U+'decision_browser_guards_are_isolated_against_eligible_requests')
case('browser-proof-enforcement','src/adapters/loopback_ui.rs','request.header("x-csrf-token")\n                != self.browser_session(&request).map(|s| s.csrf.expose())','false','Firefox real-browser missing-CSRF review check',browser=True)
case('browser-password-clearing','src/adapters/loopback_ui.rs',"approvalPassword.value='';",';','Firefox keyboard cancellation/password-clearing check',occurrence=-1,browser=True)
results=[]
for c in cases:
 path=copy/c['file'];original=path.read_text()
 if c['occurrence']==-1:mutated=original.replace(c['old'],c['new'])
 else:
  chunks=original.split(c['old']);assert len(chunks)>c['occurrence']+1,c['name'];i=c['occurrence'];mutated=c['old'].join(chunks[:i+1])+c['new']+c['old'].join(chunks[i+1:])
 assert mutated!=original,c['name']
 (out/(c['name']+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True),fromfile=c['file'],tofile=c['file'])))
 path.write_text(mutated)
 argv=['node','tests/ui/direct-request.mjs'] if c['browser'] else ['cargo','test','--lib',c['test'],'--','--exact']
 env=os.environ.copy();env.update(VW_UI_DEPS='/tmp/vw-story14-browser/node_modules',LD_LIBRARY_PATH='/tmp/vw-story13-nss/extracted/usr/lib/x86_64-linux-gnu')
 started=time.time();print('START '+c['name'],flush=True)
 try:
  with (out/(c['name']+'.log')).open('w') as log:result=subprocess.run(argv,cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
  code=result.returncode;text=(out/(c['name']+'.log')).read_text()
  classification='survived' if code==0 else 'compiler-rejected' if 'could not compile' in text else 'caught' if ('test result: FAILED.' in text or 'AssertionError' in text) else 'unrelated-failure'
 except subprocess.TimeoutExpired:code=None;classification='timeout'
 finally:path.write_text(original)
 results.append({**{k:v for k,v in c.items() if k not in ['old','new']},'argv':argv,'exit_code':code,'classification':classification,'seconds':time.time()-started})
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('DONE '+c['name']+' '+classification,flush=True)
print('MANUAL COMPLETE',flush=True)

import json,pathlib,subprocess,re,hashlib,time,sys
mode=sys.argv[1] if len(sys.argv)>1 else 'library'
root=pathlib.Path('/tmp/story15-manual-workspace') if mode=='binary' else pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-decide-request')
out=pathlib.Path('/tmp/story15-mutation-campaign')
files=sorted([*root.joinpath('src').rglob('*.rs'),*root.joinpath('tests').rglob('*')])
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
(out/('binary-input-sha256.json' if mode=='binary' else 'input-sha256.json')).write_text(json.dumps(manifest,indent=2)+'\n')
mutants=json.loads((out/'inventory.json').read_text())
mode=sys.argv[1] if len(sys.argv)>1 else 'library'
selected=[m for m in mutants if m['file'].startswith('src/bin/')==(mode=='binary')]
regex='^(?:'+'|'.join(re.escape(m['name']) for m in selected)+')$'
args=['cargo','mutants','--no-config','--jobs','4' if mode=='library' else '1','--jobserver-tasks','8','--copy-target','true','--cap-lints','false','--build-timeout','180','--timeout','90','-o',str(out/mode),'-F',regex]
if mode=='library':
 args+=['--cargo-arg=--lib','--','--','--test-threads=4']
 for skip in ['commands::','crypto::','config::','api::','models::','totp::']:args+=['--skip',skip]
else:
 args+=['--in-place','--cargo-arg=--test=provider_session']
 i=args.index('--jobs');del args[i:i+2]
 i=args.index('--copy-target');del args[i:i+2]
(out/(mode+'-command.json')).write_text(json.dumps({'argv':args,'cwd':str(root),'mutants':len(selected)},indent=2)+'\n')
print(f'Starting {mode}: {len(selected)} mutants',flush=True)
result=subprocess.run(args,cwd=root)
(out/(mode+'-exit.json')).write_text(json.dumps({'exit_code':result.returncode,'finished_unix':time.time()})+'\n')
print(f'Completed {mode}: exit={result.returncode}',flush=True)
sys.exit(result.returncode)

import subprocess,json,difflib,collections,pathlib
root=pathlib.Path.cwd()
files=[p for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if p.startswith('src/') and p.endswith('.rs')]
args=['cargo','mutants','--list','--json']
for p in files:args+=['-f',p]
all_mutants=json.loads(subprocess.check_output(args,text=True))
changed={}
for p in files:
 old=subprocess.check_output(['git','show','HEAD:'+p],text=True).splitlines()
 new=pathlib.Path(p).read_text().splitlines()
 changed[p]=[(j1+1,max(j1+1,j2)) for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(None,old,new).get_opcodes() if tag!='equal']
extra={'ProviderApplication::admit','ProviderApplication::check_owner','LoopbackUi::browser_session','LoopbackUi::authenticated'}
selected=[]
for m in all_mutants:
 f=m.get('function');span=f['span'] if f else m['span'];lo,hi=span['start']['line'],span['end']['line']
 if (f and f['function_name'] in extra) or any(a<=hi and b>=lo for a,b in changed[m['file']]):selected.append(m)
out=pathlib.Path('/tmp/story15-mutation-campaign');out.mkdir(exist_ok=True)
(out/'inventory.json').write_text(json.dumps(selected,indent=2)+'\n')
(out/'functions.txt').write_text('\n'.join(f'{n:3} {name}' for name,n in collections.Counter((m['function']['function_name'] if m['function'] else m['name']) for m in selected).items())+'\n')
print(len(selected));print((out/'functions.txt').read_text())

import pathlib,json,subprocess,re,time
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-decide-request');out=pathlib.Path('/tmp/story15-mutation-campaign');mutants=json.loads((out/'final-pending.json').read_text());mutants=[m for m in mutants if not m['file'].startswith('src/bin/')]
args=['cargo','mutants','--no-config','--jobs','4','--jobserver-tasks','16','--copy-target','true','--cap-lints','false','--build-timeout','600','--timeout','120','-o',str(out/'final-library'),'-F','^(?:'+'|'.join(re.escape(m['name']) for m in mutants)+')$','--cargo-arg=--lib','--','--','--test-threads=4']
for skip in ['commands::','crypto::','config::','api::','models::','totp::']:args+=['--skip',skip]
(out/'final-library-command.json').write_text(json.dumps({'argv':args,'cwd':str(root),'mutants':len(mutants)},indent=2)+'\n');print('START',len(mutants),flush=True)
p=subprocess.run(args,cwd=root);(out/'final-library-exit.json').write_text(json.dumps({'exit':p.returncode,'finished':time.time()})+'\n');print('END',p.returncode,flush=True)

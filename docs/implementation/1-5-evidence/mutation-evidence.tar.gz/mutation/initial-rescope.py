import pathlib,json,tarfile,hashlib,re,collections,shutil
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-decide-request');out=pathlib.Path('/tmp/story15-mutation-campaign')
archive=tarfile.open(out/'frozen-source.tar.gz');old={n:archive.extractfile(n).read().decode() for n in archive.getnames() if n.endswith('.rs')}
new={str(p.relative_to(root)):p.read_text() for p in root.joinpath('src').rglob('*.rs')}
def cut(text,span):
 lines=text.splitlines(True);a,b=span['start'],span['end'];return ''.join(lines[a['line']-1:b['line']])[a['column']-1:][:sum(map(len,lines[a['line']-1:b['line']-1]))+b['column']-a['column']]
def key(m,files):
 span=(m.get('function') or m)['span']; start=span['start']; ms=m['span'];return (m['file'],(m.get('function') or {}).get('function_name'),hashlib.sha256(cut(files[m['file']],span).encode()).hexdigest(),ms['start']['line']-start['line'],ms['start']['column']-(start['column'] if ms['start']['line']==start['line'] else 0),ms['end']['line']-start['line'],ms['end']['column'],m['genre'],m['replacement'])
def body(files,name):
 leaf=name.split('::')[-1];found=[]
 for f,s in files.items():
  m=re.search(r'(?m)^( +)(?:async )?fn '+re.escape(leaf)+r'\(',s)
  if m:
   end=re.search(r'(?m)^'+m[1]+r'\}',s[m.end():]);
   if end:found.append(s[m.start():m.end()+end.end()])
 return found[0] if len(found)==1 else None
original=[]
for area in ['library','binary']:
 for result in json.loads((out/area/'mutants.out/outcomes.json').read_text())['outcomes']:
  if 'Mutant' in result['scenario']:original.append((area,result))
lookup={key(r['scenario']['Mutant'],old):(area,r) for area,r in original}
records=[];pending=[]
for m in json.loads((out/'inventory.json').read_text()):
 k=key(m,new);record={'mutant':m,'function_sha256':k[2],'relative_identity':list(k[3:]),'classification':'pending'};match=lookup.get(k)
 if match:
  area,r=match;record['original_result']={'area':area,'name':r['scenario']['Mutant']['name'],'summary':r['summary'],'log_path':r['log_path']}
  if r['summary']=='Unviable':record['classification']='carried-compiler-rejected'
  elif r['summary']=='CaughtMutant':
   log=(out/area/'mutants.out'/r['log_path']).read_text();failed=sorted(set(re.findall(r'test ([\w:]+) \.\.\. FAILED',log)));checks={t:bool(body(old,t) and body(old,t)==body(new,t)) for t in failed};record['failed_test_bodies_unchanged']=checks
   if any(checks.values()):record['classification']='carried-caught'
 if record['classification']=='pending':pending.append(m)
 records.append(record)
(out/'final-scope-map.json').write_text(json.dumps(records,indent=2)+'\n');(out/'final-pending.json').write_text(json.dumps(pending,indent=2)+'\n')
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for base in ['src','tests'] for p in root.joinpath(base).rglob('*') if p.is_file()};(out/'final-input-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'final-frozen-source.tar.gz','w:gz') as tar:
 for base in ['src','tests','Cargo.toml','Cargo.lock']:tar.add(root/base,arcname=base)
print(collections.Counter(r['classification'] for r in records));print('pending',len(pending))

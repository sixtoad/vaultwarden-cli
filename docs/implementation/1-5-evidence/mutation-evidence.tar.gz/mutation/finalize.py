from pathlib import Path
import json,collections,hashlib,re
p=Path('/tmp/story15-mutation-campaign');rows=json.loads((p/'final-scope-map.json').read_text());runs={}
for area in ['final-library','audit-timestamp-rerun','serve-integration','auth-boundary-rerun']:
 outcomes=json.loads((p/area/'mutants.out/outcomes.json').read_text())['outcomes']
 for result in outcomes:
  if 'Mutant' in result['scenario']:runs.setdefault(result['scenario']['Mutant']['name'],[]).append((area,result))
records=[]
for row in rows:
 name=row['mutant']['name'];history=runs.get(name,[]);classification=row['classification'];evidence=[]
 for area,result in history:
  log=(p/area/'mutants.out'/result['log_path']).read_text();evidence.append({'area':area,'summary':result['summary'],'log_path':result['log_path'],'diff_path':result['diff_path'],'log_sha256':hashlib.sha256(log.encode()).hexdigest(),'failed_tests':sorted(set(re.findall(r'test ([\w:]+) \.\.\. FAILED',log))),'phase_results':result['phase_results']})
 if history:
  last=history[-1][1];classification={'CaughtMutant':'caught','Unviable':'compiler-rejected','MissedMutant':'unresolved-survivor','Timeout':'unresolved-timeout'}.get(last['summary'],'unresolved')
 if classification=='carried-caught':classification='caught'
 if classification=='carried-compiler-rejected':classification='compiler-rejected'
 if name=='src/access/application.rs:135:39: replace < with <= in ProviderApplication::expire_requests':
  assert classification=='unresolved-survivor';classification='equivalent';row['equivalence']='Provider::expire_direct persists Expired before the retain predicate runs. At equality <= retains only an already-terminal deadline entry; the next later tick removes it. No pending/approved state or approval binding can be restored by this map cleanup. Exact-deadline, independent session deadline and lifecycle tests pass unchanged.'
 row['final_classification']=classification;row['rerun_evidence']=evidence;records.append(row)
counts=collections.Counter(r['final_classification'] for r in records);assert not any('unresolved' in c or c=='pending' for c in counts),counts;assert len(records)==230
(p/'final-results.json').write_text(json.dumps({'counts':counts,'generated_total':len(records),'manual_total':16,'manual_caught':16,'records':records},indent=2)+'\n');print(counts)

from pathlib import Path
import json,subprocess,re
out=Path('/tmp/story15-mutation-campaign');copy=Path('/tmp/story15-manual-workspace');mutants=[m for m in json.loads((out/'inventory.json').read_text()) if (m.get('function') or {}).get('function_name')=='LoopbackUi::serve'];args=['cargo','mutants','--no-config','--in-place','--cap-lints','false','--build-timeout','600','--timeout','90','-o',str(out/'serve-integration'),'-F','^(?:'+'|'.join(re.escape(m['name']) for m in mutants)+')$','--cargo-arg=--test=direct_request','--cargo-arg=--test=provider_session'];(out/'serve-integration-command.json').write_text(json.dumps({'argv':args,'cwd':str(copy),'mutants':len(mutants)},indent=2)+'\n')
with (out/'serve-integration.log').open('w') as log:p=subprocess.run(args,cwd=copy,stdout=log,stderr=subprocess.STDOUT)
print(p.returncode)

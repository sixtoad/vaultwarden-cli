from pathlib import Path
import subprocess,json
out=Path('/tmp/story15-post-review');copy=Path('/tmp/story15-manual-workspace')
args=['cargo','mutants','--no-config','--in-place','--cap-lints','false','--build-timeout','600','--timeout','120','-o',str(out/'handle'),'-F','LoopbackUi::handle','--cargo-arg=--lib','--','adapters::loopback_ui::tests','--','--test-threads=4']
(out/'handle-command.json').write_text(json.dumps(dict(argv=args,cwd=str(copy)),indent=2))
with (out/'handle.log').open('w') as log:r=subprocess.run(args,cwd=copy,stdout=log,stderr=subprocess.STDOUT)
(out/'handle-exit.json').write_text(json.dumps(dict(exit_code=r.returncode)));print(r.returncode,flush=True)

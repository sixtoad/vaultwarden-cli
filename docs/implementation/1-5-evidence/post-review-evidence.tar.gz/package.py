from pathlib import Path
import json,hashlib,re,tarfile,shutil,collections
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-decide-request');out=Path('/tmp/story15-post-review');dest=root/'docs/implementation/1-5-evidence'
old=json.loads((dest/'final-results.json').read_text());prior={r['mutant']['name']:r for r in old['records']};new={m['name']:m for m in json.loads((out/'inventory.json').read_text())};source=json.loads((out/'source-provenance.json').read_text());run=json.loads((out/'handle/mutants.out/outcomes.json').read_text());assert run['total_mutants']==32 and run['missed']==run['timeout']==0
fresh={r['scenario']['Mutant']['name']:r for r in run['outcomes'] if isinstance(r.get('scenario'),dict) and 'Mutant' in r['scenario']};records=[]
for item in source:
 r=dict(prior[item['old_name']]);r['mutant']=new[item['name']];r['post_review_provenance']=item
 if not item['unchanged_function']:
  got=fresh[item['name']]; log=(out/'handle/mutants.out'/got['log_path']).read_text();failed=re.findall(r'^test (.+) \.\.\. FAILED$',log,re.M);cls={'CaughtMutant':'caught','Unviable':'compiler-rejected'}[got['summary']]
  if cls=='caught':assert failed,item['name']
  else:assert 'error[' in log or 'error:' in log,item['name']
  r['final_classification']=cls;r['post_review_result']=dict(summary=got['summary'],log_path='handle/mutants.out/'+got['log_path'],failed_tests=failed,phase_results=got['phase_results'])
 records.append(r)
counts=dict(collections.Counter(r['final_classification'] for r in records));assert counts=={'caught':204,'compiler-rejected':25,'equivalent':1},counts
manual=json.loads((out/'browser-mutants/results.json').read_text());assert len(manual)==11 and manual[0]['classification']=='passed' and all(r['classification']=='caught' for r in manual[1:])
results=dict(counts=counts,generated_total=230,manual_total=24,manual_caught=24,manual_note='16 original distinct cases plus 8 new reviewed-browser counterfactuals; two original browser cases rerun and not double-counted.',records=records)
(out/'final-results.json').write_text(json.dumps(results,indent=2)+'\n')
manifest=json.loads((out/'input-sha256.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
with tarfile.open(out/'verified-source.tar.gz','w:gz') as archive:
 for name in ['src','tests','Cargo.toml','Cargo.lock']:archive.add(root/name,arcname=name)
shutil.copy2(out/'final-results.json',dest/'final-results.json');shutil.copy2(out/'inventory.json',dest/'inventory.json');shutil.copy2(out/'input-sha256.json',dest/'verified-input-sha256.json')
for a,b in [('all-targets.log','all-targets.log'),('clippy.log','clippy.log'),('browser.log','browser.log')]:shutil.copy2(out/a,dest/'ordinary'/b)
commands=json.loads((dest/'ordinary/commands.json').read_text());commands['post_review_results']=json.loads((out/'ordinary-results.json').read_text());(dest/'ordinary/commands.json').write_text(json.dumps(commands,indent=2)+'\n')
with tarfile.open(dest/'post-review-evidence.tar.gz','w:gz') as archive:
 for p in sorted(out.iterdir()):archive.add(p,arcname=p.name)
(dest/'post-review-results.json').write_text(json.dumps(dict(generated=32,caught=30,compiler_rejected=2,survivors=0,infrastructure_timeouts=0,manual_cases=10,manual_caught=10,new_distinct_manual=8,unchanged_function_cases=198,browser_wait_assertion_kills=['submission-review-invalidation','completion-fresh-review']),indent=2)+'\n')
lines=[]
for p in sorted(dest.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(dest)))
(dest/'SHA256SUMS').write_text('\n'.join(lines)+'\n');print(counts,'manual distinct',24)

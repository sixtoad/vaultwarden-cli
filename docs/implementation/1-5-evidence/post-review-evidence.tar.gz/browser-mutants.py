from pathlib import Path
import subprocess,json,os,difflib,time
out=Path('/tmp/story15-post-review/browser-mutants');out.mkdir(exist_ok=True)
copy=Path('/tmp/story15-browser-review-workspace');path=copy/'src/adapters/loopback_ui.rs';original=path.read_text()
cases=[
('browser-proof-enforcement', [('request.header("x-csrf-token")\n                != self.browser_session(&request).map(|s| s.csrf.expose())','false')]),
('browser-password-clearing',[("approvalPassword.value='';",';')]),
('immediate-password-clearing',[("async function decide(path,password){approvalPassword.value='';","async function decide(path,password){")]),
('submission-controls',[("decisionControls(true);showFeedback('Submitting decision.');","decisionControls(false);showFeedback('Submitting decision.');")]),
('pending-poll-controls',[("decisionControls(deciding||state!=='pending')","decisionControls(state!=='pending')")]),
('submission-review-invalidation',[("deciding=true;invalidateReview();","deciding=true;")]),
('completion-fresh-review',[("await review(true);refresh.focus();","await review();refresh.focus();")]),
('stale-review-guards',[("if(!current())return;",''),("if(!current()||retired)return;","if(retired)return;")]),
('automatic-approval-retry',[("catch{password='';showFeedback('Decision response unavailable.","catch{password='';try{await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({request_id:requestId,password:'synthetic-browser-password'})});}catch{}showFeedback('Decision response unavailable.")]),
('external-completion-focus',[("if(unavailable&&decisions.contains(document.activeElement))refresh.focus();",';')]),
]
env=os.environ.copy();env.update(VW_UI_DEPS='/tmp/vw-story14-browser/node_modules',LD_LIBRARY_PATH='/tmp/vw-story13-nss/extracted/usr/lib/x86_64-linux-gnu')
argv=['node','tests/ui/direct-request.mjs'];results=[]
for name,replacements in [('baseline',[])]+cases:
 mutated=original
 for old,new in replacements:
  assert old in mutated,(name,old);mutated=mutated.replace(old,new)
 path.write_text(mutated)
 (out/(name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True),fromfile='src/adapters/loopback_ui.rs',tofile='src/adapters/loopback_ui.rs')))
 started=time.monotonic();print('START',name,flush=True)
 try:
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(argv,cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  code=r.returncode;s=(out/(name+'.log')).read_text()
  classification='passed' if name=='baseline' and code==0 else 'survived' if code==0 else 'compiler-rejected' if 'could not compile' in s else 'caught' if ('AssertionError' in s or 'TimeoutError: Waiting failed' in s) else 'unrelated-failure'
 except subprocess.TimeoutExpired:code=None;classification='infrastructure-timeout'
 finally:path.write_text(original)
 results.append(dict(name=name,argv=argv,exit_code=code,classification=classification,seconds=time.monotonic()-started));(out/'results.json').write_text(json.dumps(results,indent=2));print('END',name,classification,flush=True)
 if name=='baseline' and code!=0:raise SystemExit('baseline failed')

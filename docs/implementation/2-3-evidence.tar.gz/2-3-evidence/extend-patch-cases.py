import json
from pathlib import Path
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work')
p=Path('/tmp/vw-story23-parent');cases=json.loads((p/'cases-review1.json').read_text());wrapper='./scripts/with-secure-test-tmpdir.sh'
def add(name,path,old,new,selection):
 s=(root/path).read_text();assert s.count(old)==1,(name,s.count(old))
 cases.append(dict(name=name,path=path,old=old,new=new,command=[wrapper,'cargo','test','--offline','--locked',*selection]))
add('cli-request-id-redaction-guard','src/bin/vw-access.rs','!valid_agent_id(binding_id) || known_id.as_ref().is_some_and(|id| !valid_agent_id(id))','!valid_agent_id(binding_id)',['--test','human_cli','malformed_agent_selectors_are_usage_errors_before_key_access'])
add('exchange-response-deadline-renewed','src/adapters/unix_socket.rs','read_frame(&mut stream, MAX_RESPONSE_FRAME_BYTES, deadline).await?','read_frame(&mut stream, MAX_RESPONSE_FRAME_BYTES, Instant::now() + IO_TIMEOUT).await?',['--lib','unix_socket'])
path='src/access/protocol.rs';s=(root/path).read_text();a=s.index('impl AgentResponse {');block=s[a:];old='serde_json::from_slice(bytes).map_err(|_error| AgentRejection::Malformed)?';new='serde_json::from_value(serde_json::from_slice::<serde_json::Value>(bytes).map_err(|_error| AgentRejection::Malformed)?).map_err(|_error| AgentRejection::Malformed)?';assert block.count(old)==1
add('query-response-duplicate-fields-collapsed',path,block,block.replace(old,new,1),['--lib','protocol_tests'])
(p/'cases-patch.json').write_text(json.dumps(cases,indent=2)+'\n');print('Prepared',len(cases),'final semantic mutants')

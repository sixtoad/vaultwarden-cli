import base64,json,os,pathlib,subprocess,tempfile,time
binary='/home/sixtocantolla/sessions/day-to-day/vaultwarden-cli/target/debug/vw-access'
ident=base64.urlsafe_b64encode(bytes([19])*32).decode().rstrip('=')
results={}
with tempfile.TemporaryDirectory(prefix='vw23-triage-') as name:
 p=pathlib.Path(name);key=p/'seed';os.mkfifo(key,0o600)
 def args(binding):
  return [binary,'wait',ident,'--socket',str(p/'agent.sock'),'--key-file',str(key),'--binding-id',binding,'--timeout-seconds','1']
 started=time.monotonic()
 child=subprocess.Popen(args(ident),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:
  out,err=child.communicate(timeout=1.5)
  results['fifo']={'exit':child.returncode,'seconds':time.monotonic()-started,'stdout':out.decode(),'stderr':err.decode()}
 except subprocess.TimeoutExpired:
  child.kill();out,err=child.communicate(timeout=2)
  results['fifo']={'alive_after_timeout':True,'cleanup_exit':child.returncode,'stdout':out.decode(),'stderr':err.decode()}
 key.unlink();key.write_bytes(bytes([17])*32);key.chmod(0o600)
 for title,binding in [('invalid_binding','invalid-selector'),('valid_seed_positive_control',ident)]:
  r=subprocess.run(args(binding),stdin=subprocess.DEVNULL,capture_output=True,timeout=3)
  results[title]={'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
 assert results['fifo'].get('exit')==1
 assert results['valid_seed_positive_control']['exit']==3, 'must get past key loading'
 pathlib.Path('/tmp/vw-story23-parent/reviews/parent-triage-evidence.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results,indent=2))

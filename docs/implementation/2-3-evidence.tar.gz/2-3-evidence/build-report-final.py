import collections, hashlib, json, pathlib, shutil, tarfile
p=pathlib.Path('/tmp/vw-story23-parent')
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work')
out=root/'docs/implementation'
initial=json.loads((p/'final/results.json').read_text())
post=json.loads((p/'final-post/results.json').read_text())
mutants=json.loads((p/'final-semantic/results.json').read_text())
assert all(x['exit']==0 for x in initial+post)
assert len(mutants)==36 and all(x['classification']=='caught' for x in mutants)
source=json.loads((p/'final/source-hashes.json').read_text())
restored=json.loads((p/'final-semantic/restored-hashes.json').read_text())
postsource=json.loads((p/'final-post/source-hashes.json').read_text())
assert source==postsource
assert all(v==hashlib.sha256((root/k).read_bytes()).hexdigest() for k,v in restored.items())
assert all(restored[k]==v==hashlib.sha256((root/k).read_bytes()).hexdigest() for k,v in source.items())
summary={'environment':json.loads((p/'environment.json').read_text()),'iteration':1,'initial':initial,'post_mutation':post,'mutants':mutants,'mutation_classifications':dict(collections.Counter(x['classification'] for x in mutants)),'source_files_compared':len(source),'restored_copy_files':len(restored),'all_target_reported_passes':sum(int(x[0]) for x in next(c for c in initial if c['name']=='all-targets')['suites']),'live_backend_early_returns':71,'other_reported_passes':sum(int(x[0]) for x in next(c for c in initial if c['name']=='all-targets')['suites'])-71,'ignored_entries':14,'benchmark_smoke_checks':13,'real_manager_scenarios':30,'workflow_reviews':'all three completed; iteration-1 patches verified','publication_authorized':False}
(out/'2-3-evidence-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copy2(out/'2-3-evidence-summary.json',p/'evidence-summary.json')
# Preserve earlier implementation failures and reruns separately from final evidence.
earlier=p/'implementation'
earlier.mkdir(exist_ok=True)
for item in pathlib.Path('/tmp').glob('2-3-*.log'):
 shutil.copy2(item,earlier/item.name)
for name in ['2-3-implementation-handoff-sha256.txt','2-3-cli-hashes.txt']:
 item=pathlib.Path('/tmp')/name
 if item.exists(): shutil.copy2(item,earlier/name)
archive=out/'2-3-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for item in sorted(p.rglob('*')):
  if item.is_file() and item.suffix!='.pyc' and item.name!='review1-progress.md': tar.add(item,arcname='2-3-evidence/'+str(item.relative_to(p)))
archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
rows=[]
for phase,checks in [('Final patched source',initial),('Restored source',post)]:
 for check in checks:
  counts=[sum(int(x[i]) for x in check['suites']) for i in range(3)]
  result=(f'{counts[0]} reported passed, {counts[1]} failed, {counts[2]} ignored' if check['suites'] else 'exit 0')
  rows.append(f"| {phase}: `{check['name']}` | {result} | {check['seconds']:.2f} s |")
mutation_rows=[]
for x in mutants:
 failures=', '.join('`'+v.rsplit('::',1)[-1]+'`' for v in x['failing_tests'])
 mutation_rows.append(f"| `{x['name']}` | caught (exit {x['exit']}) | {failures} |")
report='''# Story 2.3 verification

Implementation, all three workflow reviews and final patch verification are complete.
Iteration-0 evidence and review triage are retained in the archive. The implementation
is uncommitted; commit, push and pull-request publication remain unauthorized.

Base: `6081c48764208c1adad03b9d5be31550ff850895` on updated `main`.
Epic 1 and Stories 2.1–2.2 are merged; there is no unmerged dependency.
See [planning evidence](2-3-planning-notes.md), [wire and CLI contract](2-3-protocol-contract.md),
and the [detailed acceptance map](2-3-implementation-notes.md).

## Acceptance coverage

| User acceptance criterion | Executed witnesses |
|---|---|
| 1. Signed versioned snake_case status query; purpose/request/freshness bound | Protocol suite (12 tests): canonical independent vector, all signed fields, strict Ed25519, cross-purpose reuse, strict dispatcher and field schemas |
| 2. Kernel peer, signature, enabled pairing and immutable owner on every query | Signed suite (SIGNED_COUNT tests), including independent UID/group/enabled/owner negatives; actual mapped-UID Unix socket test with independently eligible other binding and wrong-group decoy |
| 3. Explicit safe lifecycle/exit/failure projection | Every supported lifecycle and five failure categories, exit bounds, injected unknown fields; raw wire and CLI output assertions |
| 4. Indistinguishable inaccessible/nonexistent rejection | Exact byte equality and EOF behavior for known non-owner, guessed ID, unpaired and revoked callers; no state/audit/replay-marker changes on rejection |
| 5. Noninteractive polling and request-and-wait | CLI_COUNT CLI integration tests plus WAIT_COUNT virtual-time wait tests; capped 100/200/400/800/1000 ms backoff, terminal/rejection/Busy handling, timeout, disconnected acknowledgment/query, SIGINT/SIGTERM before and after receipt, full stdout/stderr pipes, shared submission/receipt/poll budget, fresh-query reconnect, exactly one submission, stdin closed and setsid |
| 6. Provider-authoritative expiry and confirmed completion | Separate provider monotonic/wall clocks; Pending/Approved × request/session deadline × before/write/final-read crossings; controlled cleanup synchronization; real systemd cleanup/recovery regression tests |
| 7. Repeated terminal observation without transferable authority | Fresh signed observations, unchanged terminal RequestRecord/audit, restart, shared nonce replay across actions, concurrency, durable write failure cases, re-pairing without old ownership, revocation intent during blocked query persistence and established-connection/active-wait revocation |

Every frozen matrix row has an executed passing witness: owner query maps to criteria
1/3/7; inaccessible ID to 2/4; invalid authority to 1/2/4; authority changes to 6/7;
interrupted waiting to 5. Existing agent-binding registry tests also passed in both
full suites; no changes to their source were needed. Query tests assert no new
requests/audits, review launch, secret resolution, backend unlock or execution.

## Exact automated results

The [machine-readable ledger](2-3-evidence-summary.json) records exact argv, exit
codes, durations and mutant failure names. All tests finished before review was
requested. Both complete suites ran on identical source bytes. The mutation copy
and restored original were checked against those source hashes.

| Check | Result | Duration |
|---|---|---|
'''+ '\n'.join(rows)+'''

Both complete suites additionally passed 13 benchmark smoke checks. Of the REPORTED_PASSES
reported passes per suite, 71 live-Vaultwarden tests return early because
`VAULTWARDEN_LIVE_TEST_URL` and `VAULTWARDEN_LIVE_ADMIN_TOKEN` are absent; **EXECUTED_PASSES
other reported tests execute**. The 14 ignored entries comprise nine subprocess
fixtures invoked by passing parent tests, one browser fixture, one internal
systemd fixture, one namespace fixture and two real-manager tests. Namespace and
systemd harnesses were explicitly executed; systemd covered 30 real-manager
scenarios. The browser fixture was not rerun for this agent-only change.

The mapped namespace invocation uses provider UID 0, separate agent/wrong UIDs
8/10, socket-access GID 7 and binding GID 9. A second UID-8/GID-10 binding allows
preflight admission while independently testing a query's selected-binding group.
The held connection is proven admitted before revocation using consumed input,
nonblocking response peek and pipe synchronization; the active-wait revocation
phase is separate. The unit socket witness uses a first-frame-chunk hook.

The tests use `scripts/with-secure-test-tmpdir.sh`, locked offline dependencies,
`CARGO_BUILD_JOBS=2`, `RUST_TEST_THREADS=4`, and the existing target cache at
`/home/sixtocantolla/sessions/day-to-day/vaultwarden-cli/target`. Escalated local
execution allowed the repository's HOME-based secure temporary fixtures, mapped
user namespaces and user systemd; HOME was not replaced. Toolchain/kernel versions
are recorded in the ledger. Fresh original source mtimes forced rebuilding after
mutations; source content hashes remained identical.

The separate log scan checks eleven exact synthetic secret/label/output/capability
sentinels across successful unmutated verification logs. The real-peer test runs with
`--nocapture`; its captured provider stdout/stderr contains no unexpected
application diagnostics. CLI tests independently require exact redacted JSON,
empty stderr where appropriate and no reflected invalid-input sentinel.

## Scoped mutation results

**36 distinct semantic mutations: 36 caught, 0 survivors, 0 equivalent mutants,
0 unviable mutants, 0 timeouts and 0 infrastructure failures.** Ten unmodified
baseline test selections passed before mutation. A caught result requires a
compiled test binary and an actual `test result: FAILED` outcome;
compilation errors and campaign timeouts are classified separately. The two blocked-output mutants trip bounded child-exit assertions and kill/reap the child; neither stalls the campaign. The terminal-stop
mutant attempts an extra query after Completed and exhausts the finite response
fixture; all other caught results are explicit assertion failures. Review-derived mutants restore blocking stdout, unbounded stderr diagnostics, a reset deadline after acknowledgment, a release gate held over storage, missing CLI request-ID validation, a renewed response-read deadline, and duplicate-field collapse through intermediate JSON values. The campaign is a
manual semantic mutation campaign, not a generated cargo-mutants run.

| Mutation | Classification | Failing witness |
|---|---|---|
'''+ '\n'.join(mutation_rows)+f'''

The disposable mutation copy was restored byte-for-byte. All {len(source)}
production/test/script/manifest hashes agree between the initial suite, copied
baseline, restored copy, post-mutation suite and final worktree. All {len(restored)}
files in the complete disposable copy also match the original worktree. Production
binaries were rebuilt from the original unmutated worktree before the final
focused and real-peer tests. No meaningful survivors remain to fix and no
equivalence claims are needed.

## Review resolution

Iteration 0 found blocked output and unbounded fixture failure paths; those were
re-derived and independently verified. Iteration 1 completed blind, edge-case and
verification-gap reviews. The edge reviewer returned no findings. Triaged patches
extend malformed positional-ID redaction, a single transport budget, terminal and
broken-pipe output, binding-scoped nonce reuse and duplicate nested response-field
coverage. The pipe witness now explains its dependency on observable Linux task
wchan symbols. No review layer was skipped. Per-finding verdicts and evidence are
retained in the archive and build spec.

Existing synchronous-filesystem stalls and permanent replay-storage growth remain
documented follow-ups. Nonblocking inherited stdout errors retain the closed local
failure behavior; automatic output readiness retries were not added. No change to
approved ownership, disclosure, lifecycle or replay intent was needed.

## Evidence and limitations

The [evidence archive](2-3-evidence.tar.gz) includes raw logs, runners, case
definitions, per-mutant diffs, classifications, source/restoration hashes and
historical implementation attempts. SHA-256: `{archive_hash}`.
Earlier fixture contention failures, the sandbox-only secure-wrapper refusal and
the strict-Clippy test-hook initializer failure are retained. The initializer was
made const; the complete final campaign passed afterward.

- All configured checks, scoped mutations and workflow reviews have finished. The 71 live-backend tests could not exercise Vaultwarden without the missing test URL/admin-token configuration. Completed-implementation human approval is the next checkpoint.
- Live Vaultwarden, hosted GitHub CI, a combined live-backend/cross-UID browser
  deployment, and manual accessibility checks were not run. No such acceptance
  is inferred from these synthetic tests. No agent-facing UI was added.
- Linux blocked-pipe synchronization requires observable task `wchan` symbols in procfs; hidden symbols fail the fixture explicitly instead of skipping it.
- Every successful poll permanently adds a nonce digest and rewrites the provider
  snapshot. Storage growth and write amplification remain; no quotas, compaction
  or replay-marker eviction were added. Freshness is durable nonce uniqueness,
  matching Story 2.2, not a client wall-clock message-age claim.
- Synchronous filesystem access can still stall beyond the network deadline; this is a pre-existing documented transport limitation. Older executables reject snapshots containing query replay metadata; replay evidence must not be stripped to force a downgrade.
- A lost submission acknowledgment can leave the client without an ID. Waiting
  never discovers, resubmits or cancels work; reconnect uses a known ID with a
  fresh signature. Local timeout/interruption/transport errors remain separate
  from provider lifecycle and execution exit status.
- These mutation witnesses cover selected security/lifecycle/wait guards; they
  are not an exhaustive enumeration of every possible defect.
'''
report=report.replace('REPORTED_PASSES', str(summary['all_target_reported_passes'])).replace('EXECUTED_PASSES', str(summary['other_reported_passes']))
report=report.replace('SIGNED_COUNT', next(c for c in initial if c['name']=='signed')['suites'][0][0]).replace('CLI_COUNT', next(c for c in initial if c['name']=='cli-lifecycle')['suites'][1][0]).replace('WAIT_COUNT', next(c for c in post if c['name']=='wait')['suites'][0][0])
(out/'2-3-verification.md').write_text(report)
print('Wrote evidence summary, archive and verification report:',archive_hash)

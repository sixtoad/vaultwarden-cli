from pathlib import Path
import json,subprocess
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work')
p=Path('/tmp/vw-story23-parent')
baseline='6081c48764208c1adad03b9d5be31550ff850895'
others=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
checks=[]
for args in [['git','diff','--check']]+[['git','diff','--no-index','--check','/dev/null',name] for name in others]:
 r=subprocess.run(args,cwd=root,text=True,capture_output=True)
 assert r.returncode in ([0] if args==['git','diff','--check'] else [0,1]) and not r.stdout and not r.stderr,(args,r.returncode,r.stdout,r.stderr)
 checks.append({'command':args,'exit':r.returncode,'diagnostics':'','result':'pass'})
(p/'final-whitespace.json').write_text(json.dumps(checks,indent=2)+'\n')
prefix=str(root)+'/'
args=['git','diff','--no-ext-diff','--src-prefix='+prefix,'--dst-prefix='+prefix,baseline,'--']
parts=[subprocess.check_output(args,cwd=root)]
for name in others:
 r=subprocess.run(['git','diff','--no-index','--no-ext-diff','--src-prefix='+prefix,'--dst-prefix='+prefix,'/dev/null',name],cwd=root,capture_output=True)
 assert r.returncode in [0,1],r.stderr
 parts.append(r.stdout)
diff=Path('/tmp/vw-story23-review-f1kbxks8.diff')
diff.write_bytes(b'\n'.join(parts))
print('Whitespace checks passed for tracked diff and',len(others),'untracked files.')
print('Review diff:',diff,'bytes',diff.stat().st_size,'lines',len(diff.read_text().splitlines()))

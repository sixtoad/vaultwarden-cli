from pathlib import Path
import json,re
p=Path('/tmp/vw-story23-parent');directory=p/'final-semantic'
results=json.loads((directory/'results.json').read_text());assert len(results)==36
assert all(r['classification']=='caught' and r['exit']==101 for r in results)
audit=[]
for result in results:
 log=(directory/(result['name']+'.log')).read_text()
 assert 'test result: FAILED.' in log and 'could not compile' not in log
 failures=re.findall(r"panicked at ([^\n]+):\n([^\n]+)(?:\n(  left: [^\n]{0,220})\n( right: [^\n]{0,220}))?",log)
 assert failures,(result['name'],'no failure detail')
 audit.append(dict(name=result['name'],failures=failures))
 print(result['name'],failures[:2])
(directory/'failure-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
text=(p/'review1-semantic/assessment.md').read_text().replace('All 33','All 36').replace('Thirty-two','Thirty-five').replace('All eight','All ten').replace('review1-post','final-post')
text+='''\nFinal patch campaign adds three independently caught regressions: removing CLI positional-request-ID validation, renewing the response-read deadline, and decoding a response through an intermediate JSON value that collapses duplicate fields. Their exact final-source failures are recorded in failure-audit.json and the per-mutant logs. The parent reviewed these raw failures before reporting readiness.\n'''
(directory/'assessment.md').write_text(text)

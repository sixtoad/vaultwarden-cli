"""Check uncaptured provider diagnostics plus recorded verification output."""
import json
from pathlib import Path
import re
import sys

root = Path('/tmp/vw-story23-parent')
phase = sys.argv[1]
logs = sorted((root / phase).glob('*.log'))
assert logs, 'no logs to check'
sentinels = [
    'status-label-sentinel', 'synthetic-password', 'Deploy login',
    'DEPLOY_PASSWORD', 'namespace-agent', 'secret-url-output-capability',
    'private-sentinel', 'Deployment', 'private-selector-sentinel',
    'secret-output-url-capability', 'backend-secret',
]
results = []
for path in logs:
    content = path.read_text(errors='replace')
    found = [value for value in sentinels if value in content]
    assert not found, (str(path), found)
    if path.name == 'real-peer.log':
        # --nocapture includes provider stdout/stderr. Exclude only Rust/Cargo
        # harness lines; application diagnostics would remain visible here.
        lines = [line for line in content.splitlines() if line.strip()
                 and not re.match(r'^\s*(Compiling |Finished |Running |running \d+ tests?|test result:|test [A-Za-z0-9_:]+ \.\.\. (ok|ignored))', line)]
        assert not lines, ('unexpected provider diagnostics', lines)
    results.append({'log': path.name, 'sentinels_checked': len(sentinels), 'result': 'pass'})
out = root / phase / 'redaction-scan.json'
out.write_text(json.dumps(results, indent=2) + '\n')
print(f'{len(results)} logs passed; {len(sentinels)} exact sentinels each; namespace provider diagnostics empty.')

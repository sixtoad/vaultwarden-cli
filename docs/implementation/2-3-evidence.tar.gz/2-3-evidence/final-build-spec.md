---
title: 'Story 2.3: Poll Delegated Work and Preserve Request Ownership'
type: feature
created: '2026-10-05'
status: done
route: dispatch
review_loop_iteration: 1
baseline_commit: 6081c48764208c1adad03b9d5be31550ff850895
context:
  - /home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work/docs/implementation/2-3-planning-notes.md
---

<frozen-after-approval reason="human-owned intent — do not modify unless human renegotiates">

## Intent

**Problem:** Issue #16 needs safe observation of delegated work.

**Approach:** Extend the existing signed JSON Lines transport with owner-authenticated status queries and noninteractive polling/waiting.

## Boundaries & Constraints

**Always:** Recheck kernel UID/group, enabled stored key, strict signature, immutable owner and revocation per query. Sign purpose, request ID, binding and fresh nonce. Persist replay consumption before disclosure. Use provider clocks for lifecycle; preserve cleanup/reaping before completion and immutable terminal records. Return only closed lifecycle/exit/failure projections. Follow the companion test matrix.

**Never:** Reveal existence through inaccessible-ID rejection; trust labels or supplied ownership; disclose secrets, credential labels, raw output, backend/browser data, URLs or capabilities. Polling cannot submit, launch approval, resolve credentials, execute, or expose history. Waiting cannot prompt, resubmit or cancel work. No commit, push or PR without completed-implementation approval.

## I/O & Edge-Case Matrix

| Scenario | Input / State | Expected Output / Behavior | Error Handling |
|---|---|---|---|
| Owner query | Fresh signature; pending/running/terminal | Minimal redacted state | Closed schema |
| Inaccessible ID | Unknown/non-owner/unpaired/revoked | Identical rejection and connection behavior | No existence/details |
| Invalid authority | Wrong peer, signature, purpose, tampering or replay | No disclosure or execution | Redacted rejection |
| Authority changes | Revoke, re-pair, restart, expiry | Current immutable ownership; provider lifecycle | Fail closed |
| Wait interrupted | Timeout, signal, disconnect | Retain known ID; resume by polling | Separate client uncertainty |

</frozen-after-approval>

## Code Map

Worktree/branch/dependency evidence is in the companion; all dependencies are merged.

- `src/access/protocol.rs`: canonical signing, strict decoding, replay digest, bounded responses.
- `src/access/application.rs`: authority/release gates, revocation tokens, clocks and existing `agent_status`.
- `src/access/provider.rs`, `provider_store.rs`: exact owner lookup, atomic snapshots, submission tombstones.
- `src/adapters/unix_socket.rs`: real peer admission and one-envelope/EOF transport.

## Tasks & Acceptance

**Execution:**
- [x] `src/access/protocol.rs`, `protocol_tests.rs` — query envelope, projection, canonical/cross-purpose tests.
- [x] `src/access/provider_store.rs`, `provider.rs`, `application.rs` — durable query markers, guarded ownership/replay and provider expiry.
- [x] `src/adapters/unix_socket.rs`, `unix_socket_tests.rs` — bounded authenticated dispatch and uniform rejection.
- [x] `src/bin/vw-access.rs`, `src/adapters/agent_wait.rs`, `src/adapters/mod.rs` — `submit --wait`, `poll <id>`, `wait <id>`; bounded cancellable waiting and stable exits.
- [x] `src/access/direct_request_tests.rs`, `agent_binding_tests.rs`, `tests/agent_submission.rs`, `tests/human_cli.rs` — deterministic matrix, real peers, no-TTY and side-effect/redaction assertions.
- [x] `docs/access-mvp.md`, `docs/implementation/2-3-*` — wire/CLI contract, AC evidence, mutations and limitations.

**Acceptance Criteria:**
- Given an enabled owner, when querying every state, then only permitted status returns, including terminal observation after restart.
- Given inaccessible IDs or invalid authority, when queried, then rejection reveals no existence/details and causes no execution.
- Given revoked/re-paired identities or captured queries, when polling, then old authority fails and ownership never transfers.
- Given skew, interruption or disconnection without stdin/TTY, when waiting, then provider state governs lifecycle and reconnect never resubmits.

## Implementation Notes

- Iteration 1 execution is sequential: do not split simultaneous edits or Cargo runs across workers. Reuse the saved validated code where the KEEP instructions apply. During derivation, run focused checks for edited surfaces and report a stable source handoff; the parent orchestrator runs the complete verification/mutation campaign after that handoff. Use the existing target cache `/home/sixtocantolla/sessions/day-to-day/vaultwarden-cli/target`, `CARGO_BUILD_JOBS=2`, `RUST_TEST_THREADS=4`, offline locked dependencies and the secure temporary-directory wrapper; never override HOME. No commit, push or PR.

- 2026-10-06: User approved the unchanged draft and continued. Implementation dispatched; no commit, push or PR authorized.

- 2026-10-06: Full implementation diff audited against baseline, including untracked files. Every frozen matrix row maps to executed passing tests; see `docs/implementation/2-3-verification.md`. Stable and Rust 1.88 all-targets suites each reported 942 passes (71 configured-backend early returns), 0 failures and 14 ignored fixtures. Explicit namespace and systemd checks passed. All 29 scoped mutations were caught; restoration hashes and fresh original rebuild/focused tests passed. No publication authorized.

- 2026-10-06, iteration 1: all tasks and frozen matrix rows audited against the complete diff. Stable/MSRV suites each 947 reported passes (71 configured-backend early returns), 0 failures, 14 ignored; all focused, namespace and 30-scenario systemd checks passed. All 33 mutants caught; 95 source and 97 restored-copy hashes matched; fresh original rebuild and post-mutation checks passed. Matrix audit records 28 passing witness mappings. Repeat workflow review follows.

## Spec Change Log

- 2026-10-06, iteration 1 — Trigger: BH1/EC1 reproduced blocked stdout defeating timeout and SIGTERM; BH10 found unbounded fixture failure paths. Amend the non-frozen CLI design and verification details to include cancellable output, bounded output-worker shutdown, one shared budget through receipt and observation, and bounded fixture cleanup. Avoid restoring synchronous output on the current-thread waiter or indefinitely joined fixture threads. KEEP all validated signed-protocol, ownership, peer/replay, provider expiry, cleanup/reaping, redaction and no-side-effect behavior/tests from iteration 0. Preserve the single deadline and strengthen its caller-level witness (VG1). Also incorporate the small BH4 disclosure-lock correction, BH7 downgrade documentation and BH8 selector validation during re-derivation. No frozen intent changed.

- Positive preservation source: `/tmp/vw-story23-iteration0-backup/source/` contains the complete reviewed changed files, with `/tmp/vw-story23-iteration0-backup/manifest.json` and `reviewed.diff`. Reuse validated portions and tests; re-derive the affected I/O, lock-scope and fixture code according to this spec. Prior evidence under `/tmp/vw-story23-parent/initial`, `semantic`, and `post` belongs to iteration 0 and is not final verification of changed source.

## Review Triage Log

# Story 2.3 review iteration 0

All three layers reported before triage. The third launch initially hit the concurrent agent limit, then succeeded after the first reviewer completed. No review layer was skipped.

| Finding | Verdict | Route | Verification evidence |
|---|---|---|---|
| BH1 — blocked stdout defeats timeout/signals | high | bad_spec | `run_agent` executes `output()`/write_all/flush synchronously on its current-thread runtime. The edge review's reproducible full-pipe fixture remains alive past its one-second timeout and after SIGTERM, requiring SIGKILL. The non-frozen design failed to include output in cancellable waiting. |
| BH2 — FIFO seed open blocks before validation | false | reject | `load_signing_key` calls `open_at`, which already adds `O_NONBLOCK` at unix_socket.rs:94 before metadata inspection. A FIFO cannot block waiting for a writer at this location. General slow-filesystem behavior is a different claim (BH3). |
| BH3 — synchronous filesystem work can exceed exchange deadline | medium | defer | Directory opening and pre/post-connect metadata checks are synchronous. The baseline implementation contains the same calls, and access-mvp.md already documents filesystem stalls exceeding socket deadlines. The new absolute network budget does not remove this existing platform limitation; separating blocking filesystem work is broader follow-up work. |
| BH4 — query holds release gate across storage I/O | medium | patch | signed_agent_status holds release_gate through refresh, nonce persistence and final reads. lock/revoke/cancel/close_admission need that gate to publish control intent. Polling can retain final disclosure serialization without retaining this control gate during storage; use a synchronized stalled-write witness. |
| BH5 — unbounded polling replay ledger | medium | defer | Permanent one-use nonce retention and full-snapshot growth are deliberate approved constraints. The underlying absence of a provider-wide storage budget was already recorded by Story 2.2; polling adds write amplification. A quota/retention policy remains explicit follow-up work rather than silently changing the accepted replay contract. |
| BH6 — repeated snapshot reads need latency benchmark/consolidation | low | reject | Multiple full reads are real overhead, but no representative workload or violated latency target was identified. Reorganizing authorization/persistence is a nontrivial optimization; ordinary-use harm beyond the disclosed storage tradeoff is unsubstantiated. |
| BH7 — older executable cannot read extended snapshots | low | patch | The baseline StoredProviderState uses deny_unknown_fields and cannot accept query_replay_markers. New-reader/old-state compatibility does not imply downgrade compatibility. Add an explicit downgrade boundary and preserve replay evidence; no data-stripping recovery instruction. |
| BH8 — malformed binding selector uses local-failure exit | low | patch | Request IDs are validated before key loading; binding IDs reach signing and map Malformed to LocalFailure. Validate canonical binding IDs with request IDs so malformed selectors consistently use usage exit 2 without reflected input. |
| BH9 — i32 DTO permits invalid public construction | false | reject | The only production constructor is signed_agent_status, which checks 0..=255 and fails closed before serialization. Deserialization requires u8. No existing caller serializes an out-of-range status; hypothetical new constructors are not a current invariant failure. |
| BH10 — test fixtures can wait indefinitely | medium | bad_spec | Newly added accept/read/child-wait/join paths lack an overall failure bound. For example, poll joins the server before checking the child result; a child that exits before connecting leaves join blocked. The verification plan must require bounded fixture teardown and owned-child cleanup. |
| EC1 — blocked stdout contradicts bounded waiting | high | bad_spec | Same reproduced defect as BH1, separately retained before grouping. Evidence is stdout-backpressure-repro.py and stdout-backpressure-evidence.txt in this directory. |
| VG1 — shared submission/wait budget lacks caller witness | medium | patch | Pre-verified regression gap: existing CLI fixtures acknowledge immediately or check only exit/output; resetting the timeout after acknowledgement would evade them. Add a caller-level shared-budget witness with delayed acknowledgement and preserved receipt ID. |

BH1/EC1 share one root cause. BH10 is separate. Both bad_spec groups concern non-frozen implementation/verification detail; approved intent needs no change. Lower patch/defer entries are recorded for preservation/follow-up; code is re-derived before any patch-only pass. Pending deferrals BH3/BH5 must be recorded in the deferred-work ledger once loopback processing completes.

KEEP: all signed protocol vectors and strict decoding; Linux peer/selected-binding checks; immutable ownership; permanent cross-purpose replay evidence; exact unauthorized response/EOF behavior; provider-clock expiry and cleanup/reaping; terminal restart observations; fresh signed queries; no secret/UI/execution side effects; existing CLI exits and redaction; all independent negative tests and mutation witnesses. Preserve the valid single submission-plus-wait deadline while adding its missing witness. The saved iteration-0 source and evidence remain available outside the worktree for reuse.


# Story 2.3 review iteration 1

All three layers completed before triage. Blind hunter returned ten findings; edge hunter returned no findings; verification-gap reviewer returned two pre-verified gaps. Third launch retried once after the transient agent limit; no layer skipped.

| Finding | Verdict | Route | Evidence |
|---|---|---|---|
| BH1 — nonblocking inherited stdout returns LocalFailure on WouldBlock | low | reject | The descriptor-owning worker preserves flags and propagates write errors as documented LocalFailure; it does not block or alter provider work. Retrying inherited nonblocking stdout is not promised. This uncommon descriptor configuration would require new readiness/retry behavior, not a direct correction. |
| BH2 — malformed positional request ID lacks CLI regression | medium | patch | Current selector test corrupts only binding_id; removing the independent known_id validation permits the untrusted positional value into LocalFailure stderr. Extend the same fixture with valid binding, malformed positional ID and absent key. |
| BH3 — terminal output lacks full-pipe witness | low | patch | Existing full-pipe fixture covers receipt and Running; normal terminal output is tested but blocked terminal output is not. Extend the same response matrix so the common Completed path proves deadline/signal precedence and retained ID. |
| BH4 — broken stdout reader lacks accepted-ID witness | low | patch | Output worker propagates BrokenPipe through the same known-ID diagnostic path, but current subprocess tests do not execute it. A closed-reader variation of the existing fixture can directly assert LocalFailure, known ID and no later query. |
| BH5 — total transport deadline lacks staged-delay witness | medium | patch | Existing read_frame tests verify a supplied deadline, immediate exchange tests verify framing, and wait tests have an outer budget. None detects renewing only the response-read deadline after earlier transport work. Add a deterministic exchange-level remaining-budget assertion. |
| BH6 — same nonce under two bindings lacks query-consumption witness | low | patch | Submission digest tests already prove binding affects the digest, but query persistence tests only reuse within one binding. Extend the existing query replay test with independently authorized requests under two bindings sharing the nonce; both must succeed. |
| BH7 — duplicate nested status response fields lack witnesses | low | patch | Query envelope duplicates and response unknown fields are covered; nested state duplicate status/exit_code/category cases are absent. Add these direct inputs to the existing closed-projection parser matrix. |
| BH8 — fixed ten-second listener budget could fail on a heavily loaded host | low | reject | Fixtures intentionally share a finite bound; the longest normal backoff sequence here is 1.5 seconds and the client has its own five-second budget. Current full CLI suite completes in under five seconds. Heavily delayed scheduling is possible, but configurable nested budgets add complexity without an ordinary-use failure demonstrated. |
| BH9 — hidden /proc wchan symbols obscure fixture diagnosis | low | patch | The pipe fixture requires observable task wchan ending pipe_write; a kernel returning 0 cannot establish its synchronization witness. Keep the test mandatory, clarify this requirement in the failure message and verification limitations instead of treating an unobserved write as a pass. |
| BH10 — quantify permanent replay storage/write cost | medium | defer | carried from iteration-0 BH5: permanent replay retention and full-snapshot growth are the approved existing storage tradeoff. The pending global-budget follow-up includes polling write amplification. No production retention policy is changed. |
| VG1 — malformed positional ID redaction gap | medium | patch | Pre-verified: known_id validation can be deleted while the existing malformed-binding test still passes. Add independent poll/wait invalid-ID cases with a valid binding and absent key. |
| VG2 — shared transport deadline regression gap | medium | patch | Pre-verified: replacing the response read deadline with Instant::now()+IO_TIMEOUT evades direct framing, immediate exchange and outer-wait tests. Add a caller-level controlled budget-consumption witness. |

Grouped BH2/VG1 (positional selector) and BH5/VG2 (transport budget) only after recording every verdict. Remaining patches are bounded extensions of existing verification or diagnostic text; no new public surface or inferred state is introduced. No intent_gap or bad_spec entry remains. Re-engage the same iteration-1 implementation agent for patches. Iteration-0 pending deferrals BH3/BH5 will be appended once after patch verification; carried BH10 does not create another entry.


## Design Notes

Preserve one JSONL envelope plus write-half EOF per connection. Reuse one-use nonce freshness without client timestamps. Store query digests outside request/audit records; both actions check both marker sets. No eviction; document storage/write amplification.

Agent commands share socket/key/binding selectors. `submit` remains acknowledgment-only unless `--wait`; explicit `wait <id>` reconnects. Wait: 100 ms exponential delay capped at 1 s; configurable 300 s monotonic deadline spans exchanges/sleeps. Print/flush the accepted ID before waiting. Exit codes: 0 accepted/nonterminal observation/completed; 1 unsuccessful terminal/rejection/local failure; 2 usage; 3 transport uncertainty; 4 wait timeout; 130 SIGINT; 143 SIGTERM. JSON distinguishes lifecycle from local errors. Preserve human interfaces.

### Review-derived implementation details

- Agent receipt/state output must yield to the same timeout and SIGINT/SIGTERM controls. A full stdout pipe must not block cancellation, and best-effort stderr diagnostics must not make timeout/interrupt exit hang. Do not wait indefinitely for a blocked output worker when the CLI runtime shuts down. Preserve flushing the receipt before the first query, redacted diagnostics, known request IDs, and no resubmission/cancellation of provider work.
- Preserve one absolute monotonic deadline across submission acknowledgement, receipt output, all queries and sleeps. Test the actual submission-to-wait composition with delayed acknowledgement so resetting the budget after acknowledgement is caught. Prefer deterministic clocks at the production composition boundary and synchronization for subprocess witnesses.
- In signed polling, do not retain the control `release_gate` through storage reads/writes/expiry refresh. Keep authority-before-release lock order, preserve durable replay consumption, and serialize the final token/admission check and safe projection with revocation. A blocked poll write must not prevent revocation/cancellation intent from being published. Add an independently synchronized write/revocation witness; retain all pre/post-write failure, ownership and expiry assertions.
- Validate canonical binding IDs with canonical request IDs before key loading; malformed selectors use redacted usage exit 2.
- Document that the new reader accepts old state, while old executables reject snapshots containing query replay metadata. Do not recommend stripping replay metadata or silently restoring stale authority as a downgrade strategy. Clarify the existing filesystem-stall limitation when describing network deadlines.
- New CLI fixture accept/read/child-wait/join paths must have an overall failure bound and deterministic teardown. A child exiting before connect or omitting a query must fail the test and release/reap owned resources, not leave the suite waiting forever. Never use scheduler sleeps to manufacture security-race ordering.

## Verification

- `cargo fmt --all -- --check`; secure test wrapper + `cargo test --all-targets --offline --locked` and Rust 1.88 equivalent; strict all-targets/all-features Clippy.
- Focused protocol, signed-query, ownership, revocation, lifecycle, socket and CLI suites; explicit mapped-UID namespace harness; affected systemd cleanup integration.
- Mutate authentication, ownership, projections, expiry and wait termination in disposable copies. Require passing baselines, survivor fixes/equivalence proofs, restoration hashes and unmutated verification.
- `git diff --check`; check untracked text. Await required checks; report exact results, skips/early returns, limitations and mutations before reviews/human approval.

- Iteration 1: rerun complete required checks after re-derivation. Extend mutation evidence for output backpressure/termination, shared budget across acknowledgement, and revocation intent during blocked query persistence. Preserve the previous exact mutant classifications as historical evidence and separately record final-source results.


## Final implementation verification and human checkpoint

Implementation and all three workflow reviews are complete. The iteration-1 patch
route finished and the final source passed formatting, strict Clippy, stable and
Rust 1.88 all-targets suites, focused signed protocol/ownership/revocation/lifecycle/
CLI checks, real mapped-UID Unix sockets, and the real systemd harness. Each full
suite reports 949 passed, 0 failed and 14 ignored; 71 reported passes are
unconfigured live-backend early returns, leaving 878 other executed tests.
The scoped campaign caught all 36 semantic mutants: zero survivors, equivalent,
unviable, timeout or infrastructure classifications. Original/restored source
hashes match, and all post-restoration checks finished. All five frozen matrix rows
have passing evidence across 30 explicit witness mappings. Exact commands, results,
mutations, review resolutions and limitations are in docs/implementation/2-3-verification.md.

Both iteration-0 deferrals are now recorded once in deferred-work.md: bounding
existing synchronous filesystem stalls, and global storage/replay write growth.
The iteration-1 carried storage finding does not create another entry.

The build implementation status is done; completed-implementation human approval
is pending. No commit, push or PR was created. The user's explicit approval gate
supersedes Step 5's default local-commit instruction. Sprint sync was skipped:
the shared sprint-status.yaml belongs to Oriel and has no matching Vaultwarden
story key; no unrelated project's status was changed. The frozen approved intent
is unchanged.

# Mutation outcome audit

All 36 mutants compiled and reached the intended selected tests. Raw failure reasons were inspected, not inferred solely from the nonzero exit code. Thirty-five produced explicit assertion failures. The terminal-stop mutant made an extra query after Completed and exhausted the finite response queue, causing the expected test panic; it was not a timeout or infrastructure failure.

Independent UID, group and stored-owner bypass mutants are caught by the full-snapshot no-effects assertion even where a later admission guard still rejects disclosure: removing the early guard incorrectly consumes query replay metadata. The enabled-pairing mutant is independently caught by a direct provider authorization witness without an application revocation token masking the missing stored check. The actual namespace test separately isolates selected-binding groups using a valid decoy binding.

Removing replay lookups changes expected Replay into Unavailable when strict snapshot validation prevents writing a conflicting marker. This is a real protocol/availability regression, not equivalence: it closes admission unnecessarily. Removing durable marker persistence instead loses replay consumption and fails concurrent/repeated-observation assertions.

Expiry mutants specifically fail final-read crossings with Pending returned instead of Expired, separately for request and session deadlines. Revocation returns Pending rather than Unauthorized. Projection mutants change Running, allowed exit 255 or a specific failure category. Virtual-time backoff, deadline and cancellation mutants show exact wrong schedules or outcomes.

No survivor, equivalence claim, compile failure, timeout or infrastructure failure remains. See results.json for every exact failing test name and per-case logs/diffs.

Iteration 1 adds four review-derived witnesses. Blocking stdout on the runtime and waiting indefinitely for stderr each trip the explicit ten-second child-exit assertion; owned-child Drop kills and reaps the child. These are behavioral catches within the test fixture, not campaign timeout classifications. Renewing the deadline after a 700 ms acknowledgment reports 1.7 s instead of the required original 1 s. Retaining release_gate through persistence prevents the synchronized revocation-intent notification while the write is blocked; the test releases storage and joins both workers before asserting the missed notification.

All ten unmodified baseline selections passed. Original worktree source hashes (95 files) and the complete restored disposable copy (97 files) match byte-for-byte. Final unmutated rebuild/verification is recorded separately in final-post.

Final patch campaign adds three independently caught regressions: removing CLI positional-request-ID validation, renewing the response-read deadline, and decoding a response through an intermediate JSON value that collapses duplicate fields. Their exact final-source failures are recorded in failure-audit.json and the per-mutant logs. The parent reviewed these raw failures before reporting readiness.

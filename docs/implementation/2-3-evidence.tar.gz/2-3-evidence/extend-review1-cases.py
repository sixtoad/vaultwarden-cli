"""Extend the original campaign with review-derived regression mutations."""
import json
from pathlib import Path
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work')
p=Path('/tmp/vw-story23-parent')
cases=json.loads((p/'cases.json').read_text())
wrapper='./scripts/with-secure-test-tmpdir.sh'
def add(name,path,old,new,selection):
 source=(root/path).read_text()
 assert source.count(old)==1,(name,source.count(old))
 cases.append(dict(name=name,path=path,old=old,new=new,command=[wrapper,'cargo','test','--offline','--locked',*selection]))
path='src/adapters/agent_wait.rs'
source=(root/path).read_text();a=source.index('pub async fn output(');b=source.index('/// A blocked diagnostic',a);block=source[a:b]
new=block.replace('tokio::sync::oneshot::channel()','std::sync::mpsc::sync_channel(1)').replace('received.await.map_err','received.recv().map_err')
assert new!=block
add('wait-blocked-stdout-runtime',path,block,new,['--test','human_cli','agent_wait_full_stdout_and_stderr_preserve_timeout_and_signal_exits'])
add('wait-blocked-diagnostic-exit',path,'received.recv_timeout(Duration::from_millis(50))','received.recv()',['--test','human_cli','agent_wait_full_stdout_and_stderr_preserve_timeout_and_signal_exits'])
a=source.index('pub async fn observe<');b=source.index('/// Writes through',a);block=source[a:b]
needle='    let work = async {'
assert block.count(needle)==1
prefix='''    // MUTANT: renew the client's budget after submission acknowledgment.
    let started = Instant::now();
    let submission = match submission {
        Some(future) => Some(std::future::ready(future.await)),
        None => None,
    };
    let deadline = deadline.map(|original| Instant::now() + original.saturating_duration_since(started));
'''
add('wait-reset-budget-after-ack',path,block,block.replace(needle,prefix+needle,1),['--lib','agent_wait::tests::submission_receipt_and_observation_share_one_deadline'])
path='src/access/application.rs';source=(root/path).read_text();a=source.index('    pub fn signed_agent_status(');b=source.index('    #[cfg(test)]\n    pub(crate) fn submit_agent_for_test(',a);block=source[a:b]
lock='                let release = self.release_gate.lock().map_err(|_error| E::Unavailable)?;\n'
anchor='            let token = self.agent_token(&Some(owner.clone()))?;\n'
assert block.count(lock)==1 and block.count(anchor)==1
add('query-release-gate-held-during-storage',path,block,block.replace(lock,'                let release = ();\n').replace(anchor,anchor+'            let _early_release = self.release_gate.lock().map_err(|_error| E::Unavailable)?;\n'),['--lib','signed_status_revocation_intent_is_published_during_blocked_query_write'])
(p/'cases-review1.json').write_text(json.dumps(cases,indent=2)+'\n')
print('Prepared',len(cases),'semantic mutants')

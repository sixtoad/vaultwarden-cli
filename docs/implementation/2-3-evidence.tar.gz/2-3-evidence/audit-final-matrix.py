from pathlib import Path
import json,re
p=Path('/tmp/vw-story23-parent')
rows={
'Owner query': ['signed_status_projects_every_validated_state_without_mutating_terminal_records','signed_status_projection_is_closed_and_validates_every_lifecycle','agent_poll_preserves_terminal_exit_information_and_busy_is_one_shot'],
'Inaccessible ID': ['signed_status_inaccessible_ids_and_authority_rejections_have_no_effects','real_linux_peer_matrix_and_noninteractive_cli'],
'Invalid authority': ['signed_query_canonical_vector_and_cross_purpose_separation','signed_query_binds_every_field_and_uses_strict_verification','signed_status_inaccessible_ids_and_authority_rejections_have_no_effects','signed_status_stored_enabled_pairing_is_independent_of_application_token','signed_status_shared_nonce_replay_precedes_neither_authentication_nor_ownership'],
'Authority changes': ['signed_status_repairing_same_label_and_principal_never_transfers_ownership','signed_status_projects_every_validated_state_without_mutating_terminal_records','signed_status_uses_provider_deadlines_even_when_storage_crosses_expiry','signed_status_revocation_intent_during_authentication_prevents_marker_and_disclosure','signed_status_revocation_intent_is_published_during_blocked_query_write','signed_query_rechecks_revocation_after_admission_and_partial_frame','signed_status_running_remains_nonterminal_until_confirmed_cleanup','real_linux_peer_matrix_and_noninteractive_cli'],
'Wait interrupted': ['query_exchange_response_read_retains_the_original_exchange_deadline','agent_wait_closed_stdout_after_receipt_retains_id_without_later_queries','agent_submit_wait_busy_changed_states_only_and_resume_without_tty','agent_wait_signal_after_receipt_retains_id_and_never_resubmits','agent_wait_timeout_and_disconnect_keep_client_uncertainty_separate','agent_wait_signal_before_acknowledgment_reports_unknown_id_without_retry','agent_wait_full_stdout_and_stderr_preserve_timeout_and_signal_exits','submission_receipt_and_observation_share_one_deadline','cancellation_interrupts_pending_state_output','busy_then_running_then_terminal_and_backoff_cap','deadline_clips_sleep_and_inflight_exchange','every_terminal_and_rejection_stops_without_sleep_or_retry'],
}
result=[]
for row,names in rows.items():
 for name in names:
  logs=['final/real-peer.log','final-post/real-peer.log'] if name=='real_linux_peer_matrix_and_noninteractive_cli' else ['final/all-targets.log','final/msrv-all-targets.log']
  for log in logs:
   text=(p/log).read_text()
   assert re.search(r'^test (?:[A-Za-z0-9_]+::)*'+re.escape(name)+r' \.\.\. ok$',text,re.M),(row,name,log)
  result.append(dict(matrix_row=row,test=name,passing_logs=logs))
(p/'final-matrix-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(len(rows),'matrix rows;',len(result),'explicit passing witness mappings; all selected tests ran.')

"""Sequential final verification; stop on any failed check or source mismatch."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
p=Path('/tmp/vw-story23-parent');root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work')
def run(*args):
 subprocess.run([sys.executable,str(p/args[0]),*args[1:]],check=True)
run('verify.py','final',str(p/'checks.json'))
run('check-log-redaction.py','final')
run('mutate.py','final-semantic',str(p/'cases-patch.json'))
source=json.loads((p/'final/source-hashes.json').read_text());restored=json.loads((p/'final-semantic/restored-hashes.json').read_text())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest==restored[name] for name,digest in source.items())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in restored.items())
for directory in ['src','tests','benches']:
 for file in (root/directory).rglob('*.rs'):os.utime(file,None)
print('Restoration verified:',len(source),'original source files,',len(restored),'complete copy files.',flush=True)
run('verify.py','final-post',str(p/'checks-post.json'))
run('check-log-redaction.py','final-post')
run('audit-final-matrix.py')
print('FINAL CAMPAIGN COMPLETE. All required checks finished.',flush=True)

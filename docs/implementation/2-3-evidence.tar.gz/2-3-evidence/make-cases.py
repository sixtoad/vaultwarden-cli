import json
from pathlib import Path
root = Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-poll-delegated-work')
cases = []
wrapper = './scripts/with-secure-test-tmpdir.sh'
def command(filter):
    return [wrapper, 'cargo', 'test', '--offline', '--locked', '--lib', filter]
def add(name, path, old, new, filter, start=None, end=None):
    source = (root/path).read_text()
    if start is not None:
        a = source.index(start)
        b = source.index(end, a) if end else len(source)
        block = source[a:b]
        assert block.count(old) == 1, (name, block.count(old))
        old, new = block, block.replace(old, new, 1)
    assert source.count(old) == 1, (name, source.count(old))
    cases.append(dict(name=name,path=path,old=old,new=new,command=command(filter)))

p='src/access/protocol.rs'
qs='impl SignedStatusQuery {'
qe='/// Untagged dispatch'
for name, old, new in [
    ('query-purpose-signing','append_field(&mut bytes, self.purpose.as_bytes());',''),
    ('query-id-signing','append_field(&mut bytes, &decode_fixed::<32>(&self.request_id)?);',''),
]:
    add(name,p,old,new,'protocol_tests',qs,qe)
# Scope signing fields separately from replay digest fields.
add('query-nonce-signing',p,'append_field(&mut bytes, &decode_fixed::<32>(&self.nonce)?);','','protocol_tests',qs,'    pub fn verify(&self, stored_public_key',)
add('query-strict-verifier',p,'key.verify_strict(&bytes, &signature)','ed25519_dalek::Verifier::verify(&key, &bytes, &signature)','protocol_tests',qs,qe)

p='src/access/provider.rs'
ast='    pub(crate) fn authenticate_status_query('
ae='    fn owned_agent_status('
add('query-signature-auth',p,'query.verify(&binding.public_key)?;','','signed_status',ast,ae)
add('query-peer-auth',p,'binding.id == query.binding_id && binding.matches_os(uid, groups)','binding.id == query.binding_id','signed_status',ast,ae)
add('query-uid-auth',p,'binding.matches_os(uid, groups)','binding.matches_os(binding.uid, groups)','signed_status',ast,ae)
add('query-group-auth',p,'binding.matches_os(uid, groups)','binding.matches_os(uid, &[binding.gid])','signed_status',ast,ae)
add('query-enabled-auth',p,'binding.matches_os(uid, groups)','(binding.uid == uid && groups.contains(&binding.gid))','signed_status',ast,ae)
add('query-stored-owner',p,'.filter(|record| record.agent_owner.as_ref() == Some(owner))','','signed_status')
add('query-durable-marker',p,'state.query_replay_markers.push(marker);','','signed_status')
add('query-replay-lookup',p,'state.query_replay_markers.contains(&marker)','false','signed_status','    pub(crate) fn consume_status_query(', '    /// Exact immutable ownership')
add('query-submission-replay-lookup',p,'record.replay_digest.as_ref() == Some(&marker)','false','signed_status','    pub(crate) fn consume_status_query(', '    /// Exact immutable ownership')
add('submission-query-replay-lookup',p,'state.query_replay_markers.contains(&marker)','false','signed_status','    pub(crate) fn create_signed(', '    fn agent_current(')

p='src/access/provider_store.rs'
add('query-marker-format',p,'!super::valid_sha256(marker)','false','signed_status_query_markers')
add('query-marker-uniqueness',p,'!replay_markers.insert(marker)','false','signed_status_query_markers')
p='src/access/application.rs'
st='    pub fn signed_agent_status('
en='    #[cfg(test)]\n    pub(crate) fn submit_agent_for_test('
source=(root/p).read_text()
a=source.index(st); b=source.index(en,a); block=source[a:b]
assert block.count('Self::token_live(&token)') >= 3
cases.append(dict(name='query-revocation-token',path=p,old=block,new=block.replace('Self::token_live(&token)','true'),command=command('signed_status')))
add('query-running-projection',p,'DirectStatus::Running => S::Running,','DirectStatus::Running => S::Completed { exit_code: 0 },','signed_status',st,en)
add('query-exit-projection',p,'S::Completed { exit_code }','S::Completed { exit_code: 0 }','signed_status',st,en)
add('query-failure-projection',p,'DirectFailure::ExecutionNonzero => F::ExecutionNonzero,','DirectFailure::ExecutionNonzero => F::ExecutionUnavailable,','signed_status',st,en)
add('query-final-request-expiry',p,'now >= *deadline','false','signed_status',st,en)
add('query-final-session-expiry',p,'now >= deadline','false','signed_status',st,en)

p='src/access/protocol.rs'
add('query-closed-projection',p,'#[serde(tag = \"status\", rename_all = \"snake_case\", deny_unknown_fields)]\nenum StrictAgentStatus','#[serde(tag = \"status\", rename_all = \"snake_case\")]\nenum StrictAgentStatus','protocol_tests')
p='src/adapters/agent_wait.rs'
add('wait-terminal-stop',p,'if state.is_terminal() {','if false {','agent_wait::tests::busy_then_running_then_terminal_and_backoff_cap')
add('wait-backoff-cap',p,'(delay * 2).min(Duration::from_secs(1))','delay * 2','agent_wait::tests')
add('wait-busy-retry',p,'category: AgentRejection::Busy,','category: AgentRejection::Replay,','agent_wait::tests')
add('wait-expiry-control-exit',p,'AgentStatus::Denied | AgentStatus::Expired | AgentStatus::Failed { .. } => 1,','AgentStatus::Denied | AgentStatus::Expired | AgentStatus::Failed { .. } => 0,','agent_wait::tests')
add('wait-deadline-extension',p,'tokio::time::sleep_until(deadline)','tokio::time::sleep_until(deadline + Duration::from_secs(1))','agent_wait::tests')
add('wait-cancellation-priority',p,'error = cancellation => Err(error),\n        _ = tokio::time::sleep_until(deadline) => Err(ClientError::WaitTimeout),\n        result = work => result,','result = work => result,\n        error = cancellation => Err(error),\n        _ = tokio::time::sleep_until(deadline) => Err(ClientError::WaitTimeout),','agent_wait::tests')
Path('/tmp/vw-story23-parent/cases.json').write_text(json.dumps(cases,indent=2)+'\n')
print('Prepared',len(cases),'exact semantic mutants')

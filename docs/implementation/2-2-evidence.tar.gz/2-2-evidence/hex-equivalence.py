# Signing validates each revision byte as lowercase hex before decoding.
alphabet = b"0123456789abcdef"
def nibble(byte):
    return byte - 48 if 48 <= byte <= 57 else byte - 97 + 10
count = 0
for high in alphabet:
    for low in alphabet:
        a, b = nibble(high) << 4, nibble(low)
        assert a & b == 0
        assert a | b == a ^ b
        assert a | b == int(bytes([high, low]), 16)
        count += 1
print(f"Exhausted {count} valid lowercase-hex byte pairs: OR equals XOR.")

import hashlib,json,pathlib,re,shutil,subprocess,tarfile
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-submit-signed-request')
completed=pathlib.Path('/tmp/vw-story22-evidence-path.txt').read_text().strip()
raw=pathlib.Path(completed)
new=root/'docs/implementation/2-2-evidence'
for p in new.iterdir():
 assert not (raw/p.name).exists(),p.name
 shutil.move(p,raw/p.name)
new.rmdir()
summary_path=root/'docs/implementation/2-2-evidence-summary.json'
summary=json.loads(summary_path.read_text())
for phase in ['review-validation','review-post-mutations']:
 for entry in json.loads((raw/phase/'results.json').read_text()):
  entry=dict(phase=phase,**entry)
  log=(raw/phase/(entry['name']+'.log')).read_text()
  rows=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)]
  if rows: entry['cargo_totals']={k:sum(r[i] for r in rows) for i,k in enumerate(['passed','failed','ignored'])}
  summary['checks'].append(entry)
source=json.loads((raw/'review-post-mutations/source-hashes.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items())
summary['post_review_source_manifest_sha256']=hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest()
results=json.loads((raw/'review-semantic/results.json').read_text())
for result in results:
 log=(raw/'review-semantic'/(result['name']+'.log')).read_text()
 result['failing_tests']=re.findall(r'^test (.+) \.\.\. FAILED$',log,re.M)
 assert result['classification']=='caught' and result['failing_tests'],result
(raw/'review-semantic/classified-results.json').write_text(json.dumps(results,indent=2)+'\n')
summary['post_review_semantic']=results
summary_path.write_text(json.dumps(summary,indent=2)+'\n')
for phase,config in [('review-validation','/tmp/vw-story22-review-checks.json'),('review-post-mutations','/tmp/vw-story22-restoration-checks.json')]:shutil.copyfile(config,raw/phase/'checks.json')
shutil.copyfile('/tmp/vw-story22-review-verify.py',raw/'review-verification-runner.py')
shutil.copyfile('/tmp/vw-story22-review-semantic.py',raw/'review-semantic-runner.py')
shutil.copyfile('/tmp/vw-story22-repackage.py',raw/'repackage-runner.py')
shutil.copyfile('/tmp/vw-story22-check-ci.py',raw/'review-ci-checker.py')
manifest={str(p.relative_to(raw)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(raw.rglob('*')) if p.is_file() and p.name!='archive-file-hashes.json'}
(raw/'archive-file-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
manifest['archive-file-hashes.json']=hashlib.sha256((raw/'archive-file-hashes.json').read_bytes()).hexdigest()
archive=root/'docs/implementation/2-2-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(raw,arcname='2-2-evidence')
with tarfile.open(archive,'r:gz') as tar:
 for name,digest in manifest.items():assert hashlib.sha256(tar.extractfile('2-2-evidence/'+name).read()).hexdigest()==digest
print(json.dumps(dict(raw_evidence=str(raw),archive=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(manifest))))

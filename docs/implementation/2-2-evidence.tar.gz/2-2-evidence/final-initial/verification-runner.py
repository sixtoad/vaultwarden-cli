import hashlib,json,os,pathlib,signal,subprocess,sys,time
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-submit-signed-request')
os.chdir(root)
phase=sys.argv[1]
checks=json.loads(pathlib.Path(sys.argv[2]).read_text())
out=root/'docs/implementation/2-2-evidence'/phase
out.mkdir(parents=True,exist_ok=False)
def manifest():
 paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines()
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if (root/p).is_file() and (p.startswith(('src/','tests/','scripts/','packaging/')) or p in ('Cargo.toml','Cargo.lock'))}
original=manifest()
(out/'source-hashes.json').write_text(json.dumps(original,indent=2)+'\n')
env=os.environ.copy()
env.update(CARGO_TARGET_DIR='/home/sixtocantolla/sessions/day-to-day/vaultwarden-cli/target',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='4',CARGO_NET_OFFLINE='true',VW_UI_DEPS='/tmp/vw-story21-ui/node_modules',CERTUTIL='/tmp/vw-story21-nss/extracted/usr/bin/certutil')
results=[]
for check in checks:
 assert manifest()==original,'source changed before check'
 name=check['name'];cmd=check['command'];timeout=check.get('timeout',1200)
 log_path=out/(name+'.log')
 print('START '+name,flush=True)
 start=time.monotonic()
 with log_path.open('w') as log:
  process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait();code=124
 result=dict(name=name,command=cmd,exit=code,seconds=round(time.monotonic()-start,2))
 results.append(result)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 assert manifest()==original,'source changed during check'
 if code:
  print(log_path.read_text()[-7000:],flush=True)
  sys.exit(code)
print('All selected checks finished; source unchanged.',flush=True)

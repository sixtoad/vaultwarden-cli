import hashlib,json,os,pathlib,shutil,signal,subprocess,tempfile,time
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-submit-signed-request')
out=root/'docs/implementation/2-2-evidence/generated'
out.mkdir(parents=True,exist_ok=False)
work=pathlib.Path(tempfile.mkdtemp(prefix='vw-story22-generated-'))
for name in ['Cargo.toml','Cargo.lock','src','tests','scripts','benches','packaging','.cargo']:
 p=root/name
 if p.is_dir():shutil.copytree(p,work/name)
 elif p.is_file():shutil.copy2(p,work/name)
# Never reuse a binary from a prior mutant merely because copied mtimes are old.
for copied in work.rglob('*'):
 if copied.is_file(): os.utime(copied, None)
source={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
(out/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
(out/'work-copy.txt').write_text(str(work)+'\n')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/sixtocantolla/sessions/day-to-day/vaultwarden-cli/target',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='4',CARGO_NET_OFFLINE='true')
command=['scripts/with-secure-test-tmpdir.sh','cargo','mutants','--no-config','--cap-lints=false','--in-place','--cargo-arg=--lib','--cargo-arg=--offline','--cargo-arg=--locked','--file','src/access/protocol.rs','--re','SignedSubmission::(verify|replay_digest|signing_bytes)','--output',str(out),'--timeout','120','--build-timeout','900','--','access::protocol_tests']
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
start=time.monotonic()
with (out/'campaign.log').open('w') as log:
 p=subprocess.Popen(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=3600)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
restored=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==digest for p,digest in source.items())
result=dict(exit=code,seconds=round(time.monotonic()-start,2),source_restored=restored)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
print((out/'campaign.log').read_text()[-7000:],flush=True)
assert restored

import pathlib,subprocess,yaml
p=pathlib.Path('.github/workflows/ci.yml')
yaml.safe_load(p.read_text())
data=yaml.load(p.read_text(),Loader=yaml.BaseLoader)
job=data['jobs']['agent-transport']
for step in job['steps']:
 if 'run' in step:subprocess.run(['bash','-n'],input=step['run'],text=True,check=True)
for name in ['merge-ready','detect-release-tag']:assert 'agent-transport' in data['jobs'][name]['needs']
assert job['strategy']['matrix']['os']==['ubuntu-24.04','ubuntu-24.04-arm']
print('CI YAML parses; new job shell syntax passes; merge/release dependency edges include namespace harness. Hosted workflow not executed.')

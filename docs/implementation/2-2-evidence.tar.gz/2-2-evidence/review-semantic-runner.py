import difflib,hashlib,json,os,pathlib,re,shutil,signal,subprocess,sys,tempfile,time
root=pathlib.Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-submit-signed-request')
phase=sys.argv[1]; cases=json.loads(pathlib.Path(sys.argv[2]).read_text())
out=root/'docs/implementation/2-2-evidence'/phase
out.mkdir(parents=True,exist_ok=False)
work=pathlib.Path(tempfile.mkdtemp(prefix='vw-story22-mutant-'))
for name in ['Cargo.toml','Cargo.lock','src','tests','scripts','benches','packaging','.cargo']:
 p=root/name
 if p.is_dir(): shutil.copytree(p,work/name)
 elif p.is_file(): shutil.copy2(p,work/name)
# Force the unmodified baseline to rebuild instead of reusing a previous mutant.
for copied in work.rglob('*'):
 if copied.is_file(): os.utime(copied,None)
source={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
(out/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
(out/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(out/'work-copy.txt').write_text(str(work)+'\n')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/sixtocantolla/sessions/day-to-day/vaultwarden-cli/target',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='4',CARGO_NET_OFFLINE='true')
def run(command,logpath):
 with logpath.open('w') as log:
  child=subprocess.Popen(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=child.wait(timeout=600)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
 return code,logpath.read_text()
results=[]
# Every chosen test command must pass unmutated and execute >=1 test.
commands=[]
for case in cases:
 command=case['command']
 if command not in commands: commands.append(command)
for i,command in enumerate(commands):
 code,log=run(command,out/f'baseline-{i}.log')
 assert code==0 and re.search(r'test result: ok\. [1-9][0-9]* passed;',log),(code,command,log[-2000:])
 print('BASELINE',i,'passed',flush=True)
for case in cases:
 path=work/case['path'];before=path.read_text();start=time.monotonic()
 assert before.count(case['old'])==1,(case['name'],'match count',before.count(case['old']))
 mutated=before.replace(case['old'],case['new'],1)
 (out/(case['name']+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),mutated.splitlines(True),fromfile=case['path'],tofile=case['path'])))
 try:
  path.write_text(mutated)
  code,log=run(case['command'],out/(case['name']+'.log'))
  verdict=('timeout' if code==124 else 'survived' if code==0 else 'unviable' if 'could not compile' in log else 'caught' if 'test result: FAILED.' in log else 'infrastructure_failure')
 finally:
  path.write_text(before)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==source[case['path']]
 result={'name':case['name'],'path':case['path'],'command':case['command'],'exit':code,'classification':verdict,'seconds':round(time.monotonic()-start,2)}
 results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
assert all(hashlib.sha256((work/p).read_bytes()).hexdigest()==digest for p,digest in source.items())
print('Mutation source restored; campaign finished.',flush=True)
sys.exit(0 if all(r['classification']=='caught' for r in results) else 1)

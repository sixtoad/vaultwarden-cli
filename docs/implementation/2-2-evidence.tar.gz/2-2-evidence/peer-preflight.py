import os,socket,struct,tempfile
with tempfile.TemporaryDirectory(prefix='vw-story22-peer-preflight-') as root:
 os.chmod(root,0o755)
 path=root+'/peer.sock'
 server=socket.socket(socket.AF_UNIX)
 server.bind(path)
 os.chown(path,0,7)
 os.chmod(path,0o660)
 server.listen(1)
 pid=os.fork()
 if pid==0:
  os.setgroups([7]);os.setresgid(9,9,9);os.setresuid(8,8,8)
  client=socket.socket(socket.AF_UNIX);client.connect(path);client.sendall(b'ok');client.close();os._exit(0)
 peer,_=server.accept()
 peer_pid,uid,gid=struct.unpack('3i',peer.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
 raw=peer.getsockopt(socket.SOL_SOCKET,59,64)
 groups=struct.unpack(f'{len(raw)//4}I',raw)
 assert (uid,gid,groups)==(8,9,(7,)),(uid,gid,groups)
 assert peer.recv(2)==b'ok'
 _,status=os.waitpid(pid,0);assert status==0
 peer.close();server.close()
 print('Real Unix listener observed UID=8, primary GID=9, supplementary GIDs=[7] in isolated user namespace.')

from pathlib import Path
import json,re,hashlib,subprocess,tarfile,shutil
r=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable');v=Path('/tmp/vw-story16-ci-verification');o=r/'docs/implementation/1-6-ci-evidence';o.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
results=read(v/'results.json');assert len(results)==4 and all(x['exit_code']==0 for x in results)
before=read(v/'source-before.json');after=read(v/'source-after.json');assert before==after
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src','tests','scripts','Cargo.toml','Cargo.lock','justfile','.github/workflows/ci.yml'],cwd=r,text=True).splitlines()
current={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (r/n).is_file()}
changed=[n for n in after if current[n]!=after[n]];assert sorted(changed)==['.github/workflows/ci.yml','tests/unsupported_provider_platform.rs'],changed
counts=[]
for n in ['1.log','3.log']:
 s=(v/n).read_text();rows=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',s,re.M)
 assert len(rows)==16 and sum(int(x[0]) for x in rows)==774 and all(x[1]=='0' for x in rows)
 assert rows[0]==('518','0','9') and len(re.findall('^Success$',s,re.M))==13
 counts.append({'log':n,'reported_passes':774,'executed_non_live':703,'live_account_early_returns':71,'suites':16,'benchmark_smoke_checks':13,'library_ignored':9,'ignored_fixtures_parent_invoked':8,'browser_fixture_not_run':1})
audit=read(v/'audit.json');assert audit['vulnerabilities']['count']==0
assert 'advisories ok, bans ok, licenses ok, sources ok' in (v/'deny.log').read_text()
security={'audit':{'argv':['cargo-audit','audit','--json'],'version':'0.22.2','exit_code':0,'reported_vulnerabilities':0,'configuration':'.cargo/audit.toml unchanged; existing RSA advisory ignore retained','warnings':['existing yanked dev dependency chacha20 0.10.1']},'deny':{'argv':['cargo-deny','check','all'],'version':'0.20.2','exit_code':0,'configuration':'deny.toml unchanged','all_four_categories':'ok','release_archive_sha256':'9f12ed4c49936e09b48bf862b595cde2fe64fcbd9d74dfacac6131ca824c8d5f','release':'https://github.com/EmbarkStudios/cargo-deny/releases/tag/0.20.2','warnings':'Existing duplicate dependency and yanked dev-dependency warnings; no suppressions added'}}
summary={'base_commit':'a66afaefbdeaba69493014e5f684434522700bef','local_commands':results,'counts':counts,'security':security,'verified_inputs_during_full_runs':len(before),'source_unchanged_during_full_runs':True,'post_run_changes':changed,'post_run_changes_scope':'Only CI Windows regression-test invocation and refinements in the non-Linux-only integration test. All production Rust, dependencies and Linux test inputs remain identical to both completed full suites. Formatting checked again. Native execution is verified by the subsequent PR CI run; do not treat this local Linux run as a non-Linux test.','native_ci':'See latest checks on https://github.com/sixtoad/vaultwarden-cli/pull/24; pending at local evidence packaging.'}
write(o/'results.json',summary);write(o/'source-tested.json',before);write(o/'source-published.json',current)
rows=read(r/'docs/implementation/1-6-evidence/mutation-source-provenance.json')
for x in rows:
 body='\n'.join((r/x['file']).read_text().splitlines()[x['first_line']-1:x['last_line']])+'\n';assert hashlib.sha256(body.encode()).hexdigest()==x['sha256'],x
write(o/'retained-mutation-proof.json',{'unchanged_linux_production_ranges':len(rows),'inventory_reference':'../1-6-evidence/mutation-source-provenance.json','previous_distinct_mutants':585,'not_rerun':True,'new_platform_boundary_not_covered_by_old_mutations':True})
with tarfile.open(o/'raw.tar.gz','w:gz') as tar:
 for p in sorted(v.iterdir()):
  if p.is_file():tar.add(p,arcname='local/'+p.name)
 for p in [Path('/tmp/vw-story16-ci-failed.log'),Path('/tmp/vw-story16-ci-linux-stable.log'),Path('/tmp/vw-story16-ci-linux-beta.log'),Path('/tmp/vw-story16-ci-verify.py'),Path('/tmp/vw-story16-ci-package.py')]:tar.add(p,arcname='provenance/'+p.name)
(o/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(o.iterdir()) if p.name!='SHA256SUMS'))
p=r/'docs/implementation/1-6-ci-follow-up.md';s=p.read_text();s=s.replace('Final local results and native CI status are recorded when available. Native\nmacOS/Windows runtime results must come from their CI hosts, not Linux cfg simulation.', '''All required local checks completed:

| Check | Exit | Elapsed |
|---|---:|---:|
| `cargo fmt --all -- --check` | 0 | 1.221 s |
| `cargo test --all-targets --locked --offline` (Rust 1.98.1) | 0 | 404.421 s |
| `cargo clippy --all-targets --all-features --locked --offline -- -D warnings` | 0 | 42.454 s |
| `rustup run 1.88.0 cargo test --all-targets --locked --offline` | 0 | 346.048 s |
| `cargo audit --json` (0.22.2) | 0 | not timed |
| `cargo deny check all` (0.20.2) | 0 | not timed |

Both full suites used the checked-in secure-temp wrapper with `RUST_TEST_THREADS=4`.
Each reports 774 passes across 16 targets: 703 non-live tests executed, 71 live-account
early returns and 13 additional benchmark smoke checks. The library has 518 passes
and nine ignored entries; eight are fixtures invoked by passing parents, and the
browser fixture was not run. The new non-Linux test target has zero tests on Linux.
Real Linux descriptor execution, deterministic races and all 66 original acceptance
matrix tests passed. No new live-account or browser coverage is claimed.

The 69 input hashes were stable throughout both local runs. Afterward, only the CI
Windows test step and the non-Linux-only regression test were refined; production
Rust, dependencies and Linux test inputs still match. Formatting and whitespace
checks were repeated. Both source snapshots are retained in
[CI evidence](1-6-ci-evidence/results.json), with [raw logs](1-6-ci-evidence/raw.tar.gz)
and [checksums](1-6-ci-evidence/SHA256SUMS).

Audit reports zero vulnerabilities under the existing repository policy. The prior
RSA advisory exception was not changed. Audit/deny still warn about the existing
yanked `chacha20 0.10.1` dev dependency; deny also reports existing duplicate
versions. All four deny categories pass; no new exception was added. The official
cargo-deny release checksum was verified. Its redundant source-build attempt was
stopped after cargo-audit finished installing; no interrupted test or audit is
counted as successful verification.

Native macOS/Windows checks require their CI hosts, not Linux cfg simulation. The
macOS stable/beta suites exercise the unsupported-platform test, and the Windows
x86_64 build job explicitly runs it. Both Windows architectures and both macOS
architectures retain build jobs. Native results are pending publication at the time
of this local evidence snapshot; see the latest [PR checks](https://github.com/sixtoad/vaultwarden-cli/pull/24/checks).

The workflow's blind review completed. Its five findings were documentation and
regression-test gaps: final result recording, bounded child execution, existing-state
preservation, valid environment-only commands and non-Unicode arguments. All were
patched. No new production defect or additional deferred item was identified.''')
p.write_text(s)
print('Packaged',len(current),'inputs; local results passed; archive', (o/'raw.tar.gz').stat().st_size)

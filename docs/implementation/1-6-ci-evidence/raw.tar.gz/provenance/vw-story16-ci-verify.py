from pathlib import Path
import hashlib,json,subprocess,os,time
root=Path('/home/sixtocantolla/sessions/day-to-day/vaultwarden-exact-protected-executable');out=Path('/tmp/vw-story16-ci-verification');out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/vw-story16-refinement-target',CARGO_TERM_COLOR='never',RUST_TEST_THREADS='4')
def hashes():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src','tests','scripts','Cargo.toml','Cargo.lock','justfile','.github/workflows/ci.yml'],cwd=root,text=True).splitlines()
 return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (root/n).is_file()}
before=hashes();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[['cargo','fmt','--all','--','--check'],['cargo','test','--all-targets','--locked','--offline'],['cargo','clippy','--all-targets','--all-features','--locked','--offline','--','-D','warnings'],['rustup','run','1.88.0','cargo','test','--all-targets','--locked','--offline']]
results=[]
for i,cmd in enumerate(commands):
 if cmd[0]=='rustup':env.update(RUSTUP_HOME='/tmp/vw-story16-rustup',CARGO_TARGET_DIR=str(root/'target/msrv188'))
 log=out/f'{i}.log';start=time.monotonic();print('Running '+repr(cmd),flush=True)
 with log.open('w') as stream:p=subprocess.run(['./scripts/with-secure-test-tmpdir.sh',*cmd],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 r=dict(argv=['./scripts/with-secure-test-tmpdir.sh',*cmd],exit_code=p.returncode,elapsed_seconds=round(time.monotonic()-start,3),log=str(log),env_overrides={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_TERM_COLOR','RUST_TEST_THREADS','RUSTUP_HOME'] if k in env});results.append(r);print(json.dumps(r),flush=True)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode:break
after=hashes();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
